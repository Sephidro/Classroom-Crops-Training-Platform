import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  WithSpringConfig,
  withTiming,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Module } from "@/data/trainingData";

interface ModuleCardProps {
  module: Module;
  isExpanded: boolean;
  progress: { completed: number; total: number };
  onPress: () => void;
  onLessonPress: (lessonId: string) => void;
  isLessonComplete: (lessonId: string) => boolean;
}

const springConfig: WithSpringConfig = {
  damping: 15,
  mass: 0.3,
  stiffness: 150,
  overshootClamping: true,
};

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function ModuleCard({
  module,
  isExpanded,
  progress,
  onPress,
  onLessonPress,
  isLessonComplete,
}: ModuleCardProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);
  const rotation = useSharedValue(0);

  React.useEffect(() => {
    rotation.value = withTiming(isExpanded ? 90 : 0, { duration: 200 });
  }, [isExpanded]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const chevronStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.98, springConfig);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, springConfig);
  };

  const isModuleComplete = progress.completed === progress.total;

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[
        styles.container,
        { backgroundColor: theme.backgroundDefault, borderColor: theme.border },
        animatedStyle,
      ]}
    >
      <View style={styles.header}>
        <View style={[styles.accentBar, { backgroundColor: module.color }]} />
        <View style={[styles.iconContainer, { backgroundColor: module.color + "15" }]}>
          <Feather name={module.icon as any} size={24} color={module.color} />
        </View>
        <View style={styles.headerContent}>
          <ThemedText style={[styles.title, { fontFamily: "Nunito_600SemiBold" }]} numberOfLines={2}>
            {module.title}
          </ThemedText>
          <View style={styles.progressRow}>
            <ThemedText style={[styles.progressText, { color: theme.textSecondary }]}>
              {progress.completed}/{progress.total} lessons
            </ThemedText>
            {isModuleComplete ? (
              <View style={[styles.completeBadge, { backgroundColor: module.color + "20" }]}>
                <Feather name="check" size={12} color={module.color} />
                <ThemedText style={[styles.completeText, { color: module.color }]}>
                  Complete
                </ThemedText>
              </View>
            ) : null}
          </View>
        </View>
        <Animated.View style={chevronStyle}>
          <Feather name="chevron-right" size={20} color={theme.textSecondary} />
        </Animated.View>
      </View>

      {isExpanded ? (
        <View style={styles.lessonsContainer}>
          {module.lessons.map((lesson, index) => {
            const isComplete = isLessonComplete(lesson.id);
            return (
              <Pressable
                key={lesson.id}
                style={({ pressed }) => [
                  styles.lessonRow,
                  { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" },
                  index < module.lessons.length - 1 && [styles.lessonBorder, { borderBottomColor: theme.border }],
                ]}
                onPress={() => onLessonPress(lesson.id)}
              >
                <View style={styles.lessonLeft}>
                  {isComplete ? (
                    <View style={[styles.checkCircle, { backgroundColor: module.color }]}>
                      <Feather name="check" size={12} color="#FFFFFF" />
                    </View>
                  ) : (
                    <View style={[styles.emptyCircle, { borderColor: theme.textTertiary }]} />
                  )}
                  <View style={styles.lessonInfo}>
                    <ThemedText
                      style={[
                        styles.lessonTitle,
                        isComplete && { color: theme.textSecondary },
                      ]}
                      numberOfLines={2}
                    >
                      {lesson.title}
                    </ThemedText>
                    <ThemedText style={[styles.lessonDuration, { color: theme.textTertiary }]}>
                      {lesson.duration}
                    </ThemedText>
                  </View>
                </View>
                <Feather name="chevron-right" size={16} color={theme.textTertiary} />
              </Pressable>
            );
          })}
        </View>
      ) : null}
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.md,
    overflow: "hidden",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    paddingLeft: 0,
  },
  accentBar: {
    width: 4,
    alignSelf: "stretch",
    borderTopLeftRadius: BorderRadius.md,
    borderBottomLeftRadius: BorderRadius.md,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: Spacing.md,
  },
  headerContent: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  title: {
    fontSize: 16,
    lineHeight: 22,
  },
  progressRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  progressText: {
    fontSize: 13,
  },
  completeBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    marginLeft: 8,
  },
  completeText: {
    fontSize: 11,
    fontWeight: "600",
    marginLeft: 4,
  },
  lessonsContainer: {
    paddingTop: 0,
    paddingBottom: Spacing.sm,
  },
  lessonRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    marginLeft: Spacing.lg,
  },
  lessonBorder: {
    borderBottomWidth: 1,
  },
  lessonLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  checkCircle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyCircle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
  },
  lessonInfo: {
    marginLeft: Spacing.md,
    flex: 1,
  },
  lessonTitle: {
    fontSize: 14,
    lineHeight: 20,
  },
  lessonDuration: {
    fontSize: 12,
    marginTop: 2,
  },
});
