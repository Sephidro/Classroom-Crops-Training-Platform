import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import MainTabNavigator, { MainTabParamList } from "@/navigation/MainTabNavigator";
import LessonViewerScreen from "@/screens/LessonViewerScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { ProgressProvider } from "@/context/ProgressContext";
import { NavigatorScreenParams } from "@react-navigation/native";

export type RootStackParamList = {
  Main: NavigatorScreenParams<MainTabParamList>;
  LessonViewer: {
    lessonId: string;
    moduleId: number;
    lessonTitle: string;
  };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <ProgressProvider>
      <Stack.Navigator screenOptions={screenOptions}>
        <Stack.Screen
          name="Main"
          component={MainTabNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="LessonViewer"
          component={LessonViewerScreen}
          options={{
            presentation: "modal",
            headerShown: false,
          }}
        />
      </Stack.Navigator>
    </ProgressProvider>
  );
}
