import React, { useState, useCallback } from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { RouteProp, useRoute, useNavigation } from "@react-navigation/native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { LessonTabBar, LessonTab } from "@/components/LessonTabBar";
import { LessonContent } from "@/components/LessonContent";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useProgressContext } from "@/context/ProgressContext";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { lessonContents, trainingModules, getModuleColor } from "@/data/trainingData";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type LessonViewerRouteProp = RouteProp<RootStackParamList, "LessonViewer">;

export default function LessonViewerScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const route = useRoute<LessonViewerRouteProp>();
  const navigation = useNavigation();
  const {
    isLessonComplete,
    isLessonBookmarked,
    markLessonComplete,
    markLessonIncomplete,
    toggleBookmark,
  } = useProgressContext();

  const { lessonId, moduleId, lessonTitle } = route.params;
  const [activeTab, setActiveTab] = useState<LessonTab>("overview");

  const content = lessonContents[lessonId];
  const isComplete = isLessonComplete(lessonId);
  const isBookmarked = isLessonBookmarked(lessonId);
  const moduleColor = getModuleColor(moduleId);

  const handleToggleComplete = useCallback(async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isComplete) {
      await markLessonIncomplete(lessonId);
    } else {
      await markLessonComplete(lessonId);
    }
  }, [isComplete, lessonId, markLessonComplete, markLessonIncomplete]);

  const handleToggleBookmark = useCallback(async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await toggleBookmark(lessonId);
  }, [lessonId, toggleBookmark]);

  if (!content) {
    return (
      <ThemedView style={[styles.container, { paddingTop: headerHeight }]}>
        <View style={styles.noContentContainer}>
          <Feather name="file-text" size={48} color={theme.textTertiary} />
          <ThemedText style={[styles.noContentTitle, { fontFamily: "Nunito_600SemiBold" }]}>
            Content Coming Soon
          </ThemedText>
          <ThemedText style={[styles.noContentText, { color: theme.textSecondary }]}>
            This lesson content is being developed. Check back soon!
          </ThemedText>
          <Button onPress={() => navigation.goBack()} style={styles.backButton}>
            Go Back
          </Button>
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: headerHeight + Spacing.md }]}>
        <View style={styles.headerTop}>
          <Pressable
            style={({ pressed }) => [
              styles.closeButton,
              { backgroundColor: pressed ? theme.backgroundSecondary : theme.backgroundDefault },
            ]}
            onPress={() => navigation.goBack()}
          >
            <Feather name="x" size={20} color={theme.text} />
          </Pressable>
          <View style={styles.headerActions}>
            <Pressable
              style={({ pressed }) => [
                styles.actionButton,
                { backgroundColor: pressed ? theme.backgroundSecondary : theme.backgroundDefault },
              ]}
              onPress={handleToggleBookmark}
            >
              <Feather
                name={isBookmarked ? "bookmark" : "bookmark"}
                size={20}
                color={isBookmarked ? BrandColors.accent : theme.textSecondary}
              />
            </Pressable>
          </View>
        </View>
        <View style={styles.titleSection}>
          <View style={[styles.moduleTag, { backgroundColor: moduleColor + "20" }]}>
            <ThemedText style={[styles.moduleTagText, { color: moduleColor }]}>
              Module {moduleId}
            </ThemedText>
          </View>
          <ThemedText style={[styles.lessonTitle, { fontFamily: "Nunito_700Bold" }]} numberOfLines={3}>
            {lessonTitle}
          </ThemedText>
        </View>
      </View>

      <LessonTabBar activeTab={activeTab} onTabChange={setActiveTab} />

      <LessonContent content={content} activeTab={activeTab} />

      <View style={[styles.footer, { backgroundColor: theme.backgroundDefault, paddingBottom: insets.bottom + Spacing.md }]}>
        <Pressable
          style={[
            styles.completeButton,
            { backgroundColor: isComplete ? BrandColors.success : BrandColors.primary },
          ]}
          onPress={handleToggleComplete}
        >
          <Feather
            name={isComplete ? "check-circle" : "circle"}
            size={20}
            color="#FFFFFF"
            style={styles.completeIcon}
          />
          <ThemedText style={styles.completeButtonText}>
            {isComplete ? "Completed" : "Mark as Complete"}
          </ThemedText>
        </Pressable>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  headerTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
  },
  headerActions: {
    flexDirection: "row",
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: Spacing.sm,
  },
  titleSection: {
    marginTop: Spacing.sm,
  },
  moduleTag: {
    alignSelf: "flex-start",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
    marginBottom: Spacing.sm,
  },
  moduleTagText: {
    fontSize: 12,
    fontWeight: "600",
  },
  lessonTitle: {
    fontSize: 24,
    lineHeight: 32,
  },
  noContentContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing["2xl"],
  },
  noContentTitle: {
    fontSize: 20,
    marginTop: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  noContentText: {
    fontSize: 15,
    textAlign: "center",
    lineHeight: 22,
    marginBottom: Spacing.xl,
  },
  backButton: {
    paddingHorizontal: Spacing["2xl"],
  },
  footer: {
    padding: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: "rgba(0,0,0,0.08)",
  },
  completeButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 52,
    borderRadius: BorderRadius.sm,
  },
  completeIcon: {
    marginRight: Spacing.sm,
  },
  completeButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
});
