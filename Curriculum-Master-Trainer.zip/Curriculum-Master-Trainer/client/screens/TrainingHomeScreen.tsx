import React, { useState, useCallback } from "react";
import { View, StyleSheet, FlatList, Image } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ProgressRing } from "@/components/ProgressRing";
import { ModuleCard } from "@/components/ModuleCard";
import { EmptyState } from "@/components/EmptyState";
import { useTheme } from "@/hooks/useTheme";
import { useProgressContext } from "@/context/ProgressContext";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { trainingModules, getTotalLessons } from "@/data/trainingData";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function TrainingHomeScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const navigation = useNavigation<NavigationProp>();
  const {
    calculateProgress,
    getModuleProgress,
    isLessonComplete,
    setCurrentLessonData,
  } = useProgressContext();

  const [expandedModules, setExpandedModules] = useState<Record<number, boolean>>({});

  const progress = calculateProgress();
  const completedCount = Object.keys(useProgressContext().completedLessons).length;
  const totalLessons = getTotalLessons();

  const toggleModule = useCallback((moduleId: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setExpandedModules((prev) => ({
      ...prev,
      [moduleId]: !prev[moduleId],
    }));
  }, []);

  const handleLessonPress = useCallback((lessonId: string, moduleId: number) => {
    const module = trainingModules.find((m) => m.id === moduleId);
    const lesson = module?.lessons.find((l) => l.id === lessonId);
    
    if (module && lesson) {
      setCurrentLessonData({
        lessonId,
        moduleId,
        lessonTitle: lesson.title,
        moduleTitle: module.title,
      });
      
      navigation.navigate("LessonViewer", {
        lessonId,
        moduleId,
        lessonTitle: lesson.title,
      });
    }
  }, [navigation, setCurrentLessonData]);

  const renderHeader = () => (
    <View style={styles.headerSection}>
      <View style={[styles.progressCard, { backgroundColor: theme.backgroundDefault }]}>
        <ProgressRing progress={progress} size={120} />
        <View style={styles.progressInfo}>
          <ThemedText style={[styles.progressTitle, { fontFamily: "Nunito_700Bold" }]}>
            Your Progress
          </ThemedText>
          <ThemedText style={[styles.progressSubtitle, { color: theme.textSecondary }]}>
            {completedCount} of {totalLessons} lessons completed
          </ThemedText>
          {progress === 100 ? (
            <View style={[styles.completeBadge, { backgroundColor: BrandColors.success + "20" }]}>
              <ThemedText style={[styles.completeText, { color: BrandColors.success }]}>
                Training Complete!
              </ThemedText>
            </View>
          ) : null}
        </View>
      </View>
      <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
        Training Modules
      </ThemedText>
    </View>
  );

  const renderModule = ({ item }: { item: typeof trainingModules[0] }) => (
    <ModuleCard
      module={item}
      isExpanded={!!expandedModules[item.id]}
      progress={getModuleProgress(item.id)}
      onPress={() => toggleModule(item.id)}
      onLessonPress={(lessonId) => handleLessonPress(lessonId, item.id)}
      isLessonComplete={isLessonComplete}
    />
  );

  return (
    <FlatList
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
      data={trainingModules}
      keyExtractor={(item) => item.id.toString()}
      renderItem={renderModule}
      ListHeaderComponent={renderHeader}
      showsVerticalScrollIndicator={false}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerSection: {
    marginBottom: Spacing.lg,
  },
  progressCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.xl,
  },
  progressInfo: {
    flex: 1,
    marginLeft: Spacing.xl,
  },
  progressTitle: {
    fontSize: 20,
    marginBottom: 4,
  },
  progressSubtitle: {
    fontSize: 14,
  },
  completeBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xs,
    marginTop: Spacing.sm,
  },
  completeText: {
    fontSize: 12,
    fontWeight: "600",
  },
  sectionTitle: {
    fontSize: 18,
    marginBottom: Spacing.sm,
  },
});
