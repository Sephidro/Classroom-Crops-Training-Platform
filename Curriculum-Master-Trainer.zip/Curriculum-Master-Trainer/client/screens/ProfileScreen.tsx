import React, { useState, useEffect } from "react";
import { View, StyleSheet, Pressable, TextInput, Alert } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";

import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { ThemedText } from "@/components/ThemedText";
import { ProgressRing } from "@/components/ProgressRing";
import { useTheme } from "@/hooks/useTheme";
import { useProgressContext } from "@/context/ProgressContext";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { getTotalLessons } from "@/data/trainingData";

const DISPLAY_NAME_KEY = "@training_display_name";

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const { calculateProgress, completedLessons } = useProgressContext();

  const [displayName, setDisplayName] = useState("Teacher");
  const [isEditing, setIsEditing] = useState(false);

  const progress = calculateProgress();
  const completedCount = Object.keys(completedLessons).length;
  const totalLessons = getTotalLessons();

  useEffect(() => {
    loadDisplayName();
  }, []);

  const loadDisplayName = async () => {
    try {
      const name = await AsyncStorage.getItem(DISPLAY_NAME_KEY);
      if (name) {
        setDisplayName(name);
      }
    } catch (error) {
      console.error("Error loading display name:", error);
    }
  };

  const saveDisplayName = async (name: string) => {
    try {
      await AsyncStorage.setItem(DISPLAY_NAME_KEY, name);
      setDisplayName(name);
      setIsEditing(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error("Error saving display name:", error);
    }
  };

  const handleResetProgress = () => {
    Alert.alert(
      "Reset Progress",
      "Are you sure you want to reset all your learning progress? This cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Reset",
          style: "destructive",
          onPress: async () => {
            try {
              await AsyncStorage.multiRemove([
                "@training_completed_lessons",
                "@training_bookmarked_lessons",
                "@training_current_lesson",
                "@training_recent_lessons",
              ]);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
              Alert.alert("Progress Reset", "Please restart the app to see the changes.");
            } catch (error) {
              console.error("Error resetting progress:", error);
            }
          },
        },
      ]
    );
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
    >
      <View style={[styles.profileCard, { backgroundColor: theme.backgroundDefault }]}>
        <View style={[styles.avatarContainer, { backgroundColor: BrandColors.primary + "20" }]}>
          <Feather name="user" size={40} color={BrandColors.primary} />
        </View>
        {isEditing ? (
          <View style={styles.editNameContainer}>
            <TextInput
              style={[styles.nameInput, { color: theme.text, borderColor: BrandColors.primary }]}
              value={displayName}
              onChangeText={setDisplayName}
              autoFocus
              onBlur={() => saveDisplayName(displayName)}
              onSubmitEditing={() => saveDisplayName(displayName)}
              returnKeyType="done"
            />
          </View>
        ) : (
          <Pressable onPress={() => setIsEditing(true)} style={styles.nameContainer}>
            <ThemedText style={[styles.displayName, { fontFamily: "Nunito_700Bold" }]}>
              {displayName}
            </ThemedText>
            <Feather name="edit-2" size={16} color={theme.textSecondary} style={styles.editIcon} />
          </Pressable>
        )}
        <ThemedText style={[styles.subtitle, { color: theme.textSecondary }]}>
          Master Teacher in Training
        </ThemedText>
      </View>

      <View style={[styles.statsCard, { backgroundColor: theme.backgroundDefault }]}>
        <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
          Your Progress
        </ThemedText>
        <View style={styles.statsRow}>
          <View style={styles.progressRingContainer}>
            <ProgressRing progress={progress} size={100} strokeWidth={10} />
          </View>
          <View style={styles.statsDetails}>
            <View style={styles.statItem}>
              <ThemedText style={[styles.statValue, { fontFamily: "Nunito_700Bold", color: BrandColors.primary }]}>
                {completedCount}
              </ThemedText>
              <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
                Lessons Completed
              </ThemedText>
            </View>
            <View style={styles.statItem}>
              <ThemedText style={[styles.statValue, { fontFamily: "Nunito_700Bold", color: BrandColors.accent }]}>
                {totalLessons - completedCount}
              </ThemedText>
              <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
                Lessons Remaining
              </ThemedText>
            </View>
          </View>
        </View>
      </View>

      <View style={[styles.menuCard, { backgroundColor: theme.backgroundDefault }]}>
        <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
          Settings
        </ThemedText>
        
        <Pressable
          style={({ pressed }) => [
            styles.menuItem,
            { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" },
          ]}
        >
          <View style={[styles.menuIconContainer, { backgroundColor: BrandColors.info + "15" }]}>
            <Feather name="info" size={18} color={BrandColors.info} />
          </View>
          <ThemedText style={styles.menuText}>About This App</ThemedText>
          <Feather name="chevron-right" size={18} color={theme.textTertiary} />
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.menuItem,
            { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" },
          ]}
        >
          <View style={[styles.menuIconContainer, { backgroundColor: BrandColors.warning + "15" }]}>
            <Feather name="help-circle" size={18} color={BrandColors.warning} />
          </View>
          <ThemedText style={styles.menuText}>Help & Support</ThemedText>
          <Feather name="chevron-right" size={18} color={theme.textTertiary} />
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.menuItem,
            { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" },
          ]}
          onPress={handleResetProgress}
        >
          <View style={[styles.menuIconContainer, { backgroundColor: BrandColors.error + "15" }]}>
            <Feather name="refresh-cw" size={18} color={BrandColors.error} />
          </View>
          <ThemedText style={[styles.menuText, { color: BrandColors.error }]}>Reset Progress</ThemedText>
          <Feather name="chevron-right" size={18} color={theme.textTertiary} />
        </Pressable>
      </View>

      <ThemedText style={[styles.version, { color: theme.textTertiary }]}>
        Classroom Crops Teacher Training v1.0.0
      </ThemedText>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  profileCard: {
    alignItems: "center",
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  avatarContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  nameContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  displayName: {
    fontSize: 24,
  },
  editIcon: {
    marginLeft: Spacing.sm,
  },
  editNameContainer: {
    width: "100%",
    paddingHorizontal: Spacing.xl,
  },
  nameInput: {
    fontSize: 24,
    fontWeight: "700",
    textAlign: "center",
    borderBottomWidth: 2,
    paddingVertical: Spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    marginTop: Spacing.xs,
  },
  statsCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 16,
    marginBottom: Spacing.lg,
  },
  statsRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  progressRingContainer: {
    marginRight: Spacing.xl,
  },
  statsDetails: {
    flex: 1,
  },
  statItem: {
    marginBottom: Spacing.md,
  },
  statValue: {
    fontSize: 28,
  },
  statLabel: {
    fontSize: 13,
  },
  menuCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.sm,
    borderRadius: BorderRadius.xs,
    marginBottom: Spacing.xs,
  },
  menuIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.md,
  },
  menuText: {
    flex: 1,
    fontSize: 15,
  },
  version: {
    textAlign: "center",
    fontSize: 12,
    marginTop: Spacing.md,
  },
});
