# Classroom Crops Teacher Training Platform - Design Guidelines

## Brand Identity

**Purpose**: Transform teachers with zero agriculture experience into confident, expert instructors through structured, self-paced training that normalizes failure and celebrates growth.

**Aesthetic Direction**: **Organic Editorial** - A sophisticated blend of natural warmth with magazine-quality typographic hierarchy. Earthy greens meet clean whitespace, rounded corners soften authority, and generous spacing creates breathing room for learning. This isn't corporate training - it's a nurturing growth journey that feels both professional and human.

**Memorable Element**: **The Growth Arc** - A subtle curved progress indicator that flows through the app like a growing vine, connecting modules and celebrating every completed lesson. This visual metaphor reinforces that mastery is a journey, not a destination.

## Navigation Architecture

**Root Navigation**: Tab Bar (3 tabs)
- **Training** (Home icon): Browse modules, track progress
- **My Learning** (BookOpen icon): Current lesson, bookmarks, history
- **Profile** (User icon): Settings, certificates, achievements

**Screen Inventory**:
1. Training Home (Training tab) - Module overview with progress
2. Module Detail (Training tab, push) - Lesson list for selected module
3. Lesson Viewer (Training tab, modal) - 4-tab lesson content
4. My Learning (My Learning tab) - Continue learning, bookmarks
5. Profile (Profile tab) - User info, settings, achievements

**Authentication**: No auth required. Profile screen includes avatar customization and display name.

## Screen Specifications

### 1. Training Home
**Purpose**: Overview of all modules with visual progress tracking

**Layout**:
- Header: Large title "Master Teacher Training", transparent background, search icon (right)
- Content: Scrollable
  - Progress card (non-scrollable hero section)
  - Module list (expandable cards)
- Safe area: top = headerHeight + 24, bottom = tabBarHeight + 24

**Components**:
- Progress Ring: Circular progress (0-100%) with percentage centered
- Module Cards: Colored accent bar (left), icon, title, lesson count, expand chevron
- When expanded: Lesson rows with type icon, title, duration, completion checkmark

### 2. Module Detail
**Purpose**: Focused view of all lessons within a module

**Layout**:
- Header: Default navigation (back button left), module title, filter icon (right)
- Content: Scrollable list
  - Module description card
  - Lesson list (tappable rows)
- Safe area: top = 24, bottom = tabBarHeight + 24

**Components**:
- Lesson Row: Type icon, title, duration badge, lock icon (if prerequisite incomplete), checkmark (if complete)

### 3. Lesson Viewer (Modal)
**Purpose**: Immersive 4-tab content experience

**Layout**:
- Header: Close button (left), lesson title, mark complete button (right)
- Tab Bar: Custom horizontal scroll tabs (Overview, Content, Practice, Tips)
- Content: Scrollable, tab-specific content
- Safe area: top = headerHeight + 24, bottom = 24

**Components**:
- Tab Indicator: Underline on active tab
- Content blocks: Rich text with formatting, bulleted lists, scenario cards
- Mark Complete Button: Prominent at bottom of each tab

### 4. My Learning
**Purpose**: Quick access to current and saved lessons

**Layout**:
- Header: Large title "My Learning", transparent
- Content: Scrollable
  - "Continue Learning" card (current lesson preview)
  - Bookmarked lessons list
  - Recent lessons list
- Safe area: top = headerHeight + 24, bottom = tabBarHeight + 24

### 5. Profile
**Purpose**: User customization and settings

**Layout**:
- Header: Large title "Profile", transparent
- Content: Scrollable form
  - Avatar picker (circular, 80pt)
  - Display name field
  - Settings sections (Notifications, Appearance, About)
- Safe area: top = headerHeight + 24, bottom = tabBarHeight + 24

## Color Palette

**Primary**: `#2D7A4F` (Forest Green) - Trust, growth, nature
**Secondary**: `#8B5A3C` (Warm Earth) - Grounding, organic
**Accent**: `#E8A43E` (Golden Harvest) - Achievement, energy

**Background**: `#FAFAF8` (Warm White) - Soft, inviting
**Surface**: `#FFFFFF` (Pure White) - Content cards
**Surface Secondary**: `#F4F3F0` (Stone Gray) - Subtle sections

**Text Primary**: `#1A1A1A` (Near Black)
**Text Secondary**: `#6B6B6B` (Warm Gray)
**Text Tertiary**: `#A8A8A8` (Light Gray)

**Semantic**:
- Success: `#2D7A4F` (reuse Primary)
- Warning: `#D97D3A`
- Error: `#C74940`
- Info: `#4A7FA6`

**Module Colors** (accent bars):
- Module 1: `#4A7FA6` (Blue)
- Module 2: `#2D7A4F` (Green)
- Module 3: `#7B68A8` (Purple)
- Module 4: `#E8A43E` (Orange)
- Module 5: `#C74940` (Red)
- Module 6: `#5A6FA8` (Indigo)
- Module 7: `#D4A936` (Yellow)

## Typography

**Primary Font**: Nunito (Google Font) - Friendly, approachable, highly legible
**Body Font**: System (SF Pro/Roboto) - Optimal reading for long content

**Type Scale**:
- **Hero**: Nunito Bold, 34pt, line height 1.2
- **Title 1**: Nunito Bold, 28pt, line height 1.3
- **Title 2**: Nunito SemiBold, 22pt, line height 1.3
- **Title 3**: Nunito SemiBold, 18pt, line height 1.4
- **Body**: System Regular, 16pt, line height 1.5
- **Body Emphasis**: System Semibold, 16pt, line height 1.5
- **Caption**: System Regular, 14pt, line height 1.4
- **Small**: System Regular, 12pt, line height 1.3

## Visual Design

**Corner Radius**: 16pt (cards), 12pt (buttons), 24pt (floating elements)

**Spacing Scale**: 4, 8, 12, 16, 24, 32, 48, 64

**Card Elevation**: Subtle border `rgba(0,0,0,0.08)` with no shadow for most cards. Floating buttons use drop shadow (shadowOffset: {width: 0, height: 2}, shadowOpacity: 0.10, shadowRadius: 2).

**Icons**: Feather icons from @expo/vector-icons, 24pt default size

## Assets to Generate

**App Icon** (`icon.png`): Stylized plant sprouting from book/curriculum guide, forest green and golden accent
**WHERE USED**: Device home screen

**Splash Icon** (`splash-icon.png`): Simplified version of app icon
**WHERE USED**: App launch screen

**Empty Progress** (`empty-progress.png`): Teacher at desk with empty progress chart, encouraging stance
**WHERE USED**: Training Home when no lessons completed

**Empty Bookmarks** (`empty-bookmarks.png`): Open notebook with bookmark ribbon
**WHERE USED**: My Learning screen when no bookmarks saved

**Lesson Complete** (`lesson-complete.png`): Sprouting seedling breaking through soil
**WHERE USED**: Completion celebration modal

**Module Complete** (`module-complete.png`): Mature plant with full foliage and flowers
**WHERE USED**: Module completion screen

**Profile Avatar Preset** (`avatar-teacher-1.png`): Friendly teacher illustration, diverse representation (generate 3 variants)
**WHERE USED**: Profile screen avatar picker

**Certificate Background** (`certificate-bg.png`): Subtle botanical border illustration
**WHERE USED**: Achievement certificates in Profile