import React, { createContext, useContext, ReactNode } from "react";
import { useProgress, CurrentLesson } from "@/hooks/useProgress";

interface ProgressContextType {
  completedLessons: Record<string, boolean>;
  bookmarkedLessons: string[];
  currentLesson: CurrentLesson | null;
  recentLessons: string[];
  isLoading: boolean;
  markLessonComplete: (lessonId: string) => Promise<void>;
  markLessonIncomplete: (lessonId: string) => Promise<void>;
  toggleBookmark: (lessonId: string) => Promise<void>;
  setCurrentLessonData: (lesson: CurrentLesson | null) => Promise<void>;
  calculateProgress: () => number;
  getModuleProgress: (moduleId: number) => { completed: number; total: number };
  isLessonComplete: (lessonId: string) => boolean;
  isLessonBookmarked: (lessonId: string) => boolean;
  getNextLesson: () => CurrentLesson | null;
}

const ProgressContext = createContext<ProgressContextType | null>(null);

export function ProgressProvider({ children }: { children: ReactNode }) {
  const progress = useProgress();

  return (
    <ProgressContext.Provider value={progress}>
      {children}
    </ProgressContext.Provider>
  );
}

export function useProgressContext() {
  const context = useContext(ProgressContext);
  if (!context) {
    throw new Error("useProgressContext must be used within a ProgressProvider");
  }
  return context;
}
