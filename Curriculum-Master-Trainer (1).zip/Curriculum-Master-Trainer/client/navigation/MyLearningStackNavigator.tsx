import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import MyLearningScreen from "@/screens/MyLearningScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type MyLearningStackParamList = {
  MyLearning: undefined;
};

const Stack = createNativeStackNavigator<MyLearningStackParamList>();

export default function MyLearningStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="MyLearning"
        component={MyLearningScreen}
        options={{
          headerTitle: "My Learning",
        }}
      />
    </Stack.Navigator>
  );
}
