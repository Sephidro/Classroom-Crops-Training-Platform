import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import TrainingHomeScreen from "@/screens/TrainingHomeScreen";
import { HeaderTitle } from "@/components/HeaderTitle";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type TrainingStackParamList = {
  TrainingHome: undefined;
};

const Stack = createNativeStackNavigator<TrainingStackParamList>();

export default function TrainingStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="TrainingHome"
        component={TrainingHomeScreen}
        options={{
          headerTitle: () => <HeaderTitle title="Master Teacher Training" />,
        }}
      />
    </Stack.Navigator>
  );
}
