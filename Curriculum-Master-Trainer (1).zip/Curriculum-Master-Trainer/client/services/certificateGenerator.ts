import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";

interface CertificateData {
  teacherName: string;
  completionDate: string;
  totalLessons: number;
  quizzesPassed: number;
}

function generateCertificateHtml(data: CertificateData): string {
  const { teacherName, completionDate, totalLessons, quizzesPassed } = data;
  
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        @page {
          size: landscape;
          margin: 0;
        }
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        body {
          font-family: 'Georgia', 'Times New Roman', serif;
          background: linear-gradient(135deg, #f8faf8 0%, #e8f5e9 100%);
          min-height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 20px;
        }
        .certificate {
          width: 10in;
          height: 7.5in;
          background: white;
          border: 3px solid #2D7A4F;
          border-radius: 8px;
          padding: 40px 60px;
          position: relative;
          box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .certificate::before {
          content: '';
          position: absolute;
          top: 15px;
          left: 15px;
          right: 15px;
          bottom: 15px;
          border: 1px solid #2D7A4F;
          border-radius: 4px;
          pointer-events: none;
        }
        .header {
          text-align: center;
          margin-bottom: 30px;
        }
        .logo-container {
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 12px;
          margin-bottom: 20px;
        }
        .logo {
          width: 50px;
          height: 50px;
          background: #2D7A4F;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: bold;
          font-size: 24px;
        }
        .brand-name {
          font-size: 28px;
          font-weight: bold;
          color: #2D7A4F;
          letter-spacing: 2px;
        }
        .title {
          font-size: 48px;
          color: #1a1a1a;
          font-weight: normal;
          letter-spacing: 4px;
          text-transform: uppercase;
          margin-bottom: 10px;
        }
        .subtitle {
          font-size: 18px;
          color: #666;
          letter-spacing: 3px;
          text-transform: uppercase;
        }
        .content {
          text-align: center;
          margin: 40px 0;
        }
        .presented-to {
          font-size: 14px;
          color: #888;
          letter-spacing: 2px;
          text-transform: uppercase;
          margin-bottom: 10px;
        }
        .recipient-name {
          font-size: 42px;
          color: #2D7A4F;
          font-style: italic;
          border-bottom: 2px solid #2D7A4F;
          padding-bottom: 10px;
          margin-bottom: 30px;
          display: inline-block;
          min-width: 400px;
        }
        .description {
          font-size: 16px;
          color: #444;
          line-height: 1.8;
          max-width: 600px;
          margin: 0 auto;
        }
        .achievement-row {
          display: flex;
          justify-content: center;
          gap: 60px;
          margin-top: 30px;
        }
        .achievement {
          text-align: center;
        }
        .achievement-value {
          font-size: 32px;
          font-weight: bold;
          color: #2D7A4F;
        }
        .achievement-label {
          font-size: 12px;
          color: #888;
          text-transform: uppercase;
          letter-spacing: 1px;
        }
        .footer {
          position: absolute;
          bottom: 50px;
          left: 60px;
          right: 60px;
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
        }
        .signature-block {
          text-align: center;
        }
        .signature-line {
          width: 200px;
          border-top: 1px solid #333;
          margin-bottom: 5px;
        }
        .signature-title {
          font-size: 12px;
          color: #666;
        }
        .date-block {
          text-align: center;
        }
        .date-value {
          font-size: 16px;
          color: #333;
          margin-bottom: 5px;
        }
        .date-label {
          font-size: 12px;
          color: #666;
        }
        .seal {
          width: 80px;
          height: 80px;
          background: linear-gradient(135deg, #2D7A4F, #1a5a3a);
          border-radius: 50%;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          color: white;
        }
        .seal-text {
          font-size: 10px;
          text-transform: uppercase;
          letter-spacing: 1px;
        }
        .seal-year {
          font-size: 18px;
          font-weight: bold;
        }
      </style>
    </head>
    <body>
      <div class="certificate">
        <div class="header">
          <div class="logo-container">
            <div class="logo">CC</div>
            <span class="brand-name">Classroom Crops</span>
          </div>
          <h1 class="title">Certificate</h1>
          <p class="subtitle">of Completion</p>
        </div>
        
        <div class="content">
          <p class="presented-to">This certifies that</p>
          <p class="recipient-name">${teacherName || "Teacher Name"}</p>
          <p class="description">
            has successfully completed the <strong>Master Teacher Training Program</strong> 
            for the Classroom Crops curriculum, demonstrating proficiency in hands-on 
            agriculture education and experiential learning methodologies.
          </p>
          
          <div class="achievement-row">
            <div class="achievement">
              <div class="achievement-value">${totalLessons}</div>
              <div class="achievement-label">Lessons Completed</div>
            </div>
            <div class="achievement">
              <div class="achievement-value">${quizzesPassed}/7</div>
              <div class="achievement-label">Quizzes Passed</div>
            </div>
            <div class="achievement">
              <div class="achievement-value">6</div>
              <div class="achievement-label">Weeks of Training</div>
            </div>
          </div>
        </div>
        
        <div class="footer">
          <div class="signature-block">
            <div class="signature-line"></div>
            <p class="signature-title">Program Director</p>
          </div>
          
          <div class="seal">
            <span class="seal-text">Certified</span>
            <span class="seal-year">${new Date().getFullYear()}</span>
          </div>
          
          <div class="date-block">
            <p class="date-value">${completionDate}</p>
            <p class="date-label">Date of Completion</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
}

export async function generateCertificatePDF(data: CertificateData): Promise<string | null> {
  try {
    const html = generateCertificateHtml(data);
    const { uri } = await Print.printToFileAsync({
      html,
      base64: false,
    });
    return uri;
  } catch (error) {
    console.error("Error generating certificate:", error);
    return null;
  }
}

export async function shareCertificate(data: CertificateData): Promise<boolean> {
  const pdfUri = await generateCertificatePDF(data);
  
  if (!pdfUri) {
    return false;
  }

  try {
    if (Platform.OS === "web") {
      const response = await fetch(pdfUri);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "classroom-crops-certificate.pdf";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return true;
    }

    const isAvailable = await Sharing.isAvailableAsync();
    if (isAvailable) {
      await Sharing.shareAsync(pdfUri, {
        mimeType: "application/pdf",
        dialogTitle: "Share Your Certificate",
        UTI: "com.adobe.pdf",
      });
      return true;
    }
    
    return false;
  } catch (error) {
    console.error("Error sharing certificate:", error);
    return false;
  }
}

export async function printCertificate(data: CertificateData): Promise<boolean> {
  try {
    const html = generateCertificateHtml(data);
    await Print.printAsync({ html });
    return true;
  } catch (error) {
    console.error("Error printing certificate:", error);
    return false;
  }
}
