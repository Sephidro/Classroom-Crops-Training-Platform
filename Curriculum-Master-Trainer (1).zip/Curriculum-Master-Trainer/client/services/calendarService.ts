import * as Calendar from "expo-calendar";
import { Platform } from "react-native";
import { trainingModules, Lesson } from "@/data/trainingData";

export interface ScheduledLesson {
  lessonId: string;
  calendarEventId: string;
  scheduledDate: string;
  moduleId: number;
}

export async function requestCalendarPermission(): Promise<boolean> {
  const { status } = await Calendar.requestCalendarPermissionsAsync();
  return status === "granted";
}

export async function getCalendarPermissionStatus(): Promise<boolean> {
  const { status } = await Calendar.getCalendarPermissionsAsync();
  return status === "granted";
}

async function getDefaultCalendarId(): Promise<string | null> {
  const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
  
  const defaultCalendar = calendars.find(
    (cal) => cal.allowsModifications && (cal.isPrimary || cal.source?.name === "Default")
  );
  
  if (defaultCalendar) {
    return defaultCalendar.id;
  }

  const writableCalendar = calendars.find((cal) => cal.allowsModifications);
  if (writableCalendar) {
    return writableCalendar.id;
  }

  if (Platform.OS === "ios") {
    const newCalendarId = await Calendar.createCalendarAsync({
      title: "Classroom Crops",
      color: "#2D7A4F",
      entityType: Calendar.EntityTypes.EVENT,
      sourceId: calendars[0]?.source?.id,
      source: calendars[0]?.source,
      name: "Classroom Crops Lessons",
      ownerAccount: "personal",
      accessLevel: Calendar.CalendarAccessLevel.OWNER,
    });
    return newCalendarId;
  }

  return calendars[0]?.id || null;
}

export async function addLessonToCalendar(
  lessonId: string,
  date: Date,
  startTime: { hour: number; minute: number }
): Promise<string | null> {
  try {
    const hasPermission = await requestCalendarPermission();
    if (!hasPermission) {
      console.log("Calendar permission denied");
      return null;
    }

    const module = trainingModules.find((m) =>
      m.lessons.some((l) => l.id === lessonId)
    );
    const lesson = module?.lessons.find((l) => l.id === lessonId);

    if (!module || !lesson) {
      console.error("Lesson not found:", lessonId);
      return null;
    }

    const calendarId = await getDefaultCalendarId();
    if (!calendarId) {
      console.error("No calendar available");
      return null;
    }

    const durationMinutes = parseInt(lesson.duration) || 45;
    
    const startDate = new Date(date);
    startDate.setHours(startTime.hour, startTime.minute, 0, 0);
    
    const endDate = new Date(startDate);
    endDate.setMinutes(endDate.getMinutes() + durationMinutes);

    const eventId = await Calendar.createEventAsync(calendarId, {
      title: `Classroom Crops: ${lesson.title}`,
      notes: `Module: ${module.title}\n\nLesson Type: ${lesson.type}\n${lesson.dayType ? `Day Type: ${lesson.dayType}\n` : ""}\nDuration: ${lesson.duration}\n\nOpen the Classroom Crops app to review lesson content and teaching scripts.`,
      startDate,
      endDate,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      alarms: [{ relativeOffset: -30 }],
    });

    return eventId;
  } catch (error) {
    console.error("Error adding lesson to calendar:", error);
    return null;
  }
}

export async function removeLessonFromCalendar(eventId: string): Promise<boolean> {
  try {
    await Calendar.deleteEventAsync(eventId);
    return true;
  } catch (error) {
    console.error("Error removing event from calendar:", error);
    return false;
  }
}

export async function getUpcomingLessonEvents(): Promise<Calendar.Event[]> {
  try {
    const hasPermission = await getCalendarPermissionStatus();
    if (!hasPermission) return [];

    const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
    const calendarIds = calendars.map((cal) => cal.id);

    const now = new Date();
    const twoWeeksLater = new Date();
    twoWeeksLater.setDate(twoWeeksLater.getDate() + 14);

    const events = await Calendar.getEventsAsync(calendarIds, now, twoWeeksLater);
    
    return events.filter((event) => 
      event.title?.includes("Classroom Crops:")
    );
  } catch (error) {
    console.error("Error fetching calendar events:", error);
    return [];
  }
}
