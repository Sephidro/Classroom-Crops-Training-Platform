import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import { trainingModules, lessonContents, LessonContent } from "@/data/trainingData";

interface LessonForPDF {
  id: string;
  title: string;
  moduleTitle: string;
  duration: string;
  dayType?: string;
  content: LessonContent;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function formatMarkdownToHtml(text: string): string {
  let html = escapeHtml(text);
  
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  html = html.replace(/^• (.+)$/gm, "<li>$1</li>");
  html = html.replace(/^(\d+)\. (.+)$/gm, "<li>$2</li>");
  html = html.replace(/(<li>.*<\/li>\n?)+/g, "<ul>$&</ul>");
  html = html.replace(/\n\n/g, "</p><p>");
  html = html.replace(/\n/g, "<br>");
  
  return `<p>${html}</p>`;
}

function getPdfStyles(): string {
  return `
    * {
      box-sizing: border-box;
    }
    body {
      font-family: 'Georgia', 'Times New Roman', serif;
      font-size: 11pt;
      line-height: 1.5;
      color: #333;
      max-width: 8.5in;
      margin: 0 auto;
      padding: 0.5in;
    }
    .lesson-page {
      page-break-after: always;
    }
    .lesson-page:last-child {
      page-break-after: auto;
    }
    .header {
      border-bottom: 3px solid #2D7A4F;
      padding-bottom: 12px;
      margin-bottom: 20px;
    }
    .logo-section {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 8px;
    }
    .logo {
      width: 40px;
      height: 40px;
      background: #2D7A4F;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: bold;
      font-size: 18px;
    }
    .brand-name {
      font-size: 20px;
      font-weight: bold;
      color: #2D7A4F;
    }
    .module-title {
      font-size: 12pt;
      color: #666;
      margin: 4px 0;
    }
    .lesson-title {
      font-size: 18pt;
      font-weight: bold;
      color: #1a1a1a;
      margin: 8px 0;
    }
    .meta-row {
      display: flex;
      gap: 20px;
      font-size: 10pt;
      color: #666;
    }
    .meta-item {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .section {
      margin-bottom: 20px;
    }
    .section-title {
      font-size: 13pt;
      font-weight: bold;
      color: #2D7A4F;
      border-bottom: 1px solid #e0e0e0;
      padding-bottom: 6px;
      margin-bottom: 10px;
    }
    .key-points {
      background: #f8f9f7;
      border-left: 4px solid #2D7A4F;
      padding: 10px 14px;
      margin: 10px 0;
    }
    .key-points ul {
      margin: 0;
      padding-left: 20px;
    }
    .key-points li {
      margin: 4px 0;
    }
    .script-box {
      background: #fffbeb;
      border: 1px solid #f59e0b;
      border-radius: 8px;
      padding: 10px 14px;
      margin: 10px 0;
    }
    .script-label {
      font-weight: bold;
      color: #b45309;
      font-size: 10pt;
      margin-bottom: 4px;
    }
    .tip-box {
      background: #f0fdf4;
      border: 1px solid #22c55e;
      border-radius: 6px;
      padding: 8px 12px;
      margin: 6px 0;
      font-size: 10pt;
    }
    .tip-box::before {
      content: "Tip: ";
      font-weight: bold;
      color: #16a34a;
    }
    .mistake-box {
      background: #fef2f2;
      border: 1px solid #ef4444;
      border-radius: 6px;
      padding: 8px 12px;
      margin: 6px 0;
      font-size: 10pt;
    }
    .mistake-box::before {
      content: "Avoid: ";
      font-weight: bold;
      color: #dc2626;
    }
    ul, ol {
      margin: 6px 0;
      padding-left: 24px;
    }
    li {
      margin: 3px 0;
    }
    p {
      margin: 8px 0;
    }
    .footer {
      margin-top: 20px;
      padding-top: 10px;
      border-top: 1px solid #e0e0e0;
      font-size: 9pt;
      color: #999;
      text-align: center;
    }
    @media print {
      body {
        padding: 0.4in;
      }
      .lesson-page {
        page-break-after: always;
      }
    }
    @page {
      margin: 0.5in;
      size: letter;
    }
  `;
}

function generateLessonContentHtml(lesson: LessonForPDF, isModulePdf: boolean = false): string {
  const { title, moduleTitle, duration, dayType, content } = lesson;
  
  return `
    <div class="lesson-page">
      <div class="header">
        <div class="logo-section">
          <div class="logo">CC</div>
          <span class="brand-name">Classroom Crops</span>
        </div>
        <div class="module-title">${escapeHtml(moduleTitle)}</div>
        <div class="lesson-title">${escapeHtml(title)}</div>
        <div class="meta-row">
          <div class="meta-item">Duration: ${duration}</div>
          ${dayType ? `<div class="meta-item">Day Type: ${dayType}</div>` : ""}
        </div>
      </div>

      <div class="section">
        <div class="section-title">Overview</div>
        ${formatMarkdownToHtml(content.overview)}
      </div>

      <div class="section">
        <div class="section-title">Key Learning Points</div>
        <div class="key-points">
          <ul>
            ${content.keyPoints.map((point) => `<li>${escapeHtml(point)}</li>`).join("")}
          </ul>
        </div>
      </div>

      <div class="section">
        <div class="section-title">Lesson Content & Scripts</div>
        ${formatMarkdownToHtml(content.detailedContent)}
      </div>

      <div class="section">
        <div class="section-title">Practice Activity</div>
        ${formatMarkdownToHtml(content.practiceActivity)}
      </div>

      <div class="section">
        <div class="section-title">Teaching Tips</div>
        ${content.teachingTips.map((tip) => `<div class="tip-box">${escapeHtml(tip)}</div>`).join("")}
      </div>

      <div class="section">
        <div class="section-title">Common Mistakes to Avoid</div>
        ${content.commonMistakes.map((mistake) => `<div class="mistake-box">${escapeHtml(mistake)}</div>`).join("")}
      </div>

      <div class="footer">
        Classroom Crops Master Teacher Training | Printed from the Classroom Crops App
      </div>
    </div>
  `;
}

function generateLessonHtml(lesson: LessonForPDF): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>${getPdfStyles()}</style>
    </head>
    <body>
      ${generateLessonContentHtml(lesson)}
    </body>
    </html>
  `;
}

export async function generateLessonPDF(lessonId: string): Promise<string | null> {
  const module = trainingModules.find((m) =>
    m.lessons.some((l) => l.id === lessonId)
  );
  
  if (!module) {
    console.error("Module not found for lesson:", lessonId);
    return null;
  }

  const lesson = module.lessons.find((l) => l.id === lessonId);
  if (!lesson) {
    console.error("Lesson not found:", lessonId);
    return null;
  }

  const content = lessonContents[lessonId];
  if (!content) {
    console.error("Lesson content not found:", lessonId);
    return null;
  }

  const lessonForPDF: LessonForPDF = {
    id: lessonId,
    title: lesson.title,
    moduleTitle: module.title,
    duration: lesson.duration,
    dayType: lesson.dayType,
    content,
  };

  try {
    const html = generateLessonHtml(lessonForPDF);
    const { uri } = await Print.printToFileAsync({
      html,
      base64: false,
    });
    
    return uri;
  } catch (error) {
    console.error("Error generating PDF:", error);
    return null;
  }
}

export async function shareLessonPDF(lessonId: string): Promise<boolean> {
  const pdfUri = await generateLessonPDF(lessonId);
  
  if (!pdfUri) {
    return false;
  }

  try {
    if (Platform.OS === "web") {
      const response = await fetch(pdfUri);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `lesson-${lessonId}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return true;
    }

    const isAvailable = await Sharing.isAvailableAsync();
    if (isAvailable) {
      await Sharing.shareAsync(pdfUri, {
        mimeType: "application/pdf",
        dialogTitle: "Share Lesson Plan",
        UTI: "com.adobe.pdf",
      });
      return true;
    }
    
    return false;
  } catch (error) {
    console.error("Error sharing PDF:", error);
    return false;
  }
}

export async function printLesson(lessonId: string): Promise<boolean> {
  const module = trainingModules.find((m) =>
    m.lessons.some((l) => l.id === lessonId)
  );
  
  if (!module) return false;

  const lesson = module.lessons.find((l) => l.id === lessonId);
  if (!lesson) return false;

  const content = lessonContents[lessonId];
  if (!content) return false;

  const lessonForPDF: LessonForPDF = {
    id: lessonId,
    title: lesson.title,
    moduleTitle: module.title,
    duration: lesson.duration,
    dayType: lesson.dayType,
    content,
  };

  try {
    const html = generateLessonHtml(lessonForPDF);
    await Print.printAsync({ html });
    return true;
  } catch (error) {
    console.error("Error printing:", error);
    return false;
  }
}

export async function generateModulePDF(moduleId: number): Promise<string | null> {
  const module = trainingModules.find((m) => m.id === moduleId);
  if (!module) return null;

  const lessonsContent = module.lessons
    .map((lesson) => {
      const content = lessonContents[lesson.id];
      if (!content) return "";
      
      const lessonForPDF: LessonForPDF = {
        id: lesson.id,
        title: lesson.title,
        moduleTitle: module.title,
        duration: lesson.duration,
        dayType: lesson.dayType,
        content,
      };
      
      return generateLessonContentHtml(lessonForPDF, true);
    })
    .filter(Boolean)
    .join("");

  const fullHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>${getPdfStyles()}</style>
    </head>
    <body>
      ${lessonsContent}
    </body>
    </html>
  `;

  try {
    const { uri } = await Print.printToFileAsync({
      html: fullHtml,
      base64: false,
    });
    return uri;
  } catch (error) {
    console.error("Error generating module PDF:", error);
    return null;
  }
}

export async function shareModulePDF(moduleId: number): Promise<boolean> {
  const pdfUri = await generateModulePDF(moduleId);
  
  if (!pdfUri) {
    return false;
  }

  const module = trainingModules.find((m) => m.id === moduleId);
  const moduleName = module?.title.replace(/[^a-zA-Z0-9]/g, "-").toLowerCase() || `module-${moduleId}`;

  try {
    if (Platform.OS === "web") {
      const response = await fetch(pdfUri);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${moduleName}-lesson-plans.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return true;
    }

    const isAvailable = await Sharing.isAvailableAsync();
    if (isAvailable) {
      await Sharing.shareAsync(pdfUri, {
        mimeType: "application/pdf",
        dialogTitle: "Share Module Lesson Plans",
        UTI: "com.adobe.pdf",
      });
      return true;
    }
    
    return false;
  } catch (error) {
    console.error("Error sharing module PDF:", error);
    return false;
  }
}
