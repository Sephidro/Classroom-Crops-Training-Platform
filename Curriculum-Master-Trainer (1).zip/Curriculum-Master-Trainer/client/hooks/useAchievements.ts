import { useState, useEffect, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { achievements, Achievement } from "@/data/achievements";
import { trainingModules, getTotalLessons } from "@/data/trainingData";

const ACHIEVEMENTS_KEY = "@classroom_crops:achievements";
const QUIZ_SCORES_KEY = "@classroom_crops:quiz_scores";

interface QuizScore {
  moduleId: number;
  score: number;
  passed: boolean;
  completedAt: string;
}

export function useAchievements(completedLessons: Record<string, boolean>) {
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>([]);
  const [quizScores, setQuizScores] = useState<Record<number, QuizScore>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [newAchievement, setNewAchievement] = useState<Achievement | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      checkForNewAchievements();
    }
  }, [completedLessons, quizScores, isLoading]);

  const loadData = async () => {
    try {
      const [achievementsData, quizData] = await Promise.all([
        AsyncStorage.getItem(ACHIEVEMENTS_KEY),
        AsyncStorage.getItem(QUIZ_SCORES_KEY)
      ]);
      
      if (achievementsData) {
        setUnlockedAchievements(JSON.parse(achievementsData));
      }
      if (quizData) {
        setQuizScores(JSON.parse(quizData));
      }
    } catch (error) {
      console.error("Error loading achievements:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveAchievements = async (newAchievements: string[]) => {
    try {
      await AsyncStorage.setItem(ACHIEVEMENTS_KEY, JSON.stringify(newAchievements));
    } catch (error) {
      console.error("Error saving achievements:", error);
    }
  };

  const saveQuizScore = async (moduleId: number, score: number, passed: boolean) => {
    const newScore: QuizScore = {
      moduleId,
      score,
      passed,
      completedAt: new Date().toISOString()
    };

    const updated = { ...quizScores, [moduleId]: newScore };
    setQuizScores(updated);

    try {
      await AsyncStorage.setItem(QUIZ_SCORES_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error("Error saving quiz score:", error);
    }
  };

  const checkForNewAchievements = useCallback(() => {
    const completedCount = Object.keys(completedLessons).length;
    const passedQuizCount = Object.values(quizScores).filter(q => q.passed).length;
    const totalLessons = getTotalLessons();

    const newlyUnlocked: string[] = [];

    achievements.forEach(achievement => {
      if (unlockedAchievements.includes(achievement.id)) return;

      let isUnlocked = false;

      switch (achievement.requirement.type) {
        case "lessons_complete":
          isUnlocked = completedCount >= (achievement.requirement.value ?? 0);
          break;

        case "module_complete":
          const module = trainingModules.find(m => m.id === achievement.requirement.moduleId);
          if (module) {
            const moduleComplete = module.lessons.every(l => completedLessons[l.id]);
            isUnlocked = moduleComplete;
          }
          break;

        case "quiz_passed":
          isUnlocked = passedQuizCount >= (achievement.requirement.value ?? 0);
          break;

        case "all_complete":
          const allLessonsComplete = completedCount >= totalLessons;
          const allQuizzesPassed = passedQuizCount >= 7;
          isUnlocked = allLessonsComplete && allQuizzesPassed;
          break;
      }

      if (isUnlocked) {
        newlyUnlocked.push(achievement.id);
      }
    });

    if (newlyUnlocked.length > 0) {
      const updated = [...unlockedAchievements, ...newlyUnlocked];
      setUnlockedAchievements(updated);
      saveAchievements(updated);
      
      const firstNew = achievements.find(a => a.id === newlyUnlocked[0]);
      if (firstNew) {
        setNewAchievement(firstNew);
      }
    }
  }, [completedLessons, quizScores, unlockedAchievements]);

  const dismissNewAchievement = useCallback(() => {
    setNewAchievement(null);
  }, []);

  const getAchievementProgress = useCallback((achievement: Achievement): number => {
    const completedCount = Object.keys(completedLessons).length;
    const passedQuizCount = Object.values(quizScores).filter(q => q.passed).length;
    const totalLessons = getTotalLessons();

    switch (achievement.requirement.type) {
      case "lessons_complete":
        return Math.min(completedCount / (achievement.requirement.value ?? 1), 1);

      case "module_complete":
        const module = trainingModules.find(m => m.id === achievement.requirement.moduleId);
        if (module) {
          const completed = module.lessons.filter(l => completedLessons[l.id]).length;
          return completed / module.lessons.length;
        }
        return 0;

      case "quiz_passed":
        return Math.min(passedQuizCount / (achievement.requirement.value ?? 1), 1);

      case "all_complete":
        const lessonProgress = completedCount / totalLessons;
        const quizProgress = passedQuizCount / 7;
        return (lessonProgress + quizProgress) / 2;
    }
  }, [completedLessons, quizScores]);

  const isAchievementUnlocked = useCallback((achievementId: string): boolean => {
    return unlockedAchievements.includes(achievementId);
  }, [unlockedAchievements]);

  const getQuizScore = useCallback((moduleId: number): QuizScore | undefined => {
    return quizScores[moduleId];
  }, [quizScores]);

  return {
    achievements,
    unlockedAchievements,
    quizScores,
    newAchievement,
    isLoading,
    saveQuizScore,
    dismissNewAchievement,
    getAchievementProgress,
    isAchievementUnlocked,
    getQuizScore
  };
}
