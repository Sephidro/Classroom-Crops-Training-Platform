import { useState, useEffect, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { trainingModules, getTotalLessons } from "@/data/trainingData";

const STORAGE_KEYS = {
  COMPLETED_LESSONS: "@training_completed_lessons",
  BOOKMARKED_LESSONS: "@training_bookmarked_lessons",
  CURRENT_LESSON: "@training_current_lesson",
  RECENT_LESSONS: "@training_recent_lessons",
};

export interface CurrentLesson {
  lessonId: string;
  moduleId: number;
  lessonTitle: string;
  moduleTitle: string;
}

export function useProgress() {
  const [completedLessons, setCompletedLessons] = useState<Record<string, boolean>>({});
  const [bookmarkedLessons, setBookmarkedLessons] = useState<string[]>([]);
  const [currentLesson, setCurrentLesson] = useState<CurrentLesson | null>(null);
  const [recentLessons, setRecentLessons] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadProgress();
  }, []);

  const loadProgress = async () => {
    try {
      const [completedData, bookmarkedData, currentData, recentData] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.COMPLETED_LESSONS),
        AsyncStorage.getItem(STORAGE_KEYS.BOOKMARKED_LESSONS),
        AsyncStorage.getItem(STORAGE_KEYS.CURRENT_LESSON),
        AsyncStorage.getItem(STORAGE_KEYS.RECENT_LESSONS),
      ]);

      if (completedData) {
        setCompletedLessons(JSON.parse(completedData));
      }
      if (bookmarkedData) {
        setBookmarkedLessons(JSON.parse(bookmarkedData));
      }
      if (currentData) {
        setCurrentLesson(JSON.parse(currentData));
      }
      if (recentData) {
        setRecentLessons(JSON.parse(recentData));
      }
    } catch (error) {
      console.error("Error loading progress:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const markLessonComplete = useCallback(async (lessonId: string) => {
    try {
      const newCompleted = { ...completedLessons, [lessonId]: true };
      setCompletedLessons(newCompleted);
      await AsyncStorage.setItem(STORAGE_KEYS.COMPLETED_LESSONS, JSON.stringify(newCompleted));
    } catch (error) {
      console.error("Error marking lesson complete:", error);
    }
  }, [completedLessons]);

  const markLessonIncomplete = useCallback(async (lessonId: string) => {
    try {
      const newCompleted = { ...completedLessons };
      delete newCompleted[lessonId];
      setCompletedLessons(newCompleted);
      await AsyncStorage.setItem(STORAGE_KEYS.COMPLETED_LESSONS, JSON.stringify(newCompleted));
    } catch (error) {
      console.error("Error marking lesson incomplete:", error);
    }
  }, [completedLessons]);

  const toggleBookmark = useCallback(async (lessonId: string) => {
    try {
      let newBookmarked: string[];
      if (bookmarkedLessons.includes(lessonId)) {
        newBookmarked = bookmarkedLessons.filter((id) => id !== lessonId);
      } else {
        newBookmarked = [...bookmarkedLessons, lessonId];
      }
      setBookmarkedLessons(newBookmarked);
      await AsyncStorage.setItem(STORAGE_KEYS.BOOKMARKED_LESSONS, JSON.stringify(newBookmarked));
    } catch (error) {
      console.error("Error toggling bookmark:", error);
    }
  }, [bookmarkedLessons]);

  const setCurrentLessonData = useCallback(async (lesson: CurrentLesson | null) => {
    try {
      setCurrentLesson(lesson);
      if (lesson) {
        await AsyncStorage.setItem(STORAGE_KEYS.CURRENT_LESSON, JSON.stringify(lesson));
        
        // Add to recent lessons
        const newRecent = [lesson.lessonId, ...recentLessons.filter((id) => id !== lesson.lessonId)].slice(0, 10);
        setRecentLessons(newRecent);
        await AsyncStorage.setItem(STORAGE_KEYS.RECENT_LESSONS, JSON.stringify(newRecent));
      } else {
        await AsyncStorage.removeItem(STORAGE_KEYS.CURRENT_LESSON);
      }
    } catch (error) {
      console.error("Error setting current lesson:", error);
    }
  }, [recentLessons]);

  const calculateProgress = useCallback((): number => {
    const totalLessons = getTotalLessons();
    const completed = Object.keys(completedLessons).length;
    return Math.round((completed / totalLessons) * 100);
  }, [completedLessons]);

  const getModuleProgress = useCallback((moduleId: number): { completed: number; total: number } => {
    const module = trainingModules.find((m) => m.id === moduleId);
    if (!module) return { completed: 0, total: 0 };
    
    const completed = module.lessons.filter((lesson) => completedLessons[lesson.id]).length;
    return { completed, total: module.lessons.length };
  }, [completedLessons]);

  const isLessonComplete = useCallback((lessonId: string): boolean => {
    return !!completedLessons[lessonId];
  }, [completedLessons]);

  const isLessonBookmarked = useCallback((lessonId: string): boolean => {
    return bookmarkedLessons.includes(lessonId);
  }, [bookmarkedLessons]);

  const getNextLesson = useCallback((): CurrentLesson | null => {
    for (const module of trainingModules) {
      for (const lesson of module.lessons) {
        if (!completedLessons[lesson.id]) {
          return {
            lessonId: lesson.id,
            moduleId: module.id,
            lessonTitle: lesson.title,
            moduleTitle: module.title,
          };
        }
      }
    }
    return null;
  }, [completedLessons]);

  return {
    completedLessons,
    bookmarkedLessons,
    currentLesson,
    recentLessons,
    isLoading,
    markLessonComplete,
    markLessonIncomplete,
    toggleBookmark,
    setCurrentLessonData,
    calculateProgress,
    getModuleProgress,
    isLessonComplete,
    isLessonBookmarked,
    getNextLesson,
  };
}
