import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Lesson, getLessonTypeIcon, getModuleColor } from "@/data/trainingData";

interface LessonRowProps {
  lesson: Lesson;
  moduleId: number;
  isComplete: boolean;
  isBookmarked?: boolean;
  showModuleColor?: boolean;
  onPress: () => void;
}

export function LessonRow({
  lesson,
  moduleId,
  isComplete,
  isBookmarked = false,
  showModuleColor = false,
  onPress,
}: LessonRowProps) {
  const { theme } = useTheme();
  const moduleColor = getModuleColor(moduleId);

  return (
    <Pressable
      style={({ pressed }) => [
        styles.container,
        { backgroundColor: pressed ? theme.backgroundSecondary : theme.backgroundDefault },
      ]}
      onPress={onPress}
    >
      {showModuleColor ? (
        <View style={[styles.colorIndicator, { backgroundColor: moduleColor }]} />
      ) : null}
      <View style={[styles.iconContainer, { backgroundColor: moduleColor + "15" }]}>
        <Feather
          name={getLessonTypeIcon(lesson.type) as any}
          size={18}
          color={moduleColor}
        />
      </View>
      <View style={styles.content}>
        <ThemedText
          style={[styles.title, isComplete && { color: theme.textSecondary }]}
          numberOfLines={2}
        >
          {lesson.title}
        </ThemedText>
        <ThemedText style={[styles.duration, { color: theme.textTertiary }]}>
          {lesson.duration}
        </ThemedText>
      </View>
      <View style={styles.rightSection}>
        {isBookmarked ? (
          <Feather name="bookmark" size={16} color={theme.textTertiary} style={styles.bookmarkIcon} />
        ) : null}
        {isComplete ? (
          <View style={[styles.checkCircle, { backgroundColor: moduleColor }]}>
            <Feather name="check" size={12} color="#FFFFFF" />
          </View>
        ) : (
          <Feather name="chevron-right" size={18} color={theme.textTertiary} />
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.sm,
  },
  colorIndicator: {
    width: 3,
    height: 40,
    borderRadius: 2,
    marginRight: Spacing.md,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.xs,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  title: {
    fontSize: 15,
    lineHeight: 20,
    marginBottom: 2,
  },
  duration: {
    fontSize: 12,
  },
  rightSection: {
    flexDirection: "row",
    alignItems: "center",
  },
  bookmarkIcon: {
    marginRight: Spacing.sm,
  },
  checkCircle: {
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: "center",
    alignItems: "center",
  },
});
