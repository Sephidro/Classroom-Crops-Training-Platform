import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  WithSpringConfig,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, BrandColors, Shadows } from "@/constants/theme";
import { CurrentLesson } from "@/hooks/useProgress";
import { getModuleColor } from "@/data/trainingData";

interface ContinueLearningCardProps {
  lesson: CurrentLesson;
  onPress: () => void;
}

const springConfig: WithSpringConfig = {
  damping: 15,
  mass: 0.3,
  stiffness: 150,
  overshootClamping: true,
};

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function ContinueLearningCard({ lesson, onPress }: ContinueLearningCardProps) {
  const { theme } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.98, springConfig);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, springConfig);
  };

  const moduleColor = getModuleColor(lesson.moduleId);

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[
        styles.container,
        { backgroundColor: theme.backgroundDefault },
        Shadows.card,
        animatedStyle,
      ]}
    >
      <View style={[styles.accentBar, { backgroundColor: moduleColor }]} />
      <View style={styles.content}>
        <View style={styles.labelRow}>
          <Feather name="play-circle" size={16} color={BrandColors.primary} />
          <ThemedText style={[styles.label, { color: BrandColors.primary }]}>
            Continue Learning
          </ThemedText>
        </View>
        <ThemedText style={[styles.title, { fontFamily: "Nunito_600SemiBold" }]} numberOfLines={2}>
          {lesson.lessonTitle}
        </ThemedText>
        <ThemedText style={[styles.moduleName, { color: theme.textSecondary }]} numberOfLines={1}>
          {lesson.moduleTitle}
        </ThemedText>
      </View>
      <View style={[styles.playButton, { backgroundColor: BrandColors.primary }]}>
        <Feather name="play" size={20} color="#FFFFFF" />
      </View>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: BorderRadius.md,
    overflow: "hidden",
    marginBottom: Spacing.lg,
  },
  accentBar: {
    width: 4,
    alignSelf: "stretch",
  },
  content: {
    flex: 1,
    padding: Spacing.lg,
  },
  labelRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.xs,
  },
  label: {
    fontSize: 12,
    fontWeight: "600",
    marginLeft: 6,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  title: {
    fontSize: 16,
    lineHeight: 22,
    marginBottom: 4,
  },
  moduleName: {
    fontSize: 13,
  },
  playButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.lg,
  },
});
