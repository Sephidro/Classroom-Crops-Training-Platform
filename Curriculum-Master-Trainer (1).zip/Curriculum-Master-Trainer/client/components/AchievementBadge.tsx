import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import Animated, { FadeIn, useAnimatedStyle, withSpring } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Achievement } from "@/data/achievements";

interface AchievementBadgeProps {
  achievement: Achievement;
  isUnlocked: boolean;
  progress?: number;
  onPress?: () => void;
  compact?: boolean;
}

export function AchievementBadge({
  achievement,
  isUnlocked,
  progress = 0,
  onPress,
  compact = false,
}: AchievementBadgeProps) {
  const { theme } = useTheme();

  if (compact) {
    return (
      <Pressable
        style={({ pressed }) => [
          styles.compactContainer,
          { 
            backgroundColor: isUnlocked ? achievement.color + "15" : theme.backgroundSecondary,
            opacity: pressed ? 0.8 : 1
          }
        ]}
        onPress={onPress}
      >
        <View style={[
          styles.compactIcon,
          { backgroundColor: isUnlocked ? achievement.color : theme.textTertiary }
        ]}>
          <Feather 
            name={achievement.icon as any} 
            size={16} 
            color="#FFFFFF" 
          />
        </View>
        <ThemedText 
          style={[
            styles.compactTitle, 
            { color: isUnlocked ? achievement.color : theme.textTertiary }
          ]}
          numberOfLines={1}
        >
          {achievement.title}
        </ThemedText>
      </Pressable>
    );
  }

  return (
    <Animated.View entering={FadeIn}>
      <Pressable
        style={({ pressed }) => [
          styles.container,
          { 
            backgroundColor: theme.backgroundDefault,
            borderColor: isUnlocked ? achievement.color : theme.border,
            opacity: pressed ? 0.9 : 1
          }
        ]}
        onPress={onPress}
        disabled={!onPress}
      >
        <View style={[
          styles.iconContainer,
          { 
            backgroundColor: isUnlocked ? achievement.color : theme.backgroundSecondary,
          }
        ]}>
          <Feather 
            name={achievement.icon as any} 
            size={28} 
            color={isUnlocked ? "#FFFFFF" : theme.textTertiary} 
          />
          {!isUnlocked && progress > 0 && (
            <View style={styles.progressOverlay}>
              <View style={[styles.progressCircle, { borderColor: theme.textTertiary }]}>
                <ThemedText style={[styles.progressText, { color: theme.textTertiary }]}>
                  {Math.round(progress * 100)}%
                </ThemedText>
              </View>
            </View>
          )}
        </View>
        
        <View style={styles.content}>
          <ThemedText 
            style={[
              styles.title, 
              { 
                fontFamily: "Nunito_600SemiBold",
                color: isUnlocked ? theme.text : theme.textSecondary 
              }
            ]}
          >
            {achievement.title}
          </ThemedText>
          <ThemedText 
            style={[
              styles.description, 
              { color: isUnlocked ? theme.textSecondary : theme.textTertiary }
            ]}
          >
            {achievement.description}
          </ThemedText>
        </View>

        {isUnlocked && (
          <Feather name="check-circle" size={20} color={achievement.color} />
        )}
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.md,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },
  progressOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
  },
  progressCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.9)",
  },
  progressText: {
    fontSize: 11,
    fontWeight: "600",
  },
  content: {
    flex: 1,
    marginLeft: Spacing.lg,
  },
  title: {
    fontSize: 16,
    marginBottom: 2,
  },
  description: {
    fontSize: 13,
    lineHeight: 18,
  },
  compactContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.sm,
    marginRight: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  compactIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.sm,
  },
  compactTitle: {
    fontSize: 13,
    fontWeight: "500",
  },
});
