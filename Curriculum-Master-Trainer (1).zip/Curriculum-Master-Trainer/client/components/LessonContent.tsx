import React from "react";
import { View, StyleSheet, ScrollView } from "react-native";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { LessonContent as LessonContentType } from "@/data/trainingData";
import { LessonTab } from "@/components/LessonTabBar";

interface LessonContentProps {
  content: LessonContentType;
  activeTab: LessonTab;
}

export function LessonContent({ content, activeTab }: LessonContentProps) {
  const { theme } = useTheme();

  const renderOverview = () => (
    <View style={styles.section}>
      <ThemedText style={[styles.overviewText, { lineHeight: 26 }]}>
        {content.overview}
      </ThemedText>
      
      <View style={[styles.keyPointsCard, { backgroundColor: BrandColors.primary + "10" }]}>
        <ThemedText style={[styles.sectionTitle, { color: BrandColors.primary, fontFamily: "Nunito_600SemiBold" }]}>
          Key Points
        </ThemedText>
        {content.keyPoints.map((point, index) => (
          <View key={index} style={styles.keyPointRow}>
            <View style={[styles.bullet, { backgroundColor: BrandColors.primary }]} />
            <ThemedText style={styles.keyPointText}>{point}</ThemedText>
          </View>
        ))}
      </View>
    </View>
  );

  const renderDetailedContent = () => {
    const paragraphs = content.detailedContent.split("\n\n");
    
    return (
      <View style={styles.section}>
        {paragraphs.map((paragraph, index) => {
          const isBold = paragraph.startsWith("**") && paragraph.includes(":**");
          const isSubheading = paragraph.startsWith("**") && paragraph.endsWith("**");
          
          if (isSubheading) {
            return (
              <ThemedText
                key={index}
                style={[styles.subheading, { fontFamily: "Nunito_600SemiBold" }]}
              >
                {paragraph.replace(/\*\*/g, "")}
              </ThemedText>
            );
          }
          
          if (isBold) {
            const [title, ...rest] = paragraph.split(":");
            return (
              <View key={index} style={styles.contentBlock}>
                <ThemedText style={[styles.blockTitle, { fontFamily: "Nunito_600SemiBold" }]}>
                  {title.replace(/\*\*/g, "")}:
                </ThemedText>
                <ThemedText style={styles.contentText}>
                  {rest.join(":").trim()}
                </ThemedText>
              </View>
            );
          }
          
          return (
            <ThemedText key={index} style={styles.contentText}>
              {paragraph.replace(/\*\*/g, "")}
            </ThemedText>
          );
        })}
      </View>
    );
  };

  const renderPractice = () => {
    const paragraphs = content.practiceActivity.split("\n\n");
    
    return (
      <View style={styles.section}>
        <View style={[styles.practiceCard, { backgroundColor: BrandColors.accent + "15", borderColor: BrandColors.accent }]}>
          <View style={styles.practiceHeader}>
            <Feather name="edit-3" size={20} color={BrandColors.accent} />
            <ThemedText style={[styles.practiceTitle, { color: BrandColors.accent, fontFamily: "Nunito_600SemiBold" }]}>
              Practice Activity
            </ThemedText>
          </View>
          {paragraphs.map((paragraph, index) => {
            if (paragraph.startsWith("**") && paragraph.includes(":**")) {
              const [title, ...rest] = paragraph.split(":");
              return (
                <View key={index} style={styles.practiceBlock}>
                  <ThemedText style={[styles.blockTitle, { fontFamily: "Nunito_600SemiBold" }]}>
                    {title.replace(/\*\*/g, "")}:
                  </ThemedText>
                  <ThemedText style={styles.practiceText}>
                    {rest.join(":").trim()}
                  </ThemedText>
                </View>
              );
            }
            return (
              <ThemedText key={index} style={styles.practiceText}>
                {paragraph.replace(/\*\*/g, "")}
              </ThemedText>
            );
          })}
        </View>
      </View>
    );
  };

  const renderTips = () => (
    <View style={styles.section}>
      <View style={[styles.tipsCard, { backgroundColor: BrandColors.success + "10" }]}>
        <View style={styles.tipsHeader}>
          <Feather name="check-circle" size={20} color={BrandColors.success} />
          <ThemedText style={[styles.tipsTitle, { color: BrandColors.success, fontFamily: "Nunito_600SemiBold" }]}>
            Teaching Tips
          </ThemedText>
        </View>
        {content.teachingTips.map((tip, index) => (
          <View key={index} style={styles.tipRow}>
            <Feather name="check" size={16} color={BrandColors.success} style={styles.tipIcon} />
            <ThemedText style={styles.tipText}>{tip}</ThemedText>
          </View>
        ))}
      </View>

      <View style={[styles.mistakesCard, { backgroundColor: BrandColors.error + "10" }]}>
        <View style={styles.tipsHeader}>
          <Feather name="alert-circle" size={20} color={BrandColors.error} />
          <ThemedText style={[styles.tipsTitle, { color: BrandColors.error, fontFamily: "Nunito_600SemiBold" }]}>
            Common Mistakes to Avoid
          </ThemedText>
        </View>
        {content.commonMistakes.map((mistake, index) => (
          <View key={index} style={styles.tipRow}>
            <Feather name="x" size={16} color={BrandColors.error} style={styles.tipIcon} />
            <ThemedText style={styles.tipText}>{mistake}</ThemedText>
          </View>
        ))}
      </View>
    </View>
  );

  const renderContent = () => {
    switch (activeTab) {
      case "overview":
        return renderOverview();
      case "content":
        return renderDetailedContent();
      case "practice":
        return renderPractice();
      case "tips":
        return renderTips();
      default:
        return renderOverview();
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={false}
    >
      {renderContent()}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
    paddingBottom: Spacing["3xl"],
  },
  section: {
    gap: Spacing.lg,
  },
  overviewText: {
    fontSize: 16,
    lineHeight: 26,
  },
  keyPointsCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  sectionTitle: {
    fontSize: 16,
    marginBottom: Spacing.md,
  },
  keyPointRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: Spacing.sm,
  },
  bullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginTop: 8,
    marginRight: Spacing.md,
  },
  keyPointText: {
    flex: 1,
    fontSize: 15,
    lineHeight: 22,
  },
  subheading: {
    fontSize: 18,
    marginTop: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  contentBlock: {
    marginBottom: Spacing.md,
  },
  blockTitle: {
    fontSize: 15,
    marginBottom: 4,
  },
  contentText: {
    fontSize: 15,
    lineHeight: 24,
    marginBottom: Spacing.md,
  },
  practiceCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  practiceHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  practiceTitle: {
    fontSize: 16,
    marginLeft: Spacing.sm,
  },
  practiceBlock: {
    marginBottom: Spacing.md,
  },
  practiceText: {
    fontSize: 15,
    lineHeight: 24,
    marginBottom: Spacing.sm,
  },
  tipsCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  mistakesCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  tipsHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  tipsTitle: {
    fontSize: 16,
    marginLeft: Spacing.sm,
  },
  tipRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: Spacing.sm,
  },
  tipIcon: {
    marginTop: 2,
    marginRight: Spacing.sm,
  },
  tipText: {
    flex: 1,
    fontSize: 15,
    lineHeight: 22,
  },
});
