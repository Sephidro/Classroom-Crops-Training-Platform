import React from "react";
import { View, StyleSheet, Pressable, ScrollView } from "react-native";
import Animated, {
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BrandColors } from "@/constants/theme";

export type LessonTab = "overview" | "content" | "practice" | "tips";

interface LessonTabBarProps {
  activeTab: LessonTab;
  onTabChange: (tab: LessonTab) => void;
}

const tabs: { key: LessonTab; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "content", label: "Content" },
  { key: "practice", label: "Practice" },
  { key: "tips", label: "Tips" },
];

export function LessonTabBar({ activeTab, onTabChange }: LessonTabBarProps) {
  const { theme } = useTheme();

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundDefault, borderBottomColor: theme.border }]}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {tabs.map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <Pressable
              key={tab.key}
              style={styles.tab}
              onPress={() => onTabChange(tab.key)}
            >
              <ThemedText
                style={[
                  styles.tabText,
                  { color: isActive ? BrandColors.primary : theme.textSecondary },
                  isActive && styles.activeTabText,
                ]}
              >
                {tab.label}
              </ThemedText>
              {isActive ? (
                <View style={[styles.indicator, { backgroundColor: BrandColors.primary }]} />
              ) : null}
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: 1,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
  },
  tab: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    marginRight: Spacing.sm,
    position: "relative",
  },
  tabText: {
    fontSize: 15,
    fontWeight: "500",
  },
  activeTabText: {
    fontWeight: "600",
  },
  indicator: {
    position: "absolute",
    bottom: 0,
    left: Spacing.lg,
    right: Spacing.lg,
    height: 3,
    borderRadius: 2,
  },
});
