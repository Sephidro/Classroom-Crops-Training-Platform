import React, { useEffect } from "react";
import { View, StyleSheet, Pressable, Dimensions } from "react-native";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
  withSequence,
  runOnJS,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Achievement } from "@/data/achievements";

interface AchievementToastProps {
  achievement: Achievement;
  onDismiss: () => void;
}

const { width: SCREEN_WIDTH } = Dimensions.get("window");

export function AchievementToast({ achievement, onDismiss }: AchievementToastProps) {
  const { theme } = useTheme();
  const translateY = useSharedValue(-150);
  const scale = useSharedValue(0.8);
  const opacity = useSharedValue(0);

  useEffect(() => {
    translateY.value = withSpring(0, { damping: 15 });
    scale.value = withSpring(1, { damping: 12 });
    opacity.value = withTiming(1, { duration: 200 });

    const timeout = setTimeout(() => {
      translateY.value = withTiming(-150, { duration: 300 });
      opacity.value = withTiming(0, { duration: 300 }, () => {
        runOnJS(onDismiss)();
      });
    }, 4000);

    return () => clearTimeout(timeout);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateY: translateY.value },
      { scale: scale.value }
    ],
    opacity: opacity.value,
  }));

  const handleDismiss = () => {
    translateY.value = withTiming(-150, { duration: 200 });
    opacity.value = withTiming(0, { duration: 200 }, () => {
      runOnJS(onDismiss)();
    });
  };

  return (
    <Animated.View style={[styles.container, animatedStyle]}>
      <Pressable
        style={[
          styles.toast,
          { 
            backgroundColor: theme.backgroundDefault,
            borderColor: achievement.color,
          }
        ]}
        onPress={handleDismiss}
      >
        <View style={[styles.iconContainer, { backgroundColor: achievement.color }]}>
          <Feather name={achievement.icon as any} size={24} color="#FFFFFF" />
        </View>
        <View style={styles.content}>
          <ThemedText style={[styles.label, { color: achievement.color }]}>
            Achievement Unlocked!
          </ThemedText>
          <ThemedText style={[styles.title, { fontFamily: "Nunito_600SemiBold" }]}>
            {achievement.title}
          </ThemedText>
          <ThemedText style={[styles.description, { color: theme.textSecondary }]}>
            {achievement.description}
          </ThemedText>
        </View>
        <Pressable style={styles.closeButton} onPress={handleDismiss}>
          <Feather name="x" size={18} color={theme.textTertiary} />
        </Pressable>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    top: 60,
    left: Spacing.lg,
    right: Spacing.lg,
    zIndex: 1000,
  },
  toast: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  label: {
    fontSize: 11,
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  title: {
    fontSize: 16,
    marginBottom: 2,
  },
  description: {
    fontSize: 12,
  },
  closeButton: {
    padding: Spacing.sm,
    marginLeft: Spacing.sm,
  },
});
