import React, { useState, useCallback, useMemo, useEffect } from "react";
import { View, StyleSheet, ScrollView, Pressable, Animated } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { RouteProp, useRoute, useNavigation } from "@react-navigation/native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { getQuizForModule, calculateQuizScore, QuizQuestion } from "@/data/quizData";
import { trainingModules } from "@/data/trainingData";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

const QUIZ_SCORES_KEY = "@classroom_crops:quiz_scores";

type QuizRouteProp = RouteProp<RootStackParamList, "Quiz">;

type QuizState = "intro" | "question" | "result";

export default function QuizScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const route = useRoute<QuizRouteProp>();
  const navigation = useNavigation();
  
  const { moduleId } = route.params;
  const quiz = getQuizForModule(moduleId);
  const module = trainingModules.find(m => m.id === moduleId);

  const [quizState, setQuizState] = useState<QuizState>("intro");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const currentQuestion = quiz?.questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === (quiz?.questions.length ?? 0) - 1;
  
  const result = useMemo(() => {
    if (quizState !== "result") return null;
    return calculateQuizScore(answers, moduleId);
  }, [quizState, answers, moduleId]);

  useEffect(() => {
    if (result && quizState === "result") {
      saveQuizScore(moduleId, result.score, result.passed);
    }
  }, [result, quizState, moduleId]);

  const saveQuizScore = async (modId: number, score: number, passed: boolean) => {
    try {
      const existing = await AsyncStorage.getItem(QUIZ_SCORES_KEY);
      const scores = existing ? JSON.parse(existing) : {};
      
      if (!scores[modId] || scores[modId].score < score) {
        scores[modId] = {
          moduleId: modId,
          score,
          passed,
          completedAt: new Date().toISOString()
        };
        await AsyncStorage.setItem(QUIZ_SCORES_KEY, JSON.stringify(scores));
      }
    } catch (error) {
      console.error("Error saving quiz score:", error);
    }
  };

  const handleStartQuiz = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setQuizState("question");
    setCurrentQuestionIndex(0);
    setAnswers({});
    setSelectedAnswer(null);
    setShowExplanation(false);
  }, []);

  const handleSelectAnswer = useCallback((index: number) => {
    if (showExplanation) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedAnswer(index);
  }, [showExplanation]);

  const handleSubmitAnswer = useCallback(() => {
    if (selectedAnswer === null || !currentQuestion) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: selectedAnswer
    }));
    setShowExplanation(true);
  }, [selectedAnswer, currentQuestion]);

  const handleNextQuestion = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    
    if (isLastQuestion) {
      setQuizState("result");
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    }
  }, [isLastQuestion]);

  const handleRetryQuiz = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    handleStartQuiz();
  }, [handleStartQuiz]);

  if (!quiz || !module) {
    return (
      <ThemedView style={[styles.container, { paddingTop: headerHeight }]}>
        <View style={styles.centerContent}>
          <ThemedText>Quiz not found for this module.</ThemedText>
          <Button onPress={() => navigation.goBack()} style={styles.backButton}>
            Go Back
          </Button>
        </View>
      </ThemedView>
    );
  }

  if (quizState === "intro") {
    return (
      <ThemedView style={styles.container}>
        <ScrollView 
          contentContainerStyle={[
            styles.scrollContent, 
            { paddingTop: headerHeight + Spacing.xl, paddingBottom: insets.bottom + Spacing.xl }
          ]}
        >
          <View style={[styles.quizIcon, { backgroundColor: module.color + "20" }]}>
            <Feather name="help-circle" size={48} color={module.color} />
          </View>
          
          <ThemedText style={[styles.quizTitle, { fontFamily: "Nunito_700Bold" }]}>
            {quiz.title}
          </ThemedText>
          
          <ThemedText style={[styles.moduleLabel, { color: module.color }]}>
            Module {moduleId}: {module.title}
          </ThemedText>

          <View style={[styles.infoCard, { backgroundColor: theme.backgroundSecondary }]}>
            <View style={styles.infoRow}>
              <Feather name="list" size={20} color={theme.textSecondary} />
              <ThemedText style={styles.infoText}>
                {quiz.questions.length} Questions
              </ThemedText>
            </View>
            <View style={styles.infoRow}>
              <Feather name="target" size={20} color={theme.textSecondary} />
              <ThemedText style={styles.infoText}>
                {quiz.passingScore}% to pass
              </ThemedText>
            </View>
            <View style={styles.infoRow}>
              <Feather name="clock" size={20} color={theme.textSecondary} />
              <ThemedText style={styles.infoText}>
                ~{Math.ceil(quiz.questions.length * 0.75)} minutes
              </ThemedText>
            </View>
          </View>

          <ThemedText style={[styles.instructions, { color: theme.textSecondary }]}>
            Test your understanding of the concepts covered in this module. 
            You'll see explanations after each answer to reinforce your learning.
          </ThemedText>

          <Button onPress={handleStartQuiz} style={styles.startButton}>
            Start Quiz
          </Button>
          
          <Pressable 
            style={styles.backLink} 
            onPress={() => navigation.goBack()}
          >
            <ThemedText style={[styles.backLinkText, { color: theme.textSecondary }]}>
              Back to Training
            </ThemedText>
          </Pressable>
        </ScrollView>
      </ThemedView>
    );
  }

  if (quizState === "result") {
    const passed = result?.passed ?? false;
    const resultColor = passed ? BrandColors.success : BrandColors.error;
    
    return (
      <ThemedView style={styles.container}>
        <ScrollView 
          contentContainerStyle={[
            styles.scrollContent, 
            { paddingTop: headerHeight + Spacing.xl, paddingBottom: insets.bottom + Spacing.xl }
          ]}
        >
          <View style={[styles.resultIcon, { backgroundColor: resultColor + "20" }]}>
            <Feather 
              name={passed ? "award" : "refresh-cw"} 
              size={48} 
              color={resultColor} 
            />
          </View>
          
          <ThemedText style={[styles.resultTitle, { fontFamily: "Nunito_700Bold" }]}>
            {passed ? "Congratulations!" : "Keep Learning!"}
          </ThemedText>
          
          <ThemedText style={[styles.resultSubtitle, { color: theme.textSecondary }]}>
            {passed 
              ? "You've demonstrated mastery of this module's content."
              : "Review the lesson content and try again."
            }
          </ThemedText>

          <View style={[styles.scoreCard, { backgroundColor: theme.backgroundSecondary }]}>
            <ThemedText style={[styles.scoreLabel, { color: theme.textSecondary }]}>
              Your Score
            </ThemedText>
            <ThemedText style={[styles.scoreValue, { color: resultColor, fontFamily: "Nunito_700Bold" }]}>
              {result?.score}%
            </ThemedText>
            <ThemedText style={[styles.scoreDetail, { color: theme.textSecondary }]}>
              {result?.correct} of {result?.total} correct
            </ThemedText>
            <View style={[styles.passingBar, { backgroundColor: theme.border }]}>
              <View 
                style={[
                  styles.passingProgress, 
                  { 
                    width: `${Math.min(result?.score ?? 0, 100)}%`,
                    backgroundColor: resultColor 
                  }
                ]} 
              />
              <View 
                style={[
                  styles.passingMarker, 
                  { left: `${quiz.passingScore}%` }
                ]} 
              />
            </View>
            <ThemedText style={[styles.passingLabel, { color: theme.textTertiary }]}>
              {quiz.passingScore}% required to pass
            </ThemedText>
          </View>

          {passed ? (
            <Button onPress={() => navigation.goBack()} style={styles.actionButton}>
              Continue Training
            </Button>
          ) : (
            <>
              <Button onPress={handleRetryQuiz} style={styles.actionButton}>
                Try Again
              </Button>
              <Pressable 
                style={styles.backLink} 
                onPress={() => navigation.goBack()}
              >
                <ThemedText style={[styles.backLinkText, { color: theme.textSecondary }]}>
                  Review Lesson Content
                </ThemedText>
              </Pressable>
            </>
          )}
        </ScrollView>
      </ThemedView>
    );
  }

  const isCorrect = showExplanation && selectedAnswer === currentQuestion?.correctIndex;
  const isIncorrect = showExplanation && selectedAnswer !== currentQuestion?.correctIndex;

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.progressHeader, { paddingTop: headerHeight + Spacing.md }]}>
        <View style={styles.progressInfo}>
          <ThemedText style={[styles.questionCount, { color: theme.textSecondary }]}>
            Question {currentQuestionIndex + 1} of {quiz.questions.length}
          </ThemedText>
        </View>
        <View style={[styles.progressBar, { backgroundColor: theme.backgroundSecondary }]}>
          <View 
            style={[
              styles.progressFill, 
              { 
                width: `${((currentQuestionIndex + 1) / quiz.questions.length) * 100}%`,
                backgroundColor: module.color 
              }
            ]} 
          />
        </View>
      </View>

      <ScrollView 
        contentContainerStyle={[styles.questionContent, { paddingBottom: insets.bottom + 100 }]}
      >
        <ThemedText style={[styles.questionText, { fontFamily: "Nunito_600SemiBold" }]}>
          {currentQuestion?.question}
        </ThemedText>

        <View style={styles.optionsContainer}>
          {currentQuestion?.options.map((option, index) => {
            const isSelected = selectedAnswer === index;
            const isThisCorrect = showExplanation && index === currentQuestion.correctIndex;
            const isThisWrong = showExplanation && isSelected && index !== currentQuestion.correctIndex;
            
            let optionStyle = [styles.optionButton, { borderColor: theme.border }];
            let optionTextColor = theme.text;
            
            if (isThisCorrect) {
              optionStyle = [styles.optionButton, styles.optionCorrect];
              optionTextColor = BrandColors.success;
            } else if (isThisWrong) {
              optionStyle = [styles.optionButton, styles.optionIncorrect];
              optionTextColor = BrandColors.error;
            } else if (isSelected && !showExplanation) {
              optionStyle = [styles.optionButton, { borderColor: module.color, borderWidth: 2 }];
              optionTextColor = module.color;
            }

            return (
              <Pressable
                key={index}
                style={optionStyle}
                onPress={() => handleSelectAnswer(index)}
                disabled={showExplanation}
              >
                <View style={[
                  styles.optionIndicator,
                  { 
                    backgroundColor: isThisCorrect ? BrandColors.success : 
                      isThisWrong ? BrandColors.error :
                      isSelected ? module.color : theme.backgroundSecondary,
                    borderColor: isThisCorrect ? BrandColors.success : 
                      isThisWrong ? BrandColors.error :
                      isSelected ? module.color : theme.border
                  }
                ]}>
                  {(isThisCorrect || (isSelected && !showExplanation)) && (
                    <Feather 
                      name={isThisCorrect ? "check" : ""} 
                      size={14} 
                      color="#FFFFFF" 
                    />
                  )}
                  {isThisWrong && (
                    <Feather name="x" size={14} color="#FFFFFF" />
                  )}
                </View>
                <ThemedText style={[styles.optionText, { color: optionTextColor }]}>
                  {option}
                </ThemedText>
              </Pressable>
            );
          })}
        </View>

        {showExplanation && (
          <View style={[
            styles.explanationCard,
            { 
              backgroundColor: isCorrect ? BrandColors.success + "15" : BrandColors.error + "15",
              borderColor: isCorrect ? BrandColors.success : BrandColors.error
            }
          ]}>
            <View style={styles.explanationHeader}>
              <Feather 
                name={isCorrect ? "check-circle" : "info"} 
                size={20} 
                color={isCorrect ? BrandColors.success : BrandColors.error} 
              />
              <ThemedText style={[
                styles.explanationTitle, 
                { color: isCorrect ? BrandColors.success : BrandColors.error, fontFamily: "Nunito_600SemiBold" }
              ]}>
                {isCorrect ? "Correct!" : "Not quite right"}
              </ThemedText>
            </View>
            <ThemedText style={[styles.explanationText, { color: theme.text }]}>
              {currentQuestion?.explanation}
            </ThemedText>
          </View>
        )}
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: theme.backgroundDefault, paddingBottom: insets.bottom + Spacing.md }]}>
        {!showExplanation ? (
          <Button 
            onPress={handleSubmitAnswer} 
            disabled={selectedAnswer === null}
            style={[styles.footerButton, selectedAnswer === null && styles.footerButtonDisabled]}
          >
            Check Answer
          </Button>
        ) : (
          <Button onPress={handleNextQuestion} style={styles.footerButton}>
            {isLastQuestion ? "See Results" : "Next Question"}
          </Button>
        )}
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centerContent: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing.xl,
  },
  scrollContent: {
    padding: Spacing.xl,
    alignItems: "center",
  },
  backButton: {
    marginTop: Spacing.lg,
  },
  quizIcon: {
    width: 96,
    height: 96,
    borderRadius: 48,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  quizTitle: {
    fontSize: 28,
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  moduleLabel: {
    fontSize: 14,
    fontWeight: "600",
    marginBottom: Spacing.xl,
  },
  infoCard: {
    width: "100%",
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
  },
  infoText: {
    marginLeft: Spacing.md,
    fontSize: 16,
  },
  instructions: {
    fontSize: 15,
    textAlign: "center",
    lineHeight: 22,
    marginBottom: Spacing.xl,
  },
  startButton: {
    width: "100%",
    marginBottom: Spacing.lg,
  },
  backLink: {
    padding: Spacing.md,
  },
  backLinkText: {
    fontSize: 15,
  },
  progressHeader: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  progressInfo: {
    marginBottom: Spacing.sm,
  },
  questionCount: {
    fontSize: 14,
    fontWeight: "500",
  },
  progressBar: {
    height: 4,
    borderRadius: 2,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 2,
  },
  questionContent: {
    padding: Spacing.xl,
  },
  questionText: {
    fontSize: 20,
    lineHeight: 28,
    marginBottom: Spacing.xl,
  },
  optionsContainer: {
    gap: Spacing.md,
  },
  optionButton: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  optionCorrect: {
    borderColor: BrandColors.success,
    borderWidth: 2,
    backgroundColor: BrandColors.success + "10",
  },
  optionIncorrect: {
    borderColor: BrandColors.error,
    borderWidth: 2,
    backgroundColor: BrandColors.error + "10",
  },
  optionIndicator: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.md,
  },
  optionText: {
    flex: 1,
    fontSize: 16,
    lineHeight: 22,
  },
  explanationCard: {
    marginTop: Spacing.xl,
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  explanationHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  explanationTitle: {
    fontSize: 16,
    marginLeft: Spacing.sm,
  },
  explanationText: {
    fontSize: 15,
    lineHeight: 22,
  },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: "rgba(0,0,0,0.08)",
  },
  footerButton: {
    width: "100%",
  },
  footerButtonDisabled: {
    opacity: 0.5,
  },
  resultIcon: {
    width: 96,
    height: 96,
    borderRadius: 48,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  resultTitle: {
    fontSize: 28,
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  resultSubtitle: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  scoreCard: {
    width: "100%",
    borderRadius: BorderRadius.md,
    padding: Spacing.xl,
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  scoreLabel: {
    fontSize: 14,
    marginBottom: Spacing.xs,
  },
  scoreValue: {
    fontSize: 48,
    marginBottom: Spacing.xs,
  },
  scoreDetail: {
    fontSize: 14,
    marginBottom: Spacing.lg,
  },
  passingBar: {
    width: "100%",
    height: 8,
    borderRadius: 4,
    position: "relative",
    overflow: "visible",
  },
  passingProgress: {
    height: "100%",
    borderRadius: 4,
  },
  passingMarker: {
    position: "absolute",
    top: -4,
    width: 2,
    height: 16,
    backgroundColor: "#333",
    marginLeft: -1,
  },
  passingLabel: {
    fontSize: 12,
    marginTop: Spacing.sm,
  },
  actionButton: {
    width: "100%",
    marginBottom: Spacing.md,
  },
});
