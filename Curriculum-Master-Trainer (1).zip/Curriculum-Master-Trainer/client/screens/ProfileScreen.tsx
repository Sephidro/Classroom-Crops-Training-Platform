import React, { useState, useEffect, useCallback } from "react";
import { View, StyleSheet, Pressable, TextInput, Alert, ActivityIndicator } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";

import { ProfileStackParamList } from "@/navigation/ProfileStackNavigator";

import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { ThemedText } from "@/components/ThemedText";
import { ProgressRing } from "@/components/ProgressRing";
import { AchievementBadge } from "@/components/AchievementBadge";
import { useTheme } from "@/hooks/useTheme";
import { useProgressContext } from "@/context/ProgressContext";
import { useAchievements } from "@/hooks/useAchievements";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { getTotalLessons } from "@/data/trainingData";
import { shareCertificate, printCertificate } from "@/services/certificateGenerator";

const DISPLAY_NAME_KEY = "@training_display_name";

type ProfileNavProp = NativeStackNavigationProp<ProfileStackParamList, "Profile">;

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const navigation = useNavigation<ProfileNavProp>();
  const { theme } = useTheme();
  const { calculateProgress, completedLessons } = useProgressContext();

  const [displayName, setDisplayName] = useState("Teacher");
  const [isEditing, setIsEditing] = useState(false);

  const progress = calculateProgress();
  const completedCount = Object.keys(completedLessons).length;
  const totalLessons = getTotalLessons();

  const {
    achievements,
    unlockedAchievements,
    quizScores,
    isAchievementUnlocked,
    getAchievementProgress
  } = useAchievements(completedLessons);

  const [isGeneratingCert, setIsGeneratingCert] = useState(false);

  const passedQuizCount = Object.values(quizScores).filter(q => q.passed).length;
  const canGetCertificate = completedCount >= totalLessons && passedQuizCount >= 7;

  const handleGetCertificate = useCallback(async () => {
    setIsGeneratingCert(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    try {
      await shareCertificate({
        teacherName: displayName,
        completionDate: new Date().toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric"
        }),
        totalLessons: completedCount,
        quizzesPassed: passedQuizCount
      });
    } catch (error) {
      console.error("Certificate error:", error);
    } finally {
      setIsGeneratingCert(false);
    }
  }, [displayName, completedCount, passedQuizCount]);

  useEffect(() => {
    loadDisplayName();
  }, []);

  const loadDisplayName = async () => {
    try {
      const name = await AsyncStorage.getItem(DISPLAY_NAME_KEY);
      if (name) {
        setDisplayName(name);
      }
    } catch (error) {
      console.error("Error loading display name:", error);
    }
  };

  const saveDisplayName = async (name: string) => {
    try {
      await AsyncStorage.setItem(DISPLAY_NAME_KEY, name);
      setDisplayName(name);
      setIsEditing(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error("Error saving display name:", error);
    }
  };

  const handleResetProgress = () => {
    Alert.alert(
      "Reset Progress",
      "Are you sure you want to reset all your learning progress? This cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Reset",
          style: "destructive",
          onPress: async () => {
            try {
              await AsyncStorage.multiRemove([
                "@training_completed_lessons",
                "@training_bookmarked_lessons",
                "@training_current_lesson",
                "@training_recent_lessons",
              ]);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
              Alert.alert("Progress Reset", "Please restart the app to see the changes.");
            } catch (error) {
              console.error("Error resetting progress:", error);
            }
          },
        },
      ]
    );
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
    >
      <View style={[styles.profileCard, { backgroundColor: theme.backgroundDefault }]}>
        <View style={[styles.avatarContainer, { backgroundColor: BrandColors.primary + "20" }]}>
          <Feather name="user" size={40} color={BrandColors.primary} />
        </View>
        {isEditing ? (
          <View style={styles.editNameContainer}>
            <TextInput
              style={[styles.nameInput, { color: theme.text, borderColor: BrandColors.primary }]}
              value={displayName}
              onChangeText={setDisplayName}
              autoFocus
              onBlur={() => saveDisplayName(displayName)}
              onSubmitEditing={() => saveDisplayName(displayName)}
              returnKeyType="done"
            />
          </View>
        ) : (
          <Pressable onPress={() => setIsEditing(true)} style={styles.nameContainer}>
            <ThemedText style={[styles.displayName, { fontFamily: "Nunito_700Bold" }]}>
              {displayName}
            </ThemedText>
            <Feather name="edit-2" size={16} color={theme.textSecondary} style={styles.editIcon} />
          </Pressable>
        )}
        <ThemedText style={[styles.subtitle, { color: theme.textSecondary }]}>
          Master Teacher in Training
        </ThemedText>
      </View>

      <View style={[styles.statsCard, { backgroundColor: theme.backgroundDefault }]}>
        <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
          Your Progress
        </ThemedText>
        <View style={styles.statsRow}>
          <View style={styles.progressRingContainer}>
            <ProgressRing progress={progress} size={100} strokeWidth={10} />
          </View>
          <View style={styles.statsDetails}>
            <View style={styles.statItem}>
              <ThemedText style={[styles.statValue, { fontFamily: "Nunito_700Bold", color: BrandColors.primary }]}>
                {completedCount}
              </ThemedText>
              <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
                Lessons Completed
              </ThemedText>
            </View>
            <View style={styles.statItem}>
              <ThemedText style={[styles.statValue, { fontFamily: "Nunito_700Bold", color: BrandColors.accent }]}>
                {totalLessons - completedCount}
              </ThemedText>
              <ThemedText style={[styles.statLabel, { color: theme.textSecondary }]}>
                Lessons Remaining
              </ThemedText>
            </View>
          </View>
        </View>
      </View>

      <View style={[styles.achievementsCard, { backgroundColor: theme.backgroundDefault }]}>
        <View style={styles.sectionHeader}>
          <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
            Achievements
          </ThemedText>
          <ThemedText style={[styles.badgeCount, { color: theme.textSecondary }]}>
            {unlockedAchievements.length}/{achievements.length}
          </ThemedText>
        </View>
        
        <View style={styles.badgesGrid}>
          {achievements.slice(0, 6).map(achievement => (
            <AchievementBadge
              key={achievement.id}
              achievement={achievement}
              isUnlocked={isAchievementUnlocked(achievement.id)}
              progress={getAchievementProgress(achievement)}
              compact
            />
          ))}
        </View>
        
        {unlockedAchievements.length < achievements.length && (
          <ThemedText style={[styles.moreAchievements, { color: theme.textTertiary }]}>
            Complete more lessons to unlock achievements
          </ThemedText>
        )}
      </View>

      <View style={[styles.certificateCard, { backgroundColor: theme.backgroundDefault }]}>
        <View style={[styles.certificateIcon, { backgroundColor: BrandColors.primary + "15" }]}>
          <Feather name="award" size={32} color={BrandColors.primary} />
        </View>
        <ThemedText style={[styles.certificateTitle, { fontFamily: "Nunito_600SemiBold" }]}>
          Completion Certificate
        </ThemedText>
        <ThemedText style={[styles.certificateDesc, { color: theme.textSecondary }]}>
          {canGetCertificate
            ? "Congratulations! You've earned your certificate."
            : `Complete all lessons and quizzes to earn your certificate. (${completedCount}/${totalLessons} lessons, ${passedQuizCount}/7 quizzes)`
          }
        </ThemedText>
        <Pressable
          style={[
            styles.certificateButton,
            { 
              backgroundColor: canGetCertificate ? BrandColors.primary : theme.backgroundSecondary,
              opacity: canGetCertificate ? 1 : 0.6
            }
          ]}
          onPress={handleGetCertificate}
          disabled={!canGetCertificate || isGeneratingCert}
        >
          {isGeneratingCert ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <>
              <Feather 
                name="download" 
                size={18} 
                color={canGetCertificate ? "#FFFFFF" : theme.textTertiary} 
              />
              <ThemedText style={[
                styles.certificateButtonText,
                { color: canGetCertificate ? "#FFFFFF" : theme.textTertiary }
              ]}>
                Get Certificate
              </ThemedText>
            </>
          )}
        </Pressable>
      </View>

      <Pressable
        style={[styles.quickStartCard, { backgroundColor: "#FEF3C7", borderColor: "#F59E0B" }]}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          navigation.navigate("QuickStart");
        }}
      >
        <View style={styles.quickStartContent}>
          <View style={[styles.quickStartIcon, { backgroundColor: "#F59E0B" }]}>
            <Feather name="zap" size={24} color="#FFFFFF" />
          </View>
          <View style={styles.quickStartText}>
            <ThemedText style={[styles.quickStartTitle, { color: "#92400E" }]}>
              Substitute Teacher Quick Start
            </ThemedText>
            <ThemedText style={[styles.quickStartDesc, { color: "#B45309" }]}>
              Emergency lesson guide - no training needed
            </ThemedText>
          </View>
          <Feather name="chevron-right" size={20} color="#B45309" />
        </View>
      </Pressable>

      <View style={[styles.menuCard, { backgroundColor: theme.backgroundDefault }]}>
        <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
          Settings
        </ThemedText>
        
        <Pressable
          style={({ pressed }) => [
            styles.menuItem,
            { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" },
          ]}
        >
          <View style={[styles.menuIconContainer, { backgroundColor: BrandColors.info + "15" }]}>
            <Feather name="info" size={18} color={BrandColors.info} />
          </View>
          <ThemedText style={styles.menuText}>About This App</ThemedText>
          <Feather name="chevron-right" size={18} color={theme.textTertiary} />
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.menuItem,
            { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" },
          ]}
        >
          <View style={[styles.menuIconContainer, { backgroundColor: BrandColors.warning + "15" }]}>
            <Feather name="help-circle" size={18} color={BrandColors.warning} />
          </View>
          <ThemedText style={styles.menuText}>Help & Support</ThemedText>
          <Feather name="chevron-right" size={18} color={theme.textTertiary} />
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.menuItem,
            { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" },
          ]}
          onPress={handleResetProgress}
        >
          <View style={[styles.menuIconContainer, { backgroundColor: BrandColors.error + "15" }]}>
            <Feather name="refresh-cw" size={18} color={BrandColors.error} />
          </View>
          <ThemedText style={[styles.menuText, { color: BrandColors.error }]}>Reset Progress</ThemedText>
          <Feather name="chevron-right" size={18} color={theme.textTertiary} />
        </Pressable>
      </View>

      <ThemedText style={[styles.version, { color: theme.textTertiary }]}>
        Classroom Crops Teacher Training v1.0.0
      </ThemedText>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  profileCard: {
    alignItems: "center",
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  avatarContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  nameContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  displayName: {
    fontSize: 24,
  },
  editIcon: {
    marginLeft: Spacing.sm,
  },
  editNameContainer: {
    width: "100%",
    paddingHorizontal: Spacing.xl,
  },
  nameInput: {
    fontSize: 24,
    fontWeight: "700",
    textAlign: "center",
    borderBottomWidth: 2,
    paddingVertical: Spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    marginTop: Spacing.xs,
  },
  statsCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 16,
    marginBottom: Spacing.lg,
  },
  statsRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  progressRingContainer: {
    marginRight: Spacing.xl,
  },
  statsDetails: {
    flex: 1,
  },
  statItem: {
    marginBottom: Spacing.md,
  },
  statValue: {
    fontSize: 28,
  },
  statLabel: {
    fontSize: 13,
  },
  menuCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.sm,
    borderRadius: BorderRadius.xs,
    marginBottom: Spacing.xs,
  },
  menuIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.md,
  },
  menuText: {
    flex: 1,
    fontSize: 15,
  },
  version: {
    textAlign: "center",
    fontSize: 12,
    marginTop: Spacing.md,
  },
  achievementsCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  badgeCount: {
    fontSize: 14,
  },
  badgesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  moreAchievements: {
    fontSize: 12,
    textAlign: "center",
    marginTop: Spacing.sm,
  },
  certificateCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
    alignItems: "center",
  },
  certificateIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  certificateTitle: {
    fontSize: 18,
    marginBottom: Spacing.xs,
  },
  certificateDesc: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 20,
    marginBottom: Spacing.lg,
  },
  certificateButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    borderRadius: BorderRadius.sm,
    gap: Spacing.sm,
  },
  certificateButtonText: {
    fontSize: 15,
    fontWeight: "600",
  },
  quickStartCard: {
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.lg,
    borderWidth: 2,
  },
  quickStartContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  quickStartIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  quickStartText: {
    flex: 1,
  },
  quickStartTitle: {
    fontSize: 16,
    fontFamily: "Nunito_700Bold",
    marginBottom: 2,
  },
  quickStartDesc: {
    fontSize: 13,
  },
});
