import React, { useState, useCallback, useMemo } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  Linking,
  FlatList,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { RouteProp, useRoute, useNavigation } from "@react-navigation/native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as Calendar from "expo-calendar";
import Animated, { FadeInDown } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { trainingModules } from "@/data/trainingData";
import { addLessonToCalendar, requestCalendarPermission } from "@/services/calendarService";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type ScheduleRouteProp = RouteProp<RootStackParamList, "ScheduleLesson">;

const TIME_SLOTS = [
  { hour: 8, minute: 0, label: "8:00 AM" },
  { hour: 8, minute: 30, label: "8:30 AM" },
  { hour: 9, minute: 0, label: "9:00 AM" },
  { hour: 9, minute: 30, label: "9:30 AM" },
  { hour: 10, minute: 0, label: "10:00 AM" },
  { hour: 10, minute: 30, label: "10:30 AM" },
  { hour: 11, minute: 0, label: "11:00 AM" },
  { hour: 11, minute: 30, label: "11:30 AM" },
  { hour: 12, minute: 0, label: "12:00 PM" },
  { hour: 12, minute: 30, label: "12:30 PM" },
  { hour: 13, minute: 0, label: "1:00 PM" },
  { hour: 13, minute: 30, label: "1:30 PM" },
  { hour: 14, minute: 0, label: "2:00 PM" },
  { hour: 14, minute: 30, label: "2:30 PM" },
  { hour: 15, minute: 0, label: "3:00 PM" },
  { hour: 15, minute: 30, label: "3:30 PM" },
];

export default function ScheduleLessonScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const navigation = useNavigation();
  const route = useRoute<ScheduleRouteProp>();
  const { lessonId, moduleId, lessonTitle } = route.params;

  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<typeof TIME_SLOTS[0] | null>(null);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduleSuccess, setScheduleSuccess] = useState(false);
  const [permissionDenied, setPermissionDenied] = useState(false);

  const module = trainingModules.find((m) => m.id === moduleId);
  const lesson = module?.lessons.find((l) => l.id === lessonId);

  const upcomingDates = useMemo(() => {
    const dates: Date[] = [];
    const today = new Date();
    for (let i = 0; i < 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      if (date.getDay() !== 0 && date.getDay() !== 6) {
        dates.push(date);
      }
    }
    return dates;
  }, []);

  const handleSchedule = useCallback(async () => {
    if (!selectedDate || !selectedTime) return;

    setIsScheduling(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const hasPermission = await requestCalendarPermission();
      
      if (!hasPermission) {
        setPermissionDenied(true);
        setIsScheduling(false);
        return;
      }

      const eventId = await addLessonToCalendar(lessonId, selectedDate, {
        hour: selectedTime.hour,
        minute: selectedTime.minute,
      });

      if (eventId) {
        setScheduleSuccess(true);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      console.error("Error scheduling lesson:", error);
    } finally {
      setIsScheduling(false);
    }
  }, [lessonId, selectedDate, selectedTime]);

  const handleOpenSettings = useCallback(async () => {
    if (Platform.OS !== "web") {
      try {
        await Linking.openSettings();
      } catch (error) {
        console.error("Could not open settings:", error);
      }
    }
  }, []);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
    });
  };

  const formatFullDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  };

  if (scheduleSuccess && selectedDate && selectedTime) {
    return (
      <ThemedView style={styles.container}>
        <ScrollView
          contentContainerStyle={[
            styles.content,
            { paddingTop: headerHeight + Spacing.xl, paddingBottom: insets.bottom + 40 }
          ]}
        >
          <Animated.View entering={FadeInDown.springify()} style={styles.successContainer}>
            <View style={[styles.successIcon, { backgroundColor: BrandColors.success + "20" }]}>
              <Feather name="check-circle" size={64} color={BrandColors.success} />
            </View>
            <ThemedText style={styles.successTitle}>Lesson Scheduled!</ThemedText>
            <ThemedText style={[styles.successText, { color: theme.textSecondary }]}>
              "{lessonTitle}" has been added to your calendar for {formatFullDate(selectedDate)} at {selectedTime.label}.
            </ThemedText>
            <ThemedText style={[styles.reminderText, { color: theme.textTertiary }]}>
              You'll receive a reminder 30 minutes before the lesson.
            </ThemedText>
            <Button
              title="Done"
              onPress={() => navigation.goBack()}
              style={styles.doneButton}
            />
          </Animated.View>
        </ScrollView>
      </ThemedView>
    );
  }

  if (permissionDenied) {
    return (
      <ThemedView style={styles.container}>
        <ScrollView
          contentContainerStyle={[
            styles.content,
            { paddingTop: headerHeight + Spacing.xl, paddingBottom: insets.bottom + 40 }
          ]}
        >
          <Card style={styles.permissionCard}>
            <View style={[styles.permissionIcon, { backgroundColor: BrandColors.warning + "20" }]}>
              <Feather name="calendar" size={48} color={BrandColors.warning} />
            </View>
            <ThemedText style={styles.permissionTitle}>Calendar Access Required</ThemedText>
            <ThemedText style={[styles.permissionText, { color: theme.textSecondary }]}>
              To schedule lessons, please enable calendar access in your device settings.
            </ThemedText>
            {Platform.OS !== "web" && (
              <Button
                title="Open Settings"
                onPress={handleOpenSettings}
                style={styles.settingsButton}
              />
            )}
            <Pressable onPress={() => navigation.goBack()} style={styles.cancelLink}>
              <ThemedText style={[styles.cancelText, { color: BrandColors.primary }]}>
                Go Back
              </ThemedText>
            </Pressable>
          </Card>
        </ScrollView>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.lg, paddingBottom: insets.bottom + 40 }
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInDown.delay(100).springify()}>
          <Card style={[styles.lessonCard, { borderLeftColor: module?.color || BrandColors.primary }]}>
            <ThemedText style={[styles.moduleName, { color: theme.textSecondary }]}>
              {module?.title}
            </ThemedText>
            <ThemedText style={styles.lessonName}>{lessonTitle}</ThemedText>
            <View style={styles.lessonMeta}>
              <View style={styles.metaItem}>
                <Feather name="clock" size={14} color={theme.textTertiary} />
                <ThemedText style={[styles.metaText, { color: theme.textTertiary }]}>
                  {lesson?.duration}
                </ThemedText>
              </View>
              {lesson?.dayType && (
                <View style={styles.metaItem}>
                  <Feather name="tag" size={14} color={theme.textTertiary} />
                  <ThemedText style={[styles.metaText, { color: theme.textTertiary }]}>
                    {lesson.dayType}
                  </ThemedText>
                </View>
              )}
            </View>
          </Card>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(200).springify()}>
          <ThemedText style={styles.sectionTitle}>Select Date</ThemedText>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.dateList}
          >
            {upcomingDates.map((date, index) => {
              const isSelected = selectedDate?.toDateString() === date.toDateString();
              return (
                <Pressable
                  key={index}
                  style={[
                    styles.dateCard,
                    { backgroundColor: isSelected ? BrandColors.primary : theme.surfaceAlt },
                  ]}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setSelectedDate(date);
                  }}
                >
                  <ThemedText
                    style={[
                      styles.dateDay,
                      { color: isSelected ? "#FFFFFF" : theme.textSecondary },
                    ]}
                  >
                    {date.toLocaleDateString("en-US", { weekday: "short" })}
                  </ThemedText>
                  <ThemedText
                    style={[
                      styles.dateNumber,
                      { color: isSelected ? "#FFFFFF" : theme.text },
                    ]}
                  >
                    {date.getDate()}
                  </ThemedText>
                  <ThemedText
                    style={[
                      styles.dateMonth,
                      { color: isSelected ? "#FFFFFF" : theme.textSecondary },
                    ]}
                  >
                    {date.toLocaleDateString("en-US", { month: "short" })}
                  </ThemedText>
                </Pressable>
              );
            })}
          </ScrollView>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(300).springify()}>
          <ThemedText style={styles.sectionTitle}>Select Time</ThemedText>
          <Pressable
            onPress={() => setShowTimePicker(true)}
            style={[styles.pickerButton, { backgroundColor: theme.surfaceAlt }]}
          >
            <Feather name="clock" size={20} color={BrandColors.primary} />
            <ThemedText style={styles.pickerText}>
              {selectedTime ? selectedTime.label : "Choose a time..."}
            </ThemedText>
            <Feather name="chevron-down" size={20} color={theme.textTertiary} />
          </Pressable>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(400).springify()}>
          <Card style={[styles.infoCard, { backgroundColor: "#EFF6FF", borderColor: "#3B82F6" }]}>
            <Feather name="info" size={18} color="#3B82F6" />
            <ThemedText style={[styles.infoText, { color: "#1E40AF" }]}>
              A calendar event will be created with the lesson details and a 30-minute reminder.
            </ThemedText>
          </Card>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(500).springify()}>
          <Button
            title={isScheduling ? "Scheduling..." : "Add to Calendar"}
            onPress={handleSchedule}
            disabled={isScheduling || !selectedDate || !selectedTime}
            style={styles.scheduleButton}
          />
        </Animated.View>
      </ScrollView>

      <Modal
        visible={showTimePicker}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowTimePicker(false)}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={[styles.modalHeader, { paddingTop: insets.top + Spacing.md }]}>
            <Pressable
              style={styles.modalCloseButton}
              onPress={() => setShowTimePicker(false)}
            >
              <Feather name="x" size={24} color={theme.text} />
            </Pressable>
            <ThemedText style={styles.modalTitle}>Select Time</ThemedText>
            <View style={{ width: 40 }} />
          </View>
          <FlatList
            data={TIME_SLOTS}
            keyExtractor={(item) => item.label}
            contentContainerStyle={{ padding: Spacing.md, paddingBottom: insets.bottom + 40 }}
            renderItem={({ item }) => {
              const isSelected = selectedTime?.label === item.label;
              return (
                <Pressable
                  style={[
                    styles.timeOption,
                    { backgroundColor: isSelected ? BrandColors.primary + "15" : theme.surfaceAlt },
                    isSelected && { borderColor: BrandColors.primary, borderWidth: 2 },
                  ]}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    setSelectedTime(item);
                    setShowTimePicker(false);
                  }}
                >
                  <Feather
                    name={isSelected ? "check-circle" : "circle"}
                    size={20}
                    color={isSelected ? BrandColors.primary : theme.textTertiary}
                  />
                  <ThemedText
                    style={[
                      styles.timeOptionText,
                      isSelected && { color: BrandColors.primary, fontFamily: "Nunito_700Bold" },
                    ]}
                  >
                    {item.label}
                  </ThemedText>
                </Pressable>
              );
            }}
          />
        </ThemedView>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    padding: Spacing.md,
  },
  lessonCard: {
    padding: Spacing.md,
    marginBottom: Spacing.lg,
    borderLeftWidth: 4,
  },
  moduleName: {
    fontSize: 12,
    marginBottom: 4,
  },
  lessonName: {
    fontSize: 18,
    fontFamily: "Nunito_700Bold",
    marginBottom: Spacing.sm,
  },
  lessonMeta: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    fontSize: 13,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Nunito_600SemiBold",
    marginBottom: Spacing.sm,
    marginTop: Spacing.sm,
  },
  dateList: {
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
  },
  dateCard: {
    width: 70,
    height: 90,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.sm,
  },
  dateDay: {
    fontSize: 12,
    marginBottom: 2,
  },
  dateNumber: {
    fontSize: 24,
    fontFamily: "Nunito_700Bold",
  },
  dateMonth: {
    fontSize: 11,
  },
  pickerButton: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  pickerText: {
    flex: 1,
    fontSize: 16,
  },
  infoCard: {
    flexDirection: "row",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    gap: Spacing.sm,
    marginTop: Spacing.md,
    marginBottom: Spacing.lg,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 20,
  },
  scheduleButton: {
    marginTop: Spacing.md,
  },
  successContainer: {
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl,
  },
  successIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  successTitle: {
    fontSize: 24,
    fontFamily: "Nunito_700Bold",
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  successText: {
    fontSize: 16,
    textAlign: "center",
    lineHeight: 24,
    marginBottom: Spacing.sm,
  },
  reminderText: {
    fontSize: 14,
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  doneButton: {
    minWidth: 200,
  },
  permissionCard: {
    padding: Spacing.xl,
    alignItems: "center",
  },
  permissionIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  permissionTitle: {
    fontSize: 20,
    fontFamily: "Nunito_700Bold",
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  permissionText: {
    fontSize: 15,
    textAlign: "center",
    lineHeight: 22,
    marginBottom: Spacing.lg,
  },
  settingsButton: {
    marginBottom: Spacing.md,
  },
  cancelLink: {
    paddingVertical: Spacing.sm,
  },
  cancelText: {
    fontSize: 15,
    fontFamily: "Nunito_600SemiBold",
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.md,
    paddingBottom: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
  },
  modalCloseButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  modalTitle: {
    fontSize: 18,
    fontFamily: "Nunito_700Bold",
  },
  timeOption: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.sm,
    gap: Spacing.md,
  },
  timeOptionText: {
    fontSize: 16,
  },
});
