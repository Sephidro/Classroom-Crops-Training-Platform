import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { FadeInDown, FadeInUp } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, BrandColors } from "@/constants/theme";
import { quickStartGuide, quickStartWeeks, QuickStartLesson, QuickStartWeek } from "@/data/quickStartData";

export default function QuickStartScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme } = useTheme();
  const [selectedWeek, setSelectedWeek] = useState<number>(1);
  const [expandedLesson, setExpandedLesson] = useState<string | null>(null);

  const currentWeek = quickStartWeeks.find(w => w.weekNumber === selectedWeek);

  const handleWeekSelect = useCallback((weekNumber: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedWeek(weekNumber);
    setExpandedLesson(null);
  }, []);

  const handleLessonToggle = useCallback((lessonId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setExpandedLesson(prev => prev === lessonId ? null : lessonId);
  }, []);

  return (
    <ThemedView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { paddingTop: headerHeight + Spacing.md, paddingBottom: insets.bottom + 100 }
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInDown.delay(100).springify()}>
          <Card style={[styles.heroCard, { backgroundColor: BrandColors.primary }]}>
            <View style={styles.heroIcon}>
              <Feather name="zap" size={28} color="#fff" />
            </View>
            <ThemedText style={styles.heroTitle}>Substitute Teacher Quick Start</ThemedText>
            <ThemedText style={styles.heroSubtitle}>
              {quickStartGuide.introduction}
            </ThemedText>
          </Card>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(200).springify()}>
          <Card style={styles.checklistCard}>
            <View style={styles.sectionHeader}>
              <Feather name="check-square" size={20} color={BrandColors.primary} />
              <ThemedText style={styles.sectionTitle}>Before Class Checklist</ThemedText>
            </View>
            {quickStartGuide.beforeClassChecklist.map((item, index) => (
              <View key={index} style={styles.checklistItem}>
                <View style={[styles.checkCircle, { borderColor: BrandColors.primary }]}>
                  <ThemedText style={styles.checkNumber}>{index + 1}</ThemedText>
                </View>
                <ThemedText style={styles.checklistText}>{item}</ThemedText>
              </View>
            ))}
          </Card>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(300).springify()}>
          <ThemedText style={styles.sectionLabel}>Select Week</ThemedText>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            style={styles.weekSelector}
            contentContainerStyle={styles.weekSelectorContent}
          >
            {quickStartWeeks.map((week) => (
              <Pressable
                key={week.weekNumber}
                onPress={() => handleWeekSelect(week.weekNumber)}
                style={[
                  styles.weekTab,
                  { 
                    backgroundColor: selectedWeek === week.weekNumber ? week.color : theme.surfaceAlt,
                    borderColor: week.color 
                  }
                ]}
              >
                <ThemedText style={[
                  styles.weekTabText,
                  { color: selectedWeek === week.weekNumber ? "#fff" : theme.text }
                ]}>
                  Week {week.weekNumber}
                </ThemedText>
                <ThemedText style={[
                  styles.weekTabSubtext,
                  { color: selectedWeek === week.weekNumber ? "rgba(255,255,255,0.8)" : theme.textSecondary }
                ]}>
                  {week.title}
                </ThemedText>
              </Pressable>
            ))}
          </ScrollView>
        </Animated.View>

        {currentWeek && (
          <Animated.View entering={FadeInUp.delay(100).springify()}>
            <View style={styles.weekHeader}>
              <View style={[styles.weekBadge, { backgroundColor: currentWeek.color }]}>
                <ThemedText style={styles.weekBadgeText}>Week {currentWeek.weekNumber}</ThemedText>
              </View>
              <ThemedText style={styles.weekTheme}>{currentWeek.theme}</ThemedText>
            </View>

            {currentWeek.lessons.map((lesson, index) => (
              <LessonCard
                key={lesson.id}
                lesson={lesson}
                weekColor={currentWeek.color}
                isExpanded={expandedLesson === lesson.id}
                onToggle={() => handleLessonToggle(lesson.id)}
                delay={index * 50}
              />
            ))}
          </Animated.View>
        )}

        <Animated.View entering={FadeInDown.delay(400).springify()}>
          <Card style={[styles.emergencyCard, { backgroundColor: "#FEF3C7", borderColor: "#F59E0B" }]}>
            <View style={styles.sectionHeader}>
              <Feather name="alert-circle" size={20} color="#B45309" />
              <ThemedText style={[styles.sectionTitle, { color: "#B45309" }]}>Need Help?</ThemedText>
            </View>
            <ThemedText style={[styles.emergencyText, { color: "#92400E" }]}>
              {quickStartGuide.emergencyContacts}
            </ThemedText>
          </Card>
        </Animated.View>
      </ScrollView>
    </ThemedView>
  );
}

interface LessonCardProps {
  lesson: QuickStartLesson;
  weekColor: string;
  isExpanded: boolean;
  onToggle: () => void;
  delay: number;
}

function LessonCard({ lesson, weekColor, isExpanded, onToggle, delay }: LessonCardProps) {
  const { theme } = useTheme();

  return (
    <Animated.View entering={FadeInUp.delay(delay).springify()}>
      <Card style={styles.lessonCard}>
        <Pressable onPress={onToggle} style={styles.lessonHeader}>
          <View style={styles.lessonHeaderLeft}>
            <View style={[styles.dayTypeBadge, { backgroundColor: weekColor }]}>
              <ThemedText style={styles.dayTypeText}>{lesson.dayType}</ThemedText>
            </View>
            <View>
              <ThemedText style={styles.lessonTitle}>{lesson.title}</ThemedText>
              <ThemedText style={[styles.lessonDuration, { color: theme.textSecondary }]}>
                {lesson.duration}
              </ThemedText>
            </View>
          </View>
          <Feather 
            name={isExpanded ? "chevron-up" : "chevron-down"} 
            size={24} 
            color={theme.textSecondary} 
          />
        </Pressable>

        {isExpanded && (
          <View style={styles.lessonContent}>
            <View style={styles.scriptSection}>
              <View style={styles.scriptHeader}>
                <Feather name="message-circle" size={16} color={BrandColors.primary} />
                <ThemedText style={styles.scriptLabel}>Opening Script</ThemedText>
              </View>
              <View style={[styles.scriptBox, { backgroundColor: "#F0FDF4", borderColor: "#22C55E" }]}>
                <ThemedText style={styles.scriptText}>"{lesson.greetingScript}"</ThemedText>
              </View>
            </View>

            <View style={styles.stepsSection}>
              <View style={styles.scriptHeader}>
                <Feather name="list" size={16} color={BrandColors.primary} />
                <ThemedText style={styles.scriptLabel}>Activity Steps</ThemedText>
              </View>
              {lesson.activitySteps.map((step, index) => (
                <View key={index} style={styles.stepItem}>
                  <View style={[styles.stepNumber, { backgroundColor: weekColor }]}>
                    <ThemedText style={styles.stepNumberText}>{index + 1}</ThemedText>
                  </View>
                  <ThemedText style={styles.stepText}>{step}</ThemedText>
                </View>
              ))}
            </View>

            <View style={styles.materialsSection}>
              <View style={styles.scriptHeader}>
                <Feather name="package" size={16} color={BrandColors.primary} />
                <ThemedText style={styles.scriptLabel}>Materials Needed</ThemedText>
              </View>
              <View style={styles.materialsList}>
                {lesson.materials.map((material, index) => (
                  <View key={index} style={[styles.materialTag, { backgroundColor: theme.surfaceAlt }]}>
                    <ThemedText style={styles.materialText}>{material}</ThemedText>
                  </View>
                ))}
              </View>
            </View>

            <View style={styles.scriptSection}>
              <View style={styles.scriptHeader}>
                <Feather name="flag" size={16} color={BrandColors.primary} />
                <ThemedText style={styles.scriptLabel}>Closing Script</ThemedText>
              </View>
              <View style={[styles.scriptBox, { backgroundColor: "#EFF6FF", borderColor: "#3B82F6" }]}>
                <ThemedText style={styles.scriptText}>"{lesson.wrapUpScript}"</ThemedText>
              </View>
            </View>

            <View style={styles.tipsSection}>
              <View style={styles.scriptHeader}>
                <Feather name="life-buoy" size={16} color="#F59E0B" />
                <ThemedText style={[styles.scriptLabel, { color: "#B45309" }]}>Emergency Tips</ThemedText>
              </View>
              {lesson.emergencyTips.map((tip, index) => (
                <View key={index} style={[styles.tipItem, { backgroundColor: "#FFFBEB" }]}>
                  <Feather name="alert-triangle" size={14} color="#F59E0B" />
                  <ThemedText style={[styles.tipText, { color: "#92400E" }]}>{tip}</ThemedText>
                </View>
              ))}
            </View>
          </View>
        )}
      </Card>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: Spacing.md,
  },
  heroCard: {
    padding: Spacing.lg,
    marginBottom: Spacing.md,
  },
  heroIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.sm,
  },
  heroTitle: {
    fontSize: 22,
    fontFamily: "Nunito_700Bold",
    color: "#fff",
    marginBottom: Spacing.xs,
  },
  heroSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.9)",
    lineHeight: 20,
  },
  checklistCard: {
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Nunito_700Bold",
  },
  checklistItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: Spacing.sm,
    gap: Spacing.sm,
  },
  checkCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  checkNumber: {
    fontSize: 12,
    fontFamily: "Nunito_700Bold",
  },
  checklistText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 20,
  },
  sectionLabel: {
    fontSize: 16,
    fontFamily: "Nunito_700Bold",
    marginBottom: Spacing.sm,
    marginTop: Spacing.sm,
  },
  weekSelector: {
    marginBottom: Spacing.md,
  },
  weekSelectorContent: {
    gap: Spacing.sm,
    paddingRight: Spacing.md,
  },
  weekTab: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    minWidth: 100,
  },
  weekTabText: {
    fontSize: 14,
    fontFamily: "Nunito_700Bold",
  },
  weekTabSubtext: {
    fontSize: 11,
  },
  weekHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  weekBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  weekBadgeText: {
    fontSize: 12,
    fontFamily: "Nunito_700Bold",
    color: "#fff",
  },
  weekTheme: {
    fontSize: 18,
    fontFamily: "Nunito_700Bold",
    flex: 1,
  },
  lessonCard: {
    padding: 0,
    marginBottom: Spacing.sm,
    overflow: "hidden",
  },
  lessonHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.md,
  },
  lessonHeaderLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    flex: 1,
  },
  dayTypeBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
  },
  dayTypeText: {
    fontSize: 10,
    fontFamily: "Nunito_700Bold",
    color: "#fff",
    textTransform: "uppercase",
  },
  lessonTitle: {
    fontSize: 14,
    fontFamily: "Nunito_700Bold",
  },
  lessonDuration: {
    fontSize: 12,
  },
  lessonContent: {
    padding: Spacing.md,
    paddingTop: 0,
  },
  scriptSection: {
    marginBottom: Spacing.md,
  },
  scriptHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    marginBottom: Spacing.xs,
  },
  scriptLabel: {
    fontSize: 13,
    fontFamily: "Nunito_700Bold",
    color: BrandColors.primary,
  },
  scriptBox: {
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
  },
  scriptText: {
    fontSize: 14,
    fontStyle: "italic",
    lineHeight: 20,
  },
  stepsSection: {
    marginBottom: Spacing.md,
  },
  stepItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: Spacing.sm,
    gap: Spacing.sm,
  },
  stepNumber: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
  stepNumberText: {
    fontSize: 12,
    fontFamily: "Nunito_700Bold",
    color: "#fff",
  },
  stepText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 20,
  },
  materialsSection: {
    marginBottom: Spacing.md,
  },
  materialsList: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.xs,
  },
  materialTag: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
  },
  materialText: {
    fontSize: 12,
  },
  tipsSection: {
    marginTop: Spacing.sm,
  },
  tipItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    padding: Spacing.sm,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.xs,
    gap: Spacing.xs,
  },
  tipText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
  },
  emergencyCard: {
    padding: Spacing.md,
    marginTop: Spacing.md,
    borderWidth: 1,
  },
  emergencyText: {
    fontSize: 14,
    lineHeight: 20,
  },
});
