import React, { useCallback, useMemo } from "react";
import { View, StyleSheet, FlatList, Image } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";

import { ThemedText } from "@/components/ThemedText";
import { ContinueLearningCard } from "@/components/ContinueLearningCard";
import { LessonRow } from "@/components/LessonRow";
import { EmptyState } from "@/components/EmptyState";
import { useTheme } from "@/hooks/useTheme";
import { useProgressContext } from "@/context/ProgressContext";
import { Spacing, BorderRadius } from "@/constants/theme";
import { trainingModules } from "@/data/trainingData";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

export default function MyLearningScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const navigation = useNavigation<NavigationProp>();
  const {
    currentLesson,
    bookmarkedLessons,
    recentLessons,
    isLessonComplete,
    isLessonBookmarked,
    setCurrentLessonData,
    getNextLesson,
  } = useProgressContext();

  const handleLessonPress = useCallback((lessonId: string) => {
    const module = trainingModules.find((m) => m.lessons.some((l) => l.id === lessonId));
    const lesson = module?.lessons.find((l) => l.id === lessonId);

    if (module && lesson) {
      setCurrentLessonData({
        lessonId,
        moduleId: module.id,
        lessonTitle: lesson.title,
        moduleTitle: module.title,
      });

      navigation.navigate("LessonViewer", {
        lessonId,
        moduleId: module.id,
        lessonTitle: lesson.title,
      });
    }
  }, [navigation, setCurrentLessonData]);

  const getLessonData = useCallback((lessonId: string) => {
    for (const module of trainingModules) {
      const lesson = module.lessons.find((l) => l.id === lessonId);
      if (lesson) {
        return { lesson, moduleId: module.id };
      }
    }
    return null;
  }, []);

  const displayLesson = currentLesson || getNextLesson();

  const bookmarkedLessonData = useMemo(() => {
    return bookmarkedLessons
      .map((id) => getLessonData(id))
      .filter((data): data is NonNullable<typeof data> => data !== null);
  }, [bookmarkedLessons, getLessonData]);

  const recentLessonData = useMemo(() => {
    return recentLessons
      .slice(0, 5)
      .map((id) => getLessonData(id))
      .filter((data): data is NonNullable<typeof data> => data !== null);
  }, [recentLessons, getLessonData]);

  const hasContent = displayLesson || bookmarkedLessonData.length > 0 || recentLessonData.length > 0;

  if (!hasContent) {
    return (
      <View style={[styles.container, { backgroundColor: theme.backgroundRoot, paddingTop: headerHeight }]}>
        <EmptyState
          image={require("../../assets/images/empty-progress.png")}
          title="Start Your Learning Journey"
          description="Begin exploring the training modules to track your progress here."
          actionLabel="Browse Modules"
          onAction={() => navigation.navigate("Main", { screen: "TrainingTab" })}
        />
      </View>
    );
  }

  return (
    <FlatList
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      scrollIndicatorInsets={{ bottom: insets.bottom }}
      data={[]}
      renderItem={() => null}
      ListHeaderComponent={
        <>
          {displayLesson ? (
            <ContinueLearningCard
              lesson={displayLesson}
              onPress={() => handleLessonPress(displayLesson.lessonId)}
            />
          ) : null}

          {bookmarkedLessonData.length > 0 ? (
            <View style={styles.section}>
              <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
                Bookmarked
              </ThemedText>
              <View style={[styles.lessonList, { backgroundColor: theme.backgroundDefault }]}>
                {bookmarkedLessonData.map(({ lesson, moduleId }) => (
                  <LessonRow
                    key={lesson.id}
                    lesson={lesson}
                    moduleId={moduleId}
                    isComplete={isLessonComplete(lesson.id)}
                    isBookmarked={true}
                    showModuleColor={true}
                    onPress={() => handleLessonPress(lesson.id)}
                  />
                ))}
              </View>
            </View>
          ) : null}

          {recentLessonData.length > 0 ? (
            <View style={styles.section}>
              <ThemedText style={[styles.sectionTitle, { fontFamily: "Nunito_600SemiBold" }]}>
                Recently Viewed
              </ThemedText>
              <View style={[styles.lessonList, { backgroundColor: theme.backgroundDefault }]}>
                {recentLessonData.map(({ lesson, moduleId }) => (
                  <LessonRow
                    key={lesson.id}
                    lesson={lesson}
                    moduleId={moduleId}
                    isComplete={isLessonComplete(lesson.id)}
                    isBookmarked={isLessonBookmarked(lesson.id)}
                    showModuleColor={true}
                    onPress={() => handleLessonPress(lesson.id)}
                  />
                ))}
              </View>
            </View>
          ) : null}
        </>
      }
      showsVerticalScrollIndicator={false}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  section: {
    marginTop: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 18,
    marginBottom: Spacing.md,
  },
  lessonList: {
    borderRadius: BorderRadius.md,
    padding: Spacing.sm,
  },
});
