import { Platform } from "react-native";

// Design Guidelines Colors
export const BrandColors = {
  primary: "#2D7A4F", // Forest Green
  secondary: "#8B5A3C", // Warm Earth
  accent: "#E8A43E", // Golden Harvest
  
  // Module accent colors
  module1: "#4A7FA6", // Blue
  module2: "#2D7A4F", // Green
  module3: "#7B68A8", // Purple
  module4: "#E8A43E", // Orange
  module5: "#C74940", // Red
  module6: "#5A6FA8", // Indigo
  module7: "#D4A936", // Yellow
  
  // Semantic
  success: "#2D7A4F",
  warning: "#D97D3A",
  error: "#C74940",
  info: "#4A7FA6",
};

export const Colors = {
  light: {
    text: "#1A1A1A",
    textSecondary: "#6B6B6B",
    textTertiary: "#A8A8A8",
    buttonText: "#FFFFFF",
    tabIconDefault: "#6B6B6B",
    tabIconSelected: BrandColors.primary,
    link: BrandColors.primary,
    backgroundRoot: "#FAFAF8", // Warm White
    backgroundDefault: "#FFFFFF", // Pure White (cards)
    backgroundSecondary: "#F4F3F0", // Stone Gray
    backgroundTertiary: "#ECEAE6",
    border: "rgba(0,0,0,0.08)",
    ...BrandColors,
  },
  dark: {
    text: "#ECEDEE",
    textSecondary: "#A8A8A8",
    textTertiary: "#6B6B6B",
    buttonText: "#FFFFFF",
    tabIconDefault: "#9BA1A6",
    tabIconSelected: "#4CAF50",
    link: "#4CAF50",
    backgroundRoot: "#1A1A1A",
    backgroundDefault: "#2A2C2E",
    backgroundSecondary: "#353739",
    backgroundTertiary: "#404244",
    border: "rgba(255,255,255,0.08)",
    ...BrandColors,
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  "2xl": 32,
  "3xl": 48,
  "4xl": 64,
  inputHeight: 48,
  buttonHeight: 52,
};

export const BorderRadius = {
  xs: 8,
  sm: 12,
  md: 16,
  lg: 24,
  xl: 30,
  "2xl": 40,
  "3xl": 50,
  full: 9999,
};

export const Typography = {
  hero: {
    fontSize: 34,
    lineHeight: 41,
    fontWeight: "700" as const,
    fontFamily: "Nunito_700Bold",
  },
  h1: {
    fontSize: 28,
    lineHeight: 36,
    fontWeight: "700" as const,
    fontFamily: "Nunito_700Bold",
  },
  h2: {
    fontSize: 22,
    lineHeight: 29,
    fontWeight: "600" as const,
    fontFamily: "Nunito_600SemiBold",
  },
  h3: {
    fontSize: 18,
    lineHeight: 25,
    fontWeight: "600" as const,
    fontFamily: "Nunito_600SemiBold",
  },
  h4: {
    fontSize: 16,
    lineHeight: 22,
    fontWeight: "600" as const,
    fontFamily: "Nunito_600SemiBold",
  },
  body: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "400" as const,
  },
  bodyEmphasis: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "600" as const,
  },
  small: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "400" as const,
  },
  caption: {
    fontSize: 12,
    lineHeight: 16,
    fontWeight: "400" as const,
  },
  link: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: "400" as const,
  },
};

export const Fonts = Platform.select({
  ios: {
    sans: "system-ui",
    serif: "ui-serif",
    rounded: "ui-rounded",
    mono: "ui-monospace",
  },
  default: {
    sans: "normal",
    serif: "serif",
    rounded: "normal",
    mono: "monospace",
  },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded:
      "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});

export const Shadows = {
  card: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  floating: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 4,
  },
};
