export interface QuickStartLesson {
  id: string;
  title: string;
  dayType: string;
  duration: string;
  greetingScript: string;
  activitySteps: string[];
  materials: string[];
  wrapUpScript: string;
  emergencyTips: string[];
}

export interface QuickStartWeek {
  weekNumber: number;
  title: string;
  theme: string;
  color: string;
  lessons: QuickStartLesson[];
}

export const quickStartGuide = {
  introduction: "Welcome, Substitute Teacher! This Quick Start guide gives you everything you need to successfully teach today's Classroom Crops lesson - no prior training required.",
  beforeClassChecklist: [
    "Locate the plant growing area in the classroom",
    "Find the Classroom Crops materials bin",
    "Check if plants need water (soil should be moist, not wet)",
    "Review today's lesson card below",
    "Have students wash hands before handling plants"
  ],
  emergencyContacts: "If you have questions, check the regular teacher's desk for emergency plant care instructions or contact the office."
};

export const quickStartWeeks: QuickStartWeek[] = [
  {
    weekNumber: 1,
    title: "Seeds Week",
    theme: "What Are Seeds?",
    color: "#2D7A4F",
    lessons: [
      {
        id: "qs-1-1",
        title: "Monday: Intro to Seeds",
        dayType: "Plant Day",
        duration: "45 min",
        greetingScript: "Good morning, scientists! Today we're going to become seed detectives. Has anyone ever planted a seed before? What happened?",
        activitySteps: [
          "Show students 3-4 different types of seeds (bean, sunflower, pea, corn)",
          "Pass seeds around - have students observe size, shape, color",
          "Ask: 'What do you think is inside a seed?'",
          "Carefully open a pre-soaked bean to show the tiny plant inside",
          "Have students draw what they observed in their science journals"
        ],
        materials: ["Variety of seeds", "Pre-soaked beans", "Science journals", "Magnifying glasses (optional)"],
        wrapUpScript: "Scientists, you discovered something amazing today - every seed has a tiny baby plant inside, just waiting for water and warmth to grow! Tomorrow we'll start our own seeds growing.",
        emergencyTips: ["If no seeds available, use dried beans from the cafeteria", "Students can compare seeds to small items like buttons or beads"]
      },
      {
        id: "qs-1-2",
        title: "Tuesday: Seed Germination",
        dayType: "Lab Day",
        duration: "45 min",
        greetingScript: "Welcome back, scientists! Today we're setting up an experiment to watch seeds wake up and start growing. This is called germination.",
        activitySteps: [
          "Review: What's inside a seed? (tiny plant, food storage)",
          "Demonstrate setting up a 'germination station' - wet paper towel in plastic bag",
          "Each student places 2-3 bean seeds on their wet paper towel",
          "Seal bags and tape to window or place in warm spot",
          "Students predict: Which will sprout first? Record predictions"
        ],
        materials: ["Bean seeds", "Paper towels", "Plastic bags", "Tape", "Water spray bottle"],
        wrapUpScript: "Your seeds are now in the perfect environment to germinate - wet and warm, just like spring soil! Check on them tomorrow to see if anything has changed.",
        emergencyTips: ["Any seeds work - even apple seeds from lunch", "If no plastic bags, use clear cups with damp cotton"]
      },
      {
        id: "qs-1-3",
        title: "Wednesday: Seed Starters",
        dayType: "Build Day",
        duration: "45 min",
        greetingScript: "Hello builders! Today we're making our own seed starting containers from recycled materials. We're being scientists AND helping the environment!",
        activitySteps: [
          "Check germination bags - any roots or sprouts appearing?",
          "Show students how to make planters from egg cartons or paper cups",
          "Demonstrate adding drainage holes (teacher does this)",
          "Fill containers with seed starting mix",
          "Plant 2 seeds per container, cover lightly, water gently"
        ],
        materials: ["Egg cartons or paper cups", "Seed starting mix", "Seeds", "Water", "Pencil for poking holes"],
        wrapUpScript: "You've built homes for your seeds! Just like the germination bags, these seeds need water and warmth. We'll check on them and water them regularly.",
        emergencyTips: ["Any container with drainage holes works", "If no seed mix, regular potting soil is fine"]
      },
      {
        id: "qs-1-4",
        title: "Thursday: Seed Diversity",
        dayType: "Enrichment",
        duration: "40 min",
        greetingScript: "Scientists, today we're exploring why seeds come in so many different shapes and sizes. Every seed has a special design!",
        activitySteps: [
          "Water plants and check germination experiments",
          "Sort seeds by size - tiny (lettuce), medium (beans), large (avocado pit)",
          "Discuss: Why do some seeds have wings? Hooks? Float?",
          "Create a 'seed travel' poster showing how different seeds spread",
          "Students choose favorite seed and explain its 'superpower'"
        ],
        materials: ["Variety of seeds", "Poster paper", "Markers", "Glue (optional)"],
        wrapUpScript: "Every seed is perfectly designed to travel and find a good place to grow. Dandelion seeds fly on the wind, berries are eaten by birds who spread the seeds - nature is amazing!",
        emergencyTips: ["Use food examples: apple seeds, orange seeds, popcorn kernels", "Watch a short video about seed dispersal"]
      },
      {
        id: "qs-1-5",
        title: "Friday: Wrap-Up & Assessment",
        dayType: "Assessment",
        duration: "40 min",
        greetingScript: "Happy Friday, scientists! This week you learned so much about seeds. Today we're going to share what we discovered and check on our growing plants.",
        activitySteps: [
          "Final check on germination bags - measure any root growth",
          "Water seed starters and observe for any sprouting",
          "Quick review quiz: What's inside a seed? What do seeds need to grow?",
          "Students share one favorite thing they learned",
          "Clean up and organize growing area"
        ],
        materials: ["Science journals", "Rulers for measuring", "Watering can"],
        wrapUpScript: "You've officially completed Seeds Week! Next week we'll learn about what happens after seeds sprout - how seedlings grow into big, healthy plants.",
        emergencyTips: ["If seeds haven't sprouted yet, that's normal - germination takes 3-10 days", "Celebrate any growth, even if small"]
      }
    ]
  },
  {
    weekNumber: 2,
    title: "Seedlings Week",
    theme: "From Seeds to Seedlings",
    color: "#7B68A8",
    lessons: [
      {
        id: "qs-2-1",
        title: "Monday: Seedling Parts",
        dayType: "Plant Day",
        duration: "45 min",
        greetingScript: "Good morning, plant scientists! Our seeds have been growing. Today we're learning the parts of a seedling - the baby plant stage.",
        activitySteps: [
          "Observe any sprouted seeds - celebrate the growth!",
          "Introduce vocabulary: root, stem, leaves, cotyledons (seed leaves)",
          "Draw and label a seedling diagram",
          "Compare seedlings to adult plant photos - what's different?",
          "Gentle watering practice - just enough to keep soil moist"
        ],
        materials: ["Sprouted seedlings", "Plant diagrams", "Science journals", "Watering can"],
        wrapUpScript: "Now you can identify the parts of every baby plant you see! Remember - roots go down for water, stems go up toward the light.",
        emergencyTips: ["If no seedlings yet, use photos or pre-grown seedlings", "Bean sprouts from grocery store work great for observation"]
      },
      {
        id: "qs-2-2",
        title: "Tuesday: Light Experiment",
        dayType: "Lab Day",
        duration: "45 min",
        greetingScript: "Scientists, today we're testing an important question: What happens if a plant doesn't get light?",
        activitySteps: [
          "Check and water plants",
          "Set up light experiment: 2 similar seedlings - one in light, one in dark box",
          "Predict: What will happen to each plant after 5 days?",
          "Record predictions with drawings",
          "Discuss why plants need light (to make their own food!)"
        ],
        materials: ["Two similar seedlings", "Cardboard box", "Science journals"],
        wrapUpScript: "We'll check our experiment later this week. Scientists make predictions, then test them with experiments - just like you did today!",
        emergencyTips: ["If only one seedling, use half in light/half covered", "A paper bag works as well as a box"]
      },
      {
        id: "qs-2-3",
        title: "Wednesday: Transplanting",
        dayType: "Build Day",
        duration: "45 min",
        greetingScript: "Today's an exciting day - we're moving our seedlings to bigger homes! This is called transplanting.",
        activitySteps: [
          "Explain why we transplant: roots need more room to grow",
          "Demonstrate gentle transplanting technique - handle by leaves, not stem",
          "Each student carefully transplants one seedling to larger pot",
          "Water newly transplanted seedlings gently",
          "Label pots with student names and date"
        ],
        materials: ["Seedlings ready to transplant", "Larger pots or containers", "Potting soil", "Water", "Labels"],
        wrapUpScript: "You did it! Your seedlings have new, bigger homes. They might look a little tired today - that's normal. By tomorrow they'll be reaching for the light again.",
        emergencyTips: ["Transplant shock is normal - reassure students", "If no seedlings ready, practice with small plants from a garden center"]
      },
      {
        id: "qs-2-4",
        title: "Thursday: Root Systems",
        dayType: "Enrichment",
        duration: "40 min",
        greetingScript: "Hello scientists! Today we're exploring the hidden half of plants - what's happening underground with roots.",
        activitySteps: [
          "Check light experiment - any differences yet?",
          "Carefully wash soil off a seedling to observe roots",
          "Discuss root functions: anchor, absorb water and nutrients",
          "Draw root system observations",
          "Compare tap roots vs fibrous roots (carrot vs grass)"
        ],
        materials: ["Expendable seedling for observation", "Water basin", "Carrot (example of tap root)", "Science journals"],
        wrapUpScript: "Roots are the unsung heroes of plants - working underground to keep plants fed and stable. Next time you eat a carrot, you're eating a giant root!",
        emergencyTips: ["A carrot from the cafeteria works perfectly", "Videos of time-lapse root growth are fascinating"]
      },
      {
        id: "qs-2-5",
        title: "Friday: Seedling Health Check",
        dayType: "Assessment",
        duration: "40 min",
        greetingScript: "It's assessment Friday! Let's check our light experiment results and evaluate the health of all our plants.",
        activitySteps: [
          "Reveal light experiment results - compare plants side by side",
          "Discuss: Why did the plant in darkness look different?",
          "Plant health checklist: green leaves? Standing straight? Moist soil?",
          "Students assess and record the health of their seedlings",
          "Plan for next week: we'll learn about water movement in plants"
        ],
        materials: ["Light experiment plants", "Health checklist worksheet", "Science journals"],
        wrapUpScript: "You've learned that seedlings need light to be healthy and grow strong. The plant in darkness used up its stored energy trying to find light. Great scientific observations!",
        emergencyTips: ["If experiment failed, discuss what might have gone wrong - that's science too!", "Celebrate all observations, even unexpected ones"]
      }
    ]
  },
  {
    weekNumber: 3,
    title: "Water & Light Week",
    theme: "How Plants Use Water and Light",
    color: "#E8A43E",
    lessons: [
      {
        id: "qs-3-1",
        title: "Monday: Water in Plants",
        dayType: "Plant Day",
        duration: "45 min",
        greetingScript: "Good morning scientists! Today we're discovering how plants drink water and move it through their bodies.",
        activitySteps: [
          "Water all plants and observe any growth",
          "Ask: How does water get from soil to the leaves?",
          "Set up celery/carnation coloring experiment",
          "Place white flower or celery in colored water",
          "Predict what will happen by tomorrow"
        ],
        materials: ["White carnation or celery stalk", "Food coloring", "Clear cups", "Water"],
        wrapUpScript: "Plants have tiny tubes inside them that carry water up from roots to leaves. Tomorrow we'll see the proof when our flowers change color!",
        emergencyTips: ["Celery shows results faster than flowers", "Blue and red food coloring work best"]
      },
      {
        id: "qs-3-2",
        title: "Tuesday: Transpiration",
        dayType: "Lab Day",
        duration: "45 min",
        greetingScript: "Scientists, did you know plants sweat? It's called transpiration, and we're going to prove it happens!",
        activitySteps: [
          "Check colored water experiment - observe color in petals/celery",
          "Explain transpiration: water exits through tiny holes in leaves",
          "Place plastic bags over plant leaves and seal",
          "Predict: What will we find in the bags tomorrow?",
          "Discuss the water cycle connection"
        ],
        materials: ["Healthy plants with leaves", "Clear plastic bags", "Twist ties", "Colored water experiment from yesterday"],
        wrapUpScript: "Water travels up through the plant and exits through the leaves as water vapor - just like when you breathe on a cold window! Check the bags tomorrow.",
        emergencyTips: ["Seal bags tightly for best results", "Morning observation shows more water droplets"]
      },
      {
        id: "qs-3-3",
        title: "Wednesday: Intro to Hydroponics",
        dayType: "Build Day",
        duration: "50 min",
        greetingScript: "Today we're learning about a different way to grow plants - without soil! It's called hydroponics.",
        activitySteps: [
          "Check transpiration bags - observe water droplets",
          "Explain hydroponics: growing in nutrient water instead of soil",
          "Show examples of hydroponic systems (photos or videos)",
          "Build simple water culture system with plastic bottles",
          "Start lettuce or basil seeds in growing medium"
        ],
        materials: ["Plastic bottles", "Net cups or small containers with holes", "Growing medium (rockwool or perlite)", "Seeds", "Nutrient solution (or plain water to start)"],
        wrapUpScript: "You've built your first hydroponic system! Plants don't actually need soil - they need water, nutrients, and light. Hydroponics gives them everything directly in water.",
        emergencyTips: ["Start with just water - nutrients can be added later", "Any leafy green seeds work well for beginners"]
      },
      {
        id: "qs-3-4",
        title: "Thursday: Plant Nutrients",
        dayType: "Enrichment",
        duration: "45 min",
        greetingScript: "Just like you need vitamins to grow strong, plants need nutrients. Let's learn what keeps plants healthy!",
        activitySteps: [
          "Water plants and check hydroponic systems",
          "Introduce the 'Big Three' nutrients: Nitrogen, Phosphorus, Potassium",
          "N = leaves, P = roots and flowers, K = overall health",
          "Examine plant food label - find N-P-K numbers",
          "Draw a healthy vs unhealthy plant and label what might be missing"
        ],
        materials: ["Plant fertilizer container (for label reading)", "Science journals", "Photos of nutrient deficiency"],
        wrapUpScript: "Now you know the secret recipe for healthy plants! Tomorrow we'll continue working with our hydroponic systems.",
        emergencyTips: ["Focus on the basics - plants need food just like we do", "Yellow leaves often mean nitrogen deficiency"]
      },
      {
        id: "qs-3-5",
        title: "Friday: Hydroponic Check",
        dayType: "Build Day",
        duration: "50 min",
        greetingScript: "Happy Friday! Let's check on our hydroponic systems and make sure they're set up for weekend growth.",
        activitySteps: [
          "Check water levels in all hydroponic systems - refill as needed",
          "Compare soil plants to hydroponic plants - any differences?",
          "Troubleshoot any problems with systems",
          "Record observations and take measurements",
          "Ensure systems are ready for the weekend"
        ],
        materials: ["Hydroponic systems", "Water", "Measuring tools", "Science journals"],
        wrapUpScript: "Great work this week! You learned how plants use water, what transpiration is, and even started growing plants without soil. Next week: flowers and pollination!",
        emergencyTips: ["Extra water for weekend - check levels are full", "Move systems to good light source"]
      }
    ]
  }
];

export function getQuickStartLesson(weekNumber: number, dayOfWeek: number): QuickStartLesson | null {
  const week = quickStartWeeks.find(w => w.weekNumber === weekNumber);
  if (!week || dayOfWeek < 1 || dayOfWeek > 5) return null;
  return week.lessons[dayOfWeek - 1] || null;
}

export function getTodaysQuickStart(): QuickStartLesson | null {
  const today = new Date();
  const dayOfWeek = today.getDay();
  if (dayOfWeek === 0 || dayOfWeek === 6) return null;
  const weekNumber = 1;
  return getQuickStartLesson(weekNumber, dayOfWeek);
}
