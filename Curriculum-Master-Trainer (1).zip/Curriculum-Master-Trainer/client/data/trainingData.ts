import { Feather } from "@expo/vector-icons";

export type LessonType = "concept" | "practical" | "checklist" | "scenario" | "lab" | "build";

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  type: LessonType;
  dayType?: string;
}

export interface Module {
  id: number;
  title: string;
  icon: keyof typeof Feather.glyphMap;
  color: string;
  description: string;
  lessons: Lesson[];
}

export interface LessonContent {
  overview: string;
  keyPoints: string[];
  detailedContent: string;
  practiceActivity: string;
  teachingTips: string[];
  commonMistakes: string[];
}

export const trainingModules: Module[] = [
  {
    id: 1,
    title: "Getting Started: Program Overview",
    icon: "book-open",
    color: "#4A7FA6",
    description: "Master the curriculum philosophy, weekly structure, and materials setup",
    lessons: [
      { id: "1-1", title: "Course Philosophy & Learning Architecture", duration: "15 min", type: "concept" },
      { id: "1-2", title: "Weekly Structure Framework", duration: "10 min", type: "concept" },
      { id: "1-3", title: "Materials & Equipment Setup Guide", duration: "20 min", type: "checklist" },
      { id: "1-4", title: "Classroom Space Design", duration: "15 min", type: "practical" }
    ]
  },
  {
    id: 2,
    title: "Week 1: What Are Seeds?",
    icon: "sun",
    color: "#2D7A4F",
    description: "Introduce seeds, germination, and build first growing systems",
    lessons: [
      { id: "2-1", title: "Monday: Introduction to Seeds (Plant Day)", duration: "45 min", type: "concept", dayType: "Plant Day" },
      { id: "2-2", title: "Tuesday: Seed Germination Experiment (Lab Day)", duration: "45 min", type: "lab", dayType: "Lab Day" },
      { id: "2-3", title: "Wednesday: DIY Seed Starting System (Build Day)", duration: "45 min", type: "build", dayType: "Build Day" },
      { id: "2-4", title: "Thursday: Seed Diversity & Adaptations (Enrichment)", duration: "40 min", type: "concept", dayType: "Enrichment" },
      { id: "2-5", title: "Friday: Germination Wrap-up & Assessment", duration: "40 min", type: "practical", dayType: "Assessment" }
    ]
  },
  {
    id: 3,
    title: "Week 2: From Seeds to Seedlings",
    icon: "trending-up",
    color: "#7B68A8",
    description: "Seedling anatomy, plant health, and transplanting skills",
    lessons: [
      { id: "3-1", title: "Monday: Anatomy of a Seedling (Plant Day)", duration: "45 min", type: "concept", dayType: "Plant Day" },
      { id: "3-2", title: "Tuesday: Seedling Conditions Investigation (Lab Day)", duration: "45 min", type: "lab", dayType: "Lab Day" },
      { id: "3-3", title: "Wednesday: Transplanting & Planter Expansion (Build Day)", duration: "45 min", type: "build", dayType: "Build Day" },
      { id: "3-4", title: "Thursday: Root Systems Deep Dive (Enrichment)", duration: "40 min", type: "concept", dayType: "Enrichment" },
      { id: "3-5", title: "Friday: Seedling Health Assessment", duration: "40 min", type: "practical", dayType: "Assessment" }
    ]
  },
  {
    id: 4,
    title: "Week 3: Water, Light & Hydroponics",
    icon: "droplet",
    color: "#E8A43E",
    description: "Transpiration, photosynthesis, and introduction to hydroponics",
    lessons: [
      { id: "4-1", title: "Monday: Water Movement in Plants (Plant Day)", duration: "45 min", type: "concept", dayType: "Plant Day" },
      { id: "4-2", title: "Tuesday: Transpiration Experiments (Lab Day)", duration: "45 min", type: "lab", dayType: "Lab Day" },
      { id: "4-3", title: "Wednesday: Introduction to Hydroponics (Build Day)", duration: "50 min", type: "build", dayType: "Build Day" },
      { id: "4-4", title: "Thursday: Nutrients & Plant Health (Enrichment)", duration: "45 min", type: "concept", dayType: "Enrichment" },
      { id: "4-5", title: "Friday: Hydroponic System Build Day", duration: "50 min", type: "build", dayType: "Build Day" }
    ]
  },
  {
    id: 5,
    title: "Week 4: Reproduction & Pollination",
    icon: "heart",
    color: "#C74940",
    description: "Flower anatomy, pollination strategies, and fruit development",
    lessons: [
      { id: "5-1", title: "Monday: Flower Anatomy & Function (Plant Day)", duration: "45 min", type: "concept", dayType: "Plant Day" },
      { id: "5-2", title: "Tuesday: Flower Dissection Lab (Lab Day)", duration: "45 min", type: "lab", dayType: "Lab Day" },
      { id: "5-3", title: "Wednesday: Pollination Exploration & Hand-Pollination (Build Day)", duration: "50 min", type: "build", dayType: "Build Day" },
      { id: "5-4", title: "Thursday: From Flowers to Fruits (Enrichment)", duration: "45 min", type: "concept", dayType: "Enrichment" },
      { id: "5-5", title: "Friday: Life Cycles & Seed Formation", duration: "40 min", type: "practical", dayType: "Assessment" }
    ]
  },
  {
    id: 6,
    title: "Week 5: Harvest, Nutrition & Economics",
    icon: "award",
    color: "#5A6FA8",
    description: "Harvesting techniques, nutritional analysis, and food economics",
    lessons: [
      { id: "6-1", title: "Monday: Harvest Readiness Assessment (Plant Day)", duration: "45 min", type: "concept", dayType: "Plant Day" },
      { id: "6-2", title: "Tuesday: Harvest Celebration & Yield Analysis (Lab Day)", duration: "50 min", type: "lab", dayType: "Lab Day" },
      { id: "6-3", title: "Wednesday: Nutrition Analysis & Food Science (Build Day)", duration: "50 min", type: "build", dayType: "Build Day" },
      { id: "6-4", title: "Thursday: Food Preservation Methods (Enrichment)", duration: "45 min", type: "concept", dayType: "Enrichment" },
      { id: "6-5", title: "Friday: Economics of Growing Food", duration: "45 min", type: "practical", dayType: "Assessment" }
    ]
  },
  {
    id: 7,
    title: "Week 6: Optimization & Final Projects",
    icon: "target",
    color: "#D4A936",
    description: "Troubleshooting, optimization, succession planting, and capstone projects",
    lessons: [
      { id: "7-1", title: "Monday: Troubleshooting Common Problems (Plant Day)", duration: "50 min", type: "scenario", dayType: "Plant Day" },
      { id: "7-2", title: "Tuesday: Growth Optimization Experiments (Lab Day)", duration: "45 min", type: "lab", dayType: "Lab Day" },
      { id: "7-3", title: "Wednesday: Succession Planting & Calendar Planning (Build Day)", duration: "50 min", type: "build", dayType: "Build Day" },
      { id: "7-4", title: "Thursday: Final System Design Project", duration: "60 min", type: "practical", dayType: "Project" },
      { id: "7-5", title: "Friday: Presentations, Celebration & Reflection", duration: "60 min", type: "practical", dayType: "Celebration" }
    ]
  }
];

export const lessonContents: Record<string, LessonContent> = {
  "1-1": {
    overview: "Understand the core philosophy behind experiential, hands-on agriculture education and how the progressive learning architecture transforms student engagement.",
    keyPoints: [
      "Unlock → Practice → Master → Apply → Advance learning model",
      "Each unit introduces ONE core concept that builds throughout the program",
      "Previous skills are continuously reinforced while new challenges are introduced",
      "Course duration: 18 weeks (semester) to 36 weeks (full year), adaptable to your schedule",
      "Real-world consequences drive deeper engagement than abstract learning"
    ],
    detailedContent: `**Program Overview & Philosophy:**

This curriculum uses a progressive, hands-on approach where each concept builds on previous knowledge, similar to unlocking abilities in a game. Students master foundational skills before advancing to complex applications.

**Learning Architecture:**
Unlock → Practice → Master → Apply → Advance

Each unit introduces ONE core concept that students will use throughout the rest of the program. Previous skills are continuously reinforced while new challenges are introduced.

**Why Hands-On Learning Works:**

Traditional education often separates learning from doing. Students memorize facts about photosynthesis but never see it happen. Our curriculum flips this model.

**The Living Laboratory Approach:**

When students care for plants, they:
• Make real decisions with real consequences
• Observe scientific processes in real-time
• Develop responsibility and empathy
• Experience the satisfaction of growing food

**Constructivist Learning Theory:**

Students don't receive knowledge passively—they construct it through experience. When a student's plant wilts, they don't just read about water stress; they FEEL it and remember it.

**The Growth Mindset Connection:**

Plants teach patience and persistence. A seed doesn't sprout overnight. Students learn that growth takes time, care, and sometimes multiple attempts.`,
    practiceActivity: `**REFLECTION ACTIVITY:**

Think about a time when you learned something by doing it versus reading about it.

1. What was the difference in how well you remembered?
2. How did making mistakes help you learn?
3. How can you create similar experiences for your students?

**SCENARIO:**
A colleague says: "My students just need to learn the facts. They don't have time for all this plant stuff."

Write a 2-3 sentence response explaining the value of experiential learning.`,
    teachingTips: [
      "Share your own learning journey with students",
      "Resist the urge to give answers—guide discovery instead",
      "Document student 'aha moments' to share later",
      "Connect abstract concepts to what students observe",
      "Use students' questions to drive the curriculum"
    ],
    commonMistakes: [
      "Lecturing before letting students explore",
      "Providing answers too quickly",
      "Treating plant care as a chore, not learning",
      "Not connecting hands-on work to academic standards",
      "Underestimating what students can figure out"
    ]
  },
  "1-2": {
    overview: "Master the 5-day weekly structure that balances direct instruction, hands-on investigation, building projects, enrichment activities, and assessment.",
    keyPoints: [
      "Monday - PLANT DAY: New concepts, direct instruction, guided observation",
      "Tuesday - LAB DAY: Hands-on investigation, data collection, scientific method",
      "Wednesday - BUILD DAY: DIY projects, problem-solving, engineering design",
      "Thursday - ENRICHMENT 1: Extension activities, cross-curricular connections",
      "Friday - ENRICHMENT 2: Student choice, assessments, reflections"
    ],
    detailedContent: `**Weekly Structure Framework:**

**MONDAY - PLANT DAY**
Focus: New concepts, direct instruction, guided observation
• Introduce weekly theme and vocabulary
• Demonstrate key techniques
• Begin observations of ongoing experiments
• Set up the week's learning goals

**TUESDAY - LAB DAY**
Focus: Hands-on investigation, data collection, scientific method
• Conduct experiments designed on Monday
• Collect quantitative and qualitative data
• Practice scientific documentation
• Form hypotheses and test predictions

**WEDNESDAY - BUILD DAY**
Focus: DIY projects, problem-solving, engineering design
• Construct growing systems and tools
• Apply engineering design process
• Solve real-world problems with materials
• Create sustainable, reusable equipment

**THURSDAY - ENRICHMENT 1**
Focus: Extension activities, cross-curricular connections
• Connect to math, language arts, social studies
• Explore related topics in depth
• Guest speakers or virtual field trips
• Advanced challenges for fast learners

**FRIDAY - ENRICHMENT 2**
Focus: Student choice, assessments, reflections
• Formative and summative assessments
• Student reflection and journaling
• Week wrap-up and preview of next week
• Catch-up time for students who need it`,
    practiceActivity: `**PLANNING EXERCISE:**

Map out your first week considering:
1. How many class periods do you have?
2. When will students check on plants (daily routine)?
3. When will you do main instruction?
4. What's your backup if seeds don't germinate on time?

Create a simple week schedule showing how you'll adapt the 5-day framework to your actual schedule.`,
    teachingTips: [
      "Build in buffer time—plants don't follow schedules",
      "Prepare contingency lessons for plant delays",
      "Use 'plant check' time for individual observation",
      "Keep a class journal of overall progress",
      "Preview next week's content at end of each week"
    ],
    commonMistakes: [
      "Rushing through content to 'catch up'",
      "Not accounting for germination timing variations",
      "Skipping daily plant check-ins",
      "Over-planning without flexibility",
      "Not having backup activities ready"
    ]
  },
  "1-3": {
    overview: "Complete checklist of all materials, equipment, and supplies needed to run the Classroom Crops curriculum successfully.",
    keyPoints: [
      "Soil Shelf Units: Wire shelving, LED grow lights, seed starter trays with domes",
      "Hydro Shelf Unit: Hydroponic solution, clay pebbles, vinyl tubing, water pump",
      "Tools & Supplies: Scissors, hole punchers, soldering iron, zip ties, potting soil",
      "Budget-friendly alternatives and donation sources",
      "Storage organization and materials management"
    ],
    detailedContent: `**Essential Equipment (Set up before Week 1)**

For 20-30 students, you'll need:

**Soil Shelf Units (2 units):**
• 2 wire shelving units
• 2 LED grow light sets
• 6-12 seed starter trays with domes
• 100-200 clean plastic bottles (collect from students)
• 1 roll paper towels
• 8 plastic shoebox containers

**Hydro Shelf Unit (1 unit):**
• 1 wire shelving unit
• 1 LED grow light set
• Hydroponic solution
• Clay pebbles (1 bag)
• Vinyl tubing (¾" ID/1" OD and ½" ID/⅝" OD)
• 3 collapsible tubs
• Pool noodles
• Water pump

**Tools & Supplies:**
• 20-30 scissors
• 20-30 hole punchers
• Soldering iron/pen (teacher use only)
• Zip ties (1000-pack)
• Potting soil (multiple bags)
• Seed varieties (see weekly guides)
• Work trays
• Plastic gloves

**Budget Planning Tips:**

LOW COST OPTIONS:
• Reuse containers (yogurt cups, milk jugs)
• Collect seeds from produce
• Use natural light near windows
• Partner with local nurseries for donations

SPLURGE-WORTHY ITEMS:
• Quality grow lights (make or break success)
• Reliable timer systems
• Good seed varieties (don't skimp here)`,
    practiceActivity: `**INVENTORY EXERCISE:**

1. List all materials you currently have access to
2. Identify gaps in your supplies
3. Calculate estimated costs to fill gaps
4. Brainstorm 3 free or low-cost alternatives

**BUDGET SCENARIO:**
You have $200 for the semester. How would you prioritize spending? Create a prioritized shopping list.`,
    teachingTips: [
      "Create a materials request list for your school",
      "Reach out to local farms/nurseries for partnerships",
      "Set up a rotating 'materials manager' student role",
      "Keep backup seeds in a cool, dry place",
      "Label everything clearly for easy access"
    ],
    commonMistakes: [
      "Not checking seed viability before planting",
      "Running out of consumables mid-unit",
      "Storing seeds in humid conditions",
      "Not having backup growing medium",
      "Forgetting to budget for replacements"
    ]
  },
  "1-4": {
    overview: "Design a safe, functional, and inspiring growing space in your classroom that facilitates hands-on learning.",
    keyPoints: [
      "Position for adequate light access (natural or artificial)",
      "Ensure proper drainage and waterproofing",
      "Create accessible workstations for all students",
      "Establish safety protocols for tools and electricity",
      "Design for student independence and ownership"
    ],
    detailedContent: `**Space Planning Principles:**

**LIGHT REQUIREMENTS:**
• Natural light: South-facing windows ideal
• Artificial light: Position 2-6 inches above plants
• Light duration: 12-16 hours for most vegetables
• Light timing: Use timers for consistency

**WORKSTATION DESIGN:**
• Table height appropriate for students
• Waterproof surfaces or protection
• Easy-to-clean materials
• Clear pathways between stations
• Designated supply storage nearby

**SAFETY CONSIDERATIONS:**
• Electrical cords secured and away from water
• Non-slip floor mats in wet areas
• Proper ventilation if using fertilizers
• First aid kit accessible
• Clear emergency procedures posted

**LAYOUT OPTIONS:**

OPTION A - Window Garden:
• Use natural light from windows
• Low cost, limited space
• Best for small classes

OPTION B - Grow Light Station:
• Dedicated table with overhead lights
• More consistent results
• Requires electrical access

OPTION C - Hydroponic System:
• Self-contained unit
• Year-round growing
• Higher initial investment

**Student-Centered Design:**
• Labels at student eye level
• Supply bins students can access
• Visual guides for procedures
• Designated 'observation zones'`,
    practiceActivity: `**DESIGN YOUR SPACE:**

Sketch your ideal classroom growing setup:
1. Mark where natural light enters
2. Identify electrical outlets
3. Plan water access points
4. Design student traffic flow
5. Note safety considerations

Consider: What's the minimum viable setup you could start with tomorrow?`,
    teachingTips: [
      "Start small—you can always expand",
      "Involve students in setup for ownership",
      "Create visual guides for all procedures",
      "Designate a 'plant station captain' role",
      "Take before photos for comparison later"
    ],
    commonMistakes: [
      "Placing plants too far from light source",
      "Not waterproofing work surfaces",
      "Blocking walkways with plant stations",
      "Electrical hazards near water",
      "Making setup too complex to maintain"
    ]
  },
  "2-1": {
    overview: "Introduce students to the fascinating world of seeds—their structure, function, and the miracle of life they contain. Students will dissect seeds and understand the three main parts.",
    keyPoints: [
      "Seeds contain embryo (baby plant), cotyledons (food storage), and seed coat (protection)",
      "Seeds are alive but dormant—waiting for the right conditions",
      "Seeds need water, warmth, and eventually light to germinate",
      "Use the 'packed lunch' analogy to explain seed structure",
      "Establish observation and scientific inquiry habits from Day 1"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "Today we're starting a journey where YOU will become plant scientists and growers. By the end of this course, you'll have grown actual food from tiny seeds. But first, we need to understand: what exactly IS a seed?"

Hold up a dry bean seed.

What to say: "This might look like just a hard, dead object. But inside this seed is something incredible—a baby plant that's just waiting for the right conditions to wake up. Today we're going to become seed detectives."

**GUIDED INSTRUCTION (20 min):**

Activity: Seed Dissection

What to say: "I'm going to give you soaked bean seeds that are easier to open. When you carefully peel apart your seed, you're going to look for THREE main parts. Think of the seed like a packed lunch for a trip."

Distribute soaked seeds and have students carefully separate the two halves.

What to say while they work: "The two big halves you see are called COTYLEDONS (kaa·tuh·lee·dnz). These are like packed food for the baby plant. Can anyone tell me what you pack for a long trip? [Pause for answers] Food, right? These cotyledons are the plant's food supply."

**SEED STRUCTURE:**
• Seed Coat — Protective shell (like a lunchbox)
• Cotyledons — Food storage (like packed sandwiches)
• Embryo — Baby plant (the traveler)

What to say: "Now look very carefully between the cotyledons. Do you see something tiny and different-looking? That's the EMBRYO—the actual baby plant. It's so small! And finally, that outer coating you peeled off? That's the SEED COAT. It's like armor protecting everything inside."

**CONCEPT DEEPENING (15 min):**

What to say: "Now here's a question to think deeply about: Why do you think the baby plant needs food stored inside the seed? Why can't it just make food right away?"

Guide discussion toward:
• Baby plants can't photosynthesize until they have leaves
• The seed might be underground where there's no sunlight
• The stored food gives the plant energy to push through soil

Follow-up question: "If seeds have food stored inside, what do you think they need from the OUTSIDE environment to wake up and start growing?"

List student ideas on board, guiding toward: WATER, WARMTH, (eventually) LIGHT`,
    practiceActivity: `**SKILL PRACTICE (10 min):**

Have students draw and label their own seed diagram with all three parts. They should include:
• Seed coat (and what it does)
• Cotyledons (and what they do)
• Embryo (and what it becomes)

**Higher-level challenge question:** "Some seeds are huge like coconuts, and some are tiny like lettuce seeds. What might be the advantage of each size?"

**LESSON CLOSING (5 min):**

What to say: "Tomorrow we're going to start the process of waking up our seeds—germination. Tonight, think about this: If you were a seed buried in soil, what would tell you it's safe to start growing? We'll explore that tomorrow."

**Exit ticket:** Write one surprising thing you learned about seeds today.`,
    teachingTips: [
      "Soak bean seeds 24 hours before class for easy dissection",
      "Have magnifying glasses available for embryo viewing",
      "Use the 'packed lunch' analogy consistently",
      "Allow time for students to explore and ask questions",
      "Connect to students' prior experiences with seeds"
    ],
    commonMistakes: [
      "Rushing through the dissection activity",
      "Not soaking seeds long enough for easy opening",
      "Using technical terms without kid-friendly explanations",
      "Skipping the 'why' questions that build understanding",
      "Not setting up the germination preview for tomorrow"
    ]
  },
  "2-2": {
    overview: "Students set up germination experiments using a wick-based system, make predictions about different seed types, and begin their observation logs.",
    keyPoints: [
      "Germination = when a seed starts to grow",
      "Use the paper towel wick system for consistent moisture",
      "Different seeds germinate at different rates",
      "Scientists always make PREDICTIONS before experiments",
      "Establish observation and documentation habits"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "Yesterday we learned that seeds are alive but sleeping. Today we're going to WAKE THEM UP. Scientists call this process GERMINATION. It's when the baby plant inside breaks out of its protective coat and starts growing."

Write on board: GERMINATION = When a seed starts to grow

What to say: "But here's our scientific question for today: Do ALL seeds germinate the same way and at the same speed? We're going to design an experiment to find out."

**LAB INTRODUCTION (15 min):**

Demonstrate the seed starting tray method:

What to say while demonstrating: "We're going to create perfect conditions for germination using a simple system. Watch carefully—you'll build your own in a moment."

**Step-by-step demonstration:**
1. Show plastic container: "This will be our germination chamber."
2. Use soldering iron to melt two small slits in the lid: "I'm creating two openings for our wick system. SAFETY NOTE: Only teachers use the soldering iron."
3. Thread paper towel through slits: "This paper towel will act like a drinking straw, constantly pulling water up from below."
4. Fill container bottom with water: "About 1 inch of water."
5. Place lid upside down: "Now the paper towel ends are sitting in the water."
6. Place seeds on moist paper towel: "Spread them out so they're not touching."
7. Sprinkle with soil and cover: "Just a light coating to keep them moist."

What to say: "This system keeps our seeds at the perfect moisture level. The paper towel pulls water up automatically—it's using CAPILLARY ACTION, which we'll explore more later."

**EXPERIMENTAL DESIGN (10 min):**

What to say: "Here's where YOU become the scientist. We're going to test different types of seeds to see which germinates fastest. Each pair will test TWO different seed types."

Available seeds: Lettuce, radish, basil, tomato, bean, sunflower

What to say: "Scientists always make PREDICTIONS before they experiment. Based on the seed sizes you see, which do you think will germinate first? Write your prediction and explain your reasoning."`,
    practiceActivity: `**OBSERVATION LOG SETUP:**

Provide observation sheet:

GERMINATION OBSERVATION LOG

Name: ________________  Partner: ________________
Seed Type 1: ____________  Seed Type 2: ____________
My Prediction: _________________________________________

Day 1 (Today) - Date: ______
Seed 1: ☐ No change  ☐ Swelling  ☐ Cracking  ☐ Root visible  ☐ Sprout visible
Seed 2: ☐ No change  ☐ Swelling  ☐ Cracking  ☐ Root visible  ☐ Sprout visible

[Continue through Day 7]

**Higher-level thinking question:** "Seeds in nature don't have paper towels and plastic containers. How do you think they get the moisture they need? And why might some seeds wait months or even years before germinating?"

**Homework:** Observe something growing in your neighborhood (tree, grass, weeds, houseplant). Sketch it and bring it to class Wednesday.`,
    teachingTips: [
      "Pre-drill or melt all container lids before class for safety",
      "Have students work in pairs for collaboration",
      "Emphasize making predictions BEFORE starting",
      "Create a class prediction chart to track together",
      "Set up reminder system for daily observations"
    ],
    commonMistakes: [
      "Not preparing materials in advance",
      "Letting students use soldering iron (teacher only!)",
      "Too much water drowning seeds",
      "Seeds touching each other (causes mold)",
      "Skipping the prediction step"
    ]
  },
  "2-3": {
    overview: "Students build self-watering bottle planters from recycled materials, learning engineering design while creating sustainable growing systems.",
    keyPoints: [
      "Self-watering planters use capillary action (wicking)",
      "Recycled bottles become functional growing systems",
      "Plants need containers that hold soil, drain excess water, and provide moisture",
      "Transplanting requires gentle handling to protect roots",
      "Students gain ownership through building their own systems"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "You've learned that seeds need moisture to germinate. But once they sprout, baby plants need somewhere to grow. Today you're going to solve a real-world problem: How can we create planters using materials that would otherwise be trash?"

Show examples of bottle planters from previous classes/photos

What to say: "These are self-watering planters made from recycled bottles. They use the same principle as our seed trays—wicking. But these are designed for bigger plants. Today, you're going to engineer your own."

**ENGINEERING CHALLENGE (5 min):**

What to say: "Before we build, let's think like engineers. What does a plant need from a container?"

List on board as students brainstorm:
• Holds soil
• Allows drainage (roots don't want to sit in water)
• Provides water (but not too much)
• Room to grow

**DEMONSTRATION BUILD (15 min):**

Step 1: Prepare the bottle
What to say: "Cut your bottle about one-third from the top. Save both pieces—we'll use them both. The bottom becomes our water reservoir."

Step 2: Create drainage and wicking
What to say: "Punch holes in the bottle cap—about 5-7 holes. These let water wick up but also let excess drain down. Now thread a strip of cloth through the cap. This cloth is our wick—it'll pull water up to the roots."

Step 3: Assembly
What to say: "Flip the top part upside down and place it into the bottom part—like a funnel. The cloth should hang down into the water reservoir. Pour water in the bottom section."

Step 4: Add soil and seedlings
What to say: "Fill with soil, and we'll transplant seedlings that were started a couple weeks ago."

**SELF-WATERING BOTTLE PLANTER DIAGRAM:**

Top section (inverted): SOIL + SEEDLING
↓ Bottle cap with holes
↓ CLOTH WICK (pulls water up)
Bottom section: WATER RESERVOIR`,
    practiceActivity: `**STUDENT BUILD TIME (25 min):**

Students work in pairs to create their planters. Provide pre-started seedlings for immediate transplanting.

While circulating, prompt thinking:
• "Why do you think we inverted the top instead of just putting holes in the bottom?"
• "What would happen if the cloth wick was too short? Too long?"
• "How will you know when to refill the water reservoir?"

For advanced students: "Can you design a system to connect multiple bottles together? What would be the advantages?"

**TRANSPLANTING PRACTICE (10 min):**

What to say: "Transplanting is a skill you'll use constantly in plant growing. The goal is to move the plant WITHOUT damaging its roots. Roots are like the plant's mouth—damage them and it can't eat."

Demonstrate gentle transplanting:
1. Support the stem between your fingers
2. Tip the container and gently tap to loosen
3. Keep the root ball intact
4. Create a hole in new soil
5. Place plant and firm soil around it gently
6. Water immediately

**Exit ticket:** Sketch one improvement you'd make to this planter design.`,
    teachingTips: [
      "Have students bring bottles from home in advance",
      "Pre-cut bottles for younger students",
      "Use old t-shirts cut into strips for wicks",
      "Demonstrate transplanting multiple times",
      "Celebrate creative design variations"
    ],
    commonMistakes: [
      "Bottles not cut evenly (wobble when assembled)",
      "Wick too short to reach water reservoir",
      "Too much or too little soil",
      "Damaging roots during transplanting",
      "Not watering immediately after transplanting"
    ]
  },
  "4-3": {
    overview: "Introduce students to growing plants without soil using Deep Water Culture (DWC) hydroponics. Students learn the science behind hydroponics and begin building their systems.",
    keyPoints: [
      "Hydroponics = growing plants in water with dissolved nutrients",
      "Soil provides support, water, oxygen, and nutrients—hydroponics must replace all of these",
      "Deep Water Culture (DWC) is the simplest hydroponic method",
      "Plants often grow 30-50% faster in hydroponics due to direct nutrient access",
      "Air pumps provide essential oxygen to submerged roots"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "Everything you've learned so far has been about growing in SOIL. But today, you're going to see that soil isn't actually necessary for plant growth. You're about to enter the world of HYDROPONICS—growing plants in water."

Show example of established hydroponic system with healthy plants.

What to say: "These plants are growing with their roots sitting directly in water. No soil at all. How is this possible? What does soil actually DO for plants that we need to replace?"

**List on board as students brainstorm:**

WHAT SOIL PROVIDES:
• SUPPORT/ANCHOR — Holds plant upright
• WATER — Stores moisture for roots
• OXYGEN — Air spaces between soil particles
• NUTRIENTS — Minerals dissolved in water

HYDROPONICS MUST PROVIDE:
• SUPPORT → Use growing medium (clay pebbles) + net pots
• WATER → Direct water access!
• OXYGEN → Bubbles/water movement/air gaps
• NUTRIENTS → Add nutrients to water

What to say: "In hydroponics, we control everything precisely. Plants often grow FASTER because they don't have to search for water and nutrients—we deliver everything directly."

**SYSTEM OVERVIEW (15 min):**

What to say: "We're building a DEEP WATER CULTURE system—one of the simplest hydroponic methods. Let me show you how it works."

**DEEP WATER CULTURE (DWC) SYSTEM:**

The plant sits in a net pot filled with clay pebbles. Roots grow down into the nutrient-enriched water. An air pump constantly bubbles oxygen into the water—remember, roots need oxygen just like we do! The bubbles also help distribute nutrients evenly.

**ADVANTAGES & DISADVANTAGES:**

HYDROPONICS ADVANTAGES:
• Faster growth (30-50% quicker)
• Uses 90% less water overall
• No soil-borne diseases
• Precise nutrient control
• Can grow anywhere (cities, deserts, indoors)
• No weeding!

HYDROPONICS DISADVANTAGES:
• More expensive setup
• Requires electricity (pump)
• More technical knowledge needed
• System failure = rapid plant death
• pH and nutrients need monitoring`,
    practiceActivity: `**BUILD DEMONSTRATION (20 min):**

What to say: "Now I'm going to demonstrate the build process step by step. Tomorrow you'll build your own systems in groups."

**Step-by-step demonstration:**

Step 1: Prepare the reservoir (5-gallon bucket)
"This bucket will hold our nutrient solution. First, drill a small hole near the bottom for the air tube."

Step 2: Prepare the grow container (2-gallon bucket)
"This container sits inside the 5-gallon bucket and holds our plant. We need to drill a large hole in the lid for the net pot."

Step 3: Create the net pot support
"Pool noodle foam provides flotation and support. It ensures the net pot stays at the correct water level."

Step 4: Prepare clay pebbles
"Rinse until water runs clear. Clay dust can clog roots."

Step 5: Install air pump
"Thread the air line through the hole we drilled. Attach an airstone to the end inside the bucket."

**SYSTEM CARE INTRODUCTION:**

DAILY:
• Check that pump is running and bubbling
• Observe plant health (color, wilting, growth)
• Check water level

WEEKLY:
• Top off water as needed
• Check pH (should be 5.5-6.5)
• Clean any algae

EVERY 2 WEEKS:
• Completely change nutrient solution
• Rinse reservoir
• Inspect roots (should be white/cream, not brown/slimy)

**Exit ticket:** List three ways hydroponics differs from soil growing. Which system do you think YOU would prefer and why?`,
    teachingTips: [
      "Pre-drill all holes before class for safety",
      "Have an established hydroponic plant to show results",
      "Emphasize the pump as 'life support'—never let it stop",
      "Connect to real-world applications (commercial farms)",
      "Address the 'is it natural?' question head-on"
    ],
    commonMistakes: [
      "Not rinsing clay pebbles thoroughly",
      "Placing air pump below water level (causes siphon)",
      "Forgetting to check pH",
      "Letting nutrient solution get too low",
      "Not providing enough light for hydro plants"
    ]
  },
  "7-1": {
    overview: "Transform students into plant diagnosticians who can systematically identify and solve common growing problems including environmental stress, pests, and diseases.",
    keyPoints: [
      "Use systematic diagnostic approach: Observe → Categorize → Eliminate → Test → Prevent",
      "Problems fall into 5 categories: Environmental, Water, Nutritional, Pests, Diseases",
      "Location of symptoms helps diagnosis (old vs. new leaves)",
      "Catching issues EARLY is key to success",
      "Integrated Pest Management (IPM) starts with prevention"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "You've successfully grown plants from seed to harvest. But even experienced growers face problems—pests, diseases, nutrient deficiencies, environmental stress. Today you're going to become plant diagnosticians. You'll learn to identify problems quickly and fix them before crops fail. This troubleshooting skill separates beginners from expert growers!"

Show side-by-side comparison: Healthy plant vs. plant with problems

What to say: "Both plants started identically. One got early intervention when problems appeared. The other's problems went untreated. Catching issues EARLY is the key to success. Let's learn how."

**SYSTEMATIC DIAGNOSTIC APPROACH (15 min):**

What to say: "Professional growers don't guess—they use systematic diagnosis. You're going to learn a step-by-step process that works for ANY plant problem."

**THE PLANT DIAGNOSTIC PROCESS:**

STEP 1: OBSERVE CAREFULLY
☐ WHERE is the problem? (old leaves, new leaves, stems, roots?)
☐ WHAT does it look like? (color, texture, pattern, location)
☐ WHEN did it start? (sudden or gradual?)
☐ WHICH plants? (all of them or just some?)

STEP 2: CONSIDER THE CATEGORIES
Problems fall into 5 categories:
1. Environmental (light, temperature, humidity, air flow)
2. Water-related (too much, too little, quality issues)
3. Nutritional (deficiency or excess)
4. Pests (insects, mites, etc.)
5. Diseases (fungi, bacteria, viruses)

STEP 3: USE PROCESS OF ELIMINATION
Start with the EASIEST to diagnose and fix:
→ Environmental issues (quick to spot and fix)
→ Water problems (common, observable)
→ Nutritional deficiencies (predictable patterns)
→ Pests (visible with magnification)
→ Diseases (hardest to diagnose)

STEP 4: TEST YOUR HYPOTHESIS
• Make one change at a time
• Observe for 3-7 days
• Did it improve? → Correct diagnosis!
• No change? → Try next hypothesis

STEP 5: PREVENT RECURRENCE
Once solved, adjust practices to prevent future problems`,
    practiceActivity: `**DIAGNOSTIC SCENARIOS (20 min):**

Present these scenarios and have students diagnose:

SCENARIO 1: Leggy, Stretched Plants
• Long spaces between leaves
• Pale green or yellowish color
• Weak, floppy stems
• Plants leaning toward window

DIAGNOSIS: Insufficient light
SOLUTION: Move closer to light, add more lights, increase duration

SCENARIO 2: Wilting Despite Moist Soil
• Drooping leaves
• Soil is wet
• Roots may smell bad

DIAGNOSIS: Root rot from overwatering
SOLUTION: Improve drainage, reduce watering, check roots

SCENARIO 3: Brown Crispy Leaf Edges
• Starts on older leaves
• Plants otherwise healthy
• No pests visible

DIAGNOSIS: Potassium deficiency or underwatering
SOLUTION: Add potassium fertilizer, check watering schedule

**COMMON PESTS TO IDENTIFY:**

APHIDS: Tiny soft-bodied insects, cluster on new growth, leave sticky residue
FUNGUS GNATS: Small black flies around soil, larvae eat roots
SPIDER MITES: Microscopic, fine webbing on leaves, stippled yellowing
WHITEFLIES: Tiny white flies, fly up in cloud when disturbed

**Exit ticket:** Describe the 5-step diagnostic process in your own words. Why is it important to make only ONE change at a time when testing a solution?`,
    teachingTips: [
      "Create 'problem plant' stations for hands-on diagnosis",
      "Use photos when live problem plants aren't available",
      "Emphasize PREVENTION over treatment",
      "Connect symptoms to underlying plant biology",
      "Build a class 'troubleshooting guide' as you go"
    ],
    commonMistakes: [
      "Jumping to conclusions without systematic observation",
      "Making multiple changes at once (can't identify what worked)",
      "Ignoring early warning signs until problems are severe",
      "Using chemicals as first response (should be last resort)",
      "Not documenting problems and solutions for future reference"
    ]
  },
  "5-1": {
    overview: "Explore the intricate anatomy of flowers and understand how each part contributes to plant reproduction. Students will learn to identify the four layers of flower structure.",
    keyPoints: [
      "Flowers are reproductive structures designed to produce seeds",
      "Four layers: Sepals (protection), Petals (attraction), Stamens (male), Pistils (female)",
      "Complete flowers have all four parts; incomplete flowers lack one or more",
      "Perfect flowers have both male and female parts; imperfect have only one",
      "Flower adaptations reflect their pollination strategies"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "For weeks, you've been growing VEGETATIVE plants—leaves and stems. But plants have a mission beyond just growing: REPRODUCTION. Flowers are the reproductive organs of plants, and understanding them unlocks how plants make seeds, fruits, and the next generation."

Hold up a flower (lily works great for visibility):

What to say: "This isn't just pretty—it's a complex reproductive factory. Today you're going to learn to read the parts of a flower like an instruction manual."

**FLOWER ANATOMY OVERVIEW (20 min):**

What to say: "Flowers have up to FOUR distinct layers, like rings in a target. Let's start from the outside and work our way in."

**THE FOUR LAYERS (from outside to inside):**

**LAYER 1: SEPALS (The Protectors)**
• Outermost layer, usually green
• Protected the flower when it was a bud
• Sometimes fall off when flower opens
• Collectively called the CALYX

**LAYER 2: PETALS (The Attractors)**
• Usually colorful and showy
• Primary job: Attract pollinators
• May have scent, nectar guides, UV patterns
• Collectively called the COROLLA

**LAYER 3: STAMENS (The Male Parts)**
• Produce POLLEN (contains sperm cells)
• Two parts: FILAMENT (stalk) and ANTHER (pollen factory)
• Usually multiple stamens per flower
• May be tall or short depending on pollination strategy

**LAYER 4: PISTIL/CARPEL (The Female Part)**
• Receives pollen and produces seeds
• Three parts: STIGMA (sticky landing pad), STYLE (tube), OVARY (contains eggs/ovules)
• Usually in the center of the flower
• Ovary becomes the FRUIT after fertilization

What to say: "Think of it like a factory: Sepals are security guards protecting the building. Petals are the advertising department attracting customers. Stamens are the shipping department sending out pollen. And the pistil is where the actual product—seeds—are made!"`,
    practiceActivity: `**FLOWER CLASSIFICATION (15 min):**

What to say: "Not all flowers have all four parts. Let's learn the vocabulary for describing different flower types."

**COMPLETE vs. INCOMPLETE:**
• COMPLETE: Has all 4 parts (sepals, petals, stamens, pistil)
• INCOMPLETE: Missing one or more parts

Examples:
• Lily = Complete (all 4 parts)
• Grass flower = Incomplete (no petals)
• Tulip = Complete

**PERFECT vs. IMPERFECT:**
• PERFECT: Has BOTH stamens AND pistil (can self-pollinate)
• IMPERFECT: Has only stamens OR only pistil (needs partner)

Examples:
• Tomato = Perfect (male and female in same flower)
• Squash = Imperfect (separate male and female flowers)
• Corn = Imperfect (tassels are male, ears are female)

**DISCUSSION QUESTIONS:**

1. "What color were your petals? Why might evolution favor bright colors?"
Guide toward: Visibility to pollinators, different colors attract different pollinators

2. "The ovary becomes fruit, and ovules become seeds. So what's a tomato—fruit or vegetable?"
Answer: FRUIT! It's a ripened ovary. Cucumbers, peppers, squash—all fruits botanically!

3. "If you removed all the petals from a flower, could it still reproduce?"
Answer: Yes! Petals just attract pollinators. Wind-pollinated plants often have no petals.

**Exit ticket:** Label a blank flower diagram with all four layers and explain the function of each part.`,
    teachingTips: [
      "Use large flowers (lilies) for easy observation",
      "Have students draw their own diagrams while you teach",
      "Connect to grocery store produce—what's really a fruit?",
      "Discuss why some flowers smell good and others don't",
      "Preview pollination lesson for tomorrow"
    ],
    commonMistakes: [
      "Using flowers that are too small or complex",
      "Rushing through the layers without student interaction",
      "Not connecting structure to function",
      "Forgetting to discuss incomplete/imperfect flowers",
      "Making reproduction 'awkward' instead of scientific"
    ]
  },
  "6-1": {
    overview: "Teach students to assess harvest readiness across different crop types and understand the science behind optimal harvest timing.",
    keyPoints: [
      "Different crops have different harvest indicators (size, color, texture, timing)",
      "Harvesting at peak ripeness maximizes nutrition and flavor",
      "Cut-and-come-again harvesting extends productive life of plants",
      "Proper harvest technique prevents plant damage",
      "Timing matters: morning harvest often best for freshness"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "You've spent weeks nurturing your plants from seed. Now comes the reward—HARVEST! But timing matters. Harvest too early: underdeveloped flavor and nutrition. Harvest too late: bitter, bolting, or spoiled. Today you're going to learn to read the signs of harvest readiness like a professional farmer."

Show comparison: perfectly ripe vs. over-mature lettuce (showing bolting)

What to say: "See the difference? The first is sweet and tender. The second is bitter and tough. Same plant, different timing! Understanding when to harvest is as important as knowing how to grow."

**HARVEST READINESS INDICATORS (20 min):**

What to say: "Different crops signal readiness in different ways. Let's learn the indicators for our classroom crops."

**LETTUCE & LEAFY GREENS:**
READY WHEN:
• Outer leaves are full-sized (4-6 inches for most varieties)
• Before center starts elongating (bolting)
• Leaves are firm and crisp, not limp

NOT READY:
• Leaves too small
• Beginning to bolt (center stretching upward)
• Yellow or damaged leaves

BEST TECHNIQUE: Cut-and-come-again
• Harvest outer leaves only
• Leave center growing point intact
• Plant continues producing for weeks!

**BASIL & HERBS:**
READY WHEN:
• Plants are 6+ inches tall
• Multiple sets of true leaves developed
• Before flowering (flowers reduce leaf quality)

HARVEST TECHNIQUE: Pinching
• Cut stem just above a leaf node
• Plant branches from that point
• Regular harvesting encourages bushier growth

**ROOT VEGETABLES (Radish, Carrot):**
READY WHEN:
• Shoulders visible above soil line
• Proper size for variety (check seed packet)
• Leaves healthy and vigorous

**FRUITING PLANTS (Tomato, Pepper):**
READY WHEN:
• Full color development (red, orange, etc.)
• Slight give when gently squeezed
• Easily separates from plant with light twist`,
    practiceActivity: `**HARVEST ASSESSMENT ACTIVITY (15 min):**

What to say: "Now you're going to assess your own classroom plants for harvest readiness. Be honest and scientific!"

**Students complete assessment forms:**

HARVEST READINESS ASSESSMENT

Plant Type: ________________
Location: ________________
Age (weeks since planting): ____

VISUAL INSPECTION:
☐ Appropriate size for variety
☐ Good color (describe): ____________
☐ No signs of bolting
☐ Healthy appearance

PHYSICAL INSPECTION:
☐ Leaves/fruit firm (not limp)
☐ Proper texture
☐ Good aroma (for herbs)

HARVEST DECISION:
☐ Ready to harvest now
☐ Needs 1-2 more days
☐ Needs 1 week or more
☐ Past prime (should have harvested earlier)

RECOMMENDED TECHNIQUE:
☐ Cut-and-come-again
☐ Pinching (herbs)
☐ Full plant harvest
☐ Fruit picking

Notes: ________________

**While students assess, circulate and guide:**
• "Gently feel that leaf—is it crisp or limp?"
• "Look at the center—do you see a flower stalk forming?"
• "Compare hydroponic vs. soil—which is bigger?"
• "Smell this leaf—strong aroma indicates good essential oil content."

**LESSON CLOSING:**

What to say: "Tomorrow is HARVEST DAY! We'll harvest from your plants using proper techniques, weigh our yields, and start analyzing the nutrition in what you've grown. Bring your appetites—we might do some taste testing!"

**Exit ticket:** Draw a plant and show where/how you would harvest it using the cut-and-come-again method.`,
    teachingTips: [
      "Build excitement for harvest day",
      "Have examples of ready vs. not-ready produce",
      "Emphasize 'cut-and-come-again' for extended harvests",
      "Discuss optimal harvest time (morning often best)",
      "Preview the yield comparison between systems"
    ],
    commonMistakes: [
      "Harvesting before plants are truly ready",
      "Harvesting entire plant when cut-and-come-again would work",
      "Damaging growth points during harvest",
      "Not recognizing bolting signs early enough",
      "Harvesting at hottest part of day (wilts faster)"
    ]
  },
  "7-3": {
    overview: "Teach succession planting strategies for continuous harvests and guide students in creating year-round growing calendars.",
    keyPoints: [
      "Succession planting = staggering plantings for continuous harvest",
      "Calculate planting intervals based on days to maturity and desired harvest frequency",
      "Four strategies: time-based, space-based, variety-based, and overlapping production",
      "Year-round indoor growing is possible with proper planning",
      "Crop rotation prevents pest/disease buildup"
    ],
    detailedContent: `**LESSON OPENING (10 min):**

What to say: "You've learned to grow plants from seed to harvest. But here's the problem: After harvest, you have empty space. What if you could have CONTINUOUS harvests—fresh food every week, year-round? Today you're going to learn SUCCESSION PLANTING—the professional technique for non-stop production."

Show comparison:
• Beginner approach: Plant everything at once → Harvest all at once → Nothing until replant
• Professional approach: Stagger plantings → Harvest continuously → Always have crops at different stages

**SUCCESSION PLANTING STRATEGIES (15 min):**

**STRATEGY 1: TIME-BASED SUCCESSION**
Plant the same crop every X weeks/days

Example: Lettuce
• Week 1: Plant batch 1
• Week 3: Plant batch 2
• Week 5: Plant batch 3
• Week 7: Harvest batch 1, plant batch 4
→ Continuous harvest every 2 weeks!

**STRATEGY 2: SPACE-BASED SUCCESSION**
Divide growing area into sections, plant each on different schedule

Example: 4 shelf sections
• Section A: Week 1 planting → harvest week 6
• Section B: Week 2 planting → harvest week 7
• Section C: Week 3 planting → harvest week 8
• Section D: Week 4 planting → harvest week 9
→ Always have 3 sections growing, 1 ready to harvest!

**STRATEGY 3: VARIETY-BASED SUCCESSION**
Plant varieties with different maturity dates simultaneously

Example: Lettuce varieties
• Fast variety (45 days)
• Medium variety (60 days)
• Slow variety (75 days)
All planted same day → harvest every 2 weeks!

**STRATEGY 4: CUT-AND-COME-AGAIN + NEW PLANTINGS**
Harvest continuously from existing plants WHILE starting new plants

**CALCULATING SUCCESSION INTERVALS:**

Formula: Planting interval = Days to maturity ÷ Number of successive harvests desired

Example:
• Lettuce: 45 days to maturity
• Want harvests every 2 weeks (14 days)
• Need: 45 ÷ 14 = 3.2 → 3-4 batches in rotation`,
    practiceActivity: `**CREATE YOUR GROWING CALENDAR (25 min):**

What to say: "Now you're going to create a year-long succession planting calendar. This can be for classroom growing or your home setup."

**Students complete calendar template:**

SUCCESSION PLANTING CALENDAR

Grower: _____________ Year: _____

GROWING SYSTEM CAPACITY:
Total growing spaces: _____
Spaces per batch: _____
Number of batches in rotation: _____

PRIMARY CROP: _________________
Days to maturity: _____
Harvest interval goal: Every _____ days/weeks
Batches needed: _____

**MONTHLY PLANTING SCHEDULE:**

JANUARY:
Week 1: Plant ____________
Week 2: Plant ____________
Week 3: Plant ____________
Week 4: Plant ____________

[Continue for all 12 months]

**HARVEST PROJECTIONS:**
Month | Crop | Expected Harvest
________________________
________________________
________________________

**While students work, circulate and assist:**
• "How many plants can you realistically maintain?"
• "Calculate your interval: days to maturity ÷ desired harvest frequency"
• "Color-code your calendar—different colors for different crops"

**CROP ROTATION CONCEPT (10 min):**

What to say: "Even indoors, rotating crop families helps prevent pest and disease buildup."

SIMPLE RULE:
• Follow heavy feeders (lettuce) with light feeders (herbs)
• Don't grow same family in same spot repeatedly
• Refresh soil or clean hydroponic systems between cycles

**Exit ticket:** "If you want to harvest lettuce every 10 days, and lettuce takes 50 days to mature, how many staggered plantings do you need in rotation?"`,
    teachingTips: [
      "Start with simple 2-crop rotation before getting complex",
      "Use color-coding on calendars for visual clarity",
      "Connect to real-world farming practices",
      "Emphasize flexibility—calendars will need adjustment",
      "Encourage students to continue calendars at home"
    ],
    commonMistakes: [
      "Over-planning without accounting for failures",
      "Not leaving buffer time between batches",
      "Ignoring seasonal growth rate variations",
      "Making calendar too rigid to adapt",
      "Planting more than can be properly maintained"
    ]
  }
};

export const getModuleColor = (moduleId: number): string => {
  const module = trainingModules.find(m => m.id === moduleId);
  return module?.color || "#2D7A4F";
};

export const getLessonTypeIcon = (type: LessonType): string => {
  const icons: Record<LessonType, string> = {
    concept: "book",
    practical: "tool",
    checklist: "check-square",
    scenario: "zap",
    lab: "flask",
    build: "package",
  };
  return icons[type] || "file-text";
};

export const getLessonTypeLabel = (type: LessonType): string => {
  const labels: Record<LessonType, string> = {
    concept: "Concept",
    practical: "Practical",
    checklist: "Checklist",
    scenario: "Scenario",
    lab: "Lab",
    build: "Build",
  };
  return labels[type] || "Lesson";
};

export const getTotalLessons = (): number => {
  return trainingModules.reduce((sum, mod) => sum + mod.lessons.length, 0);
};
