import { Feather } from "@expo/vector-icons";

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: keyof typeof Feather.glyphMap;
  color: string;
  type: "module" | "milestone" | "quiz" | "special";
  requirement: {
    type: "lessons_complete" | "module_complete" | "quiz_passed" | "all_complete";
    value?: number;
    moduleId?: number;
  };
}

export const achievements: Achievement[] = [
  {
    id: "first-lesson",
    title: "First Steps",
    description: "Complete your first lesson",
    icon: "award",
    color: "#4A7FA6",
    type: "milestone",
    requirement: { type: "lessons_complete", value: 1 }
  },
  {
    id: "getting-started",
    title: "Ready to Grow",
    description: "Complete the Getting Started module",
    icon: "book-open",
    color: "#4A7FA6",
    type: "module",
    requirement: { type: "module_complete", moduleId: 1 }
  },
  {
    id: "seed-master",
    title: "Seed Master",
    description: "Complete Week 1: What Are Seeds?",
    icon: "sun",
    color: "#2D7A4F",
    type: "module",
    requirement: { type: "module_complete", moduleId: 2 }
  },
  {
    id: "seedling-pro",
    title: "Seedling Pro",
    description: "Complete Week 2: From Seeds to Seedlings",
    icon: "trending-up",
    color: "#7B68A8",
    type: "module",
    requirement: { type: "module_complete", moduleId: 3 }
  },
  {
    id: "hydro-hero",
    title: "Hydro Hero",
    description: "Complete Week 3: Water, Light & Hydroponics",
    icon: "droplet",
    color: "#E8A43E",
    type: "module",
    requirement: { type: "module_complete", moduleId: 4 }
  },
  {
    id: "pollination-expert",
    title: "Pollination Expert",
    description: "Complete Week 4: Reproduction & Pollination",
    icon: "heart",
    color: "#C74940",
    type: "module",
    requirement: { type: "module_complete", moduleId: 5 }
  },
  {
    id: "harvest-master",
    title: "Harvest Master",
    description: "Complete Week 5: Harvest, Nutrition & Economics",
    icon: "award",
    color: "#5A6FA8",
    type: "module",
    requirement: { type: "module_complete", moduleId: 6 }
  },
  {
    id: "optimization-guru",
    title: "Optimization Guru",
    description: "Complete Week 6: Optimization & Final Projects",
    icon: "target",
    color: "#D4A936",
    type: "module",
    requirement: { type: "module_complete", moduleId: 7 }
  },
  {
    id: "halfway-there",
    title: "Halfway There",
    description: "Complete 50% of all lessons",
    icon: "zap",
    color: "#F59E0B",
    type: "milestone",
    requirement: { type: "lessons_complete", value: 17 }
  },
  {
    id: "quiz-ace",
    title: "Quiz Ace",
    description: "Pass your first module quiz",
    icon: "check-circle",
    color: "#22C55E",
    type: "quiz",
    requirement: { type: "quiz_passed", value: 1 }
  },
  {
    id: "quiz-master",
    title: "Quiz Master",
    description: "Pass all module quizzes",
    icon: "star",
    color: "#EAB308",
    type: "quiz",
    requirement: { type: "quiz_passed", value: 7 }
  },
  {
    id: "certified-teacher",
    title: "Certified Teacher",
    description: "Complete all lessons and quizzes",
    icon: "award",
    color: "#2D7A4F",
    type: "special",
    requirement: { type: "all_complete" }
  }
];

export const getAchievementById = (id: string): Achievement | undefined => {
  return achievements.find(a => a.id === id);
};
