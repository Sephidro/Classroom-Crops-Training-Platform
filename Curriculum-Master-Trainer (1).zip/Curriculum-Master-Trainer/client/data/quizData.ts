export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface ModuleQuiz {
  moduleId: number;
  title: string;
  passingScore: number;
  questions: QuizQuestion[];
}

export const moduleQuizzes: ModuleQuiz[] = [
  {
    moduleId: 1,
    title: "Getting Started Quiz",
    passingScore: 70,
    questions: [
      {
        id: "1-q1",
        question: "What is the core learning model used in the Classroom Crops curriculum?",
        options: [
          "Read → Memorize → Test → Forget",
          "Unlock → Practice → Master → Apply → Advance",
          "Watch → Listen → Write → Repeat",
          "Lecture → Homework → Exam → Grade"
        ],
        correctIndex: 1,
        explanation: "The Classroom Crops curriculum uses a progressive 'Unlock → Practice → Master → Apply → Advance' model where each concept builds on previous knowledge."
      },
      {
        id: "1-q2",
        question: "Which day is designated as 'Lab Day' in the weekly structure?",
        options: ["Monday", "Tuesday", "Wednesday", "Thursday"],
        correctIndex: 1,
        explanation: "Tuesday is Lab Day, focused on hands-on investigation, data collection, and the scientific method."
      },
      {
        id: "1-q3",
        question: "What is the primary advantage of hands-on learning over passive learning?",
        options: [
          "It's faster to complete",
          "Students construct knowledge through experience",
          "It requires less teacher preparation",
          "Students can skip difficult concepts"
        ],
        correctIndex: 1,
        explanation: "Constructivist learning theory shows that students don't receive knowledge passively—they construct it through experience, leading to deeper understanding and retention."
      },
      {
        id: "1-q4",
        question: "What is the focus of Build Day (Wednesday)?",
        options: [
          "Taking quizzes and assessments",
          "Reading textbook chapters",
          "DIY projects, problem-solving, and engineering design",
          "Guest speaker presentations"
        ],
        correctIndex: 2,
        explanation: "Wednesday Build Day focuses on constructing growing systems and tools, applying engineering design process, and solving real-world problems with materials."
      },
      {
        id: "1-q5",
        question: "Which of the following is NOT provided by the Classroom Crops curriculum?",
        options: [
          "Weekly lesson structure",
          "Plant care schedules",
          "Teacher certification for professional development credits",
          "What to say scripts"
        ],
        correctIndex: 2,
        explanation: "While the curriculum provides comprehensive teaching materials, professional certification for CEU credits is a separate process not included in the base curriculum."
      }
    ]
  },
  {
    moduleId: 2,
    title: "Week 1: Seeds Quiz",
    passingScore: 70,
    questions: [
      {
        id: "2-q1",
        question: "What are the three main parts of a seed?",
        options: [
          "Root, stem, leaf",
          "Seed coat, cotyledons, embryo",
          "Petal, stamen, pistil",
          "Soil, water, light"
        ],
        correctIndex: 1,
        explanation: "Seeds contain three main parts: the seed coat (protection), cotyledons (food storage), and embryo (baby plant)."
      },
      {
        id: "2-q2",
        question: "What is germination?",
        options: [
          "When a plant makes flowers",
          "When a seed starts to grow",
          "When leaves turn green",
          "When roots absorb water"
        ],
        correctIndex: 1,
        explanation: "Germination is the process when a seed starts to grow—when the embryo breaks out of the protective seed coat and begins developing."
      },
      {
        id: "2-q3",
        question: "In the 'packed lunch' analogy, what do cotyledons represent?",
        options: [
          "The lunchbox (protection)",
          "The traveler (baby plant)",
          "The packed food (stored nutrients)",
          "The destination (soil)"
        ],
        correctIndex: 2,
        explanation: "Cotyledons are like packed sandwiches—they store food for the baby plant to use until it can make its own food through photosynthesis."
      },
      {
        id: "2-q4",
        question: "What does the paper towel wick system use to keep seeds moist?",
        options: [
          "Gravity",
          "Capillary action",
          "Air pressure",
          "Osmosis only"
        ],
        correctIndex: 1,
        explanation: "The wick system uses capillary action—the paper towel pulls water up from the reservoir below, keeping seeds at consistent moisture levels."
      },
      {
        id: "2-q5",
        question: "Why should seeds NOT touch each other during germination?",
        options: [
          "They compete for light",
          "It causes mold growth",
          "They grow faster when crowded",
          "It wastes water"
        ],
        correctIndex: 1,
        explanation: "Seeds touching each other can trap moisture between them, creating ideal conditions for mold growth which can kill germinating seeds."
      }
    ]
  },
  {
    moduleId: 3,
    title: "Week 2: Seedlings Quiz",
    passingScore: 70,
    questions: [
      {
        id: "3-q1",
        question: "What is the primary goal when transplanting seedlings?",
        options: [
          "To move them as quickly as possible",
          "To remove all soil from roots",
          "To protect the roots from damage",
          "To expose roots to air"
        ],
        correctIndex: 2,
        explanation: "The goal of transplanting is to move the plant WITHOUT damaging its roots. Roots are like the plant's mouth—damage them and it can't eat properly."
      },
      {
        id: "3-q2",
        question: "Why do self-watering bottle planters work?",
        options: [
          "The bottle automatically detects when plants need water",
          "A wick pulls water up from a reservoir using capillary action",
          "Water evaporates and condenses on the bottle",
          "Gravity pushes water up to the roots"
        ],
        correctIndex: 1,
        explanation: "Self-watering planters use a cloth wick that pulls water up from the reservoir through capillary action, keeping soil consistently moist."
      },
      {
        id: "3-q3",
        question: "What should you do immediately after transplanting a seedling?",
        options: [
          "Place it in direct sunlight",
          "Wait a week before watering",
          "Water it immediately",
          "Add fertilizer"
        ],
        correctIndex: 2,
        explanation: "Watering immediately after transplanting helps settle the soil around roots and reduces transplant shock."
      },
      {
        id: "3-q4",
        question: "What are the first leaves that emerge from a seed called?",
        options: [
          "True leaves",
          "Cotyledons",
          "Primary leaves",
          "Seed leaves"
        ],
        correctIndex: 1,
        explanation: "The first leaves are cotyledons (seed leaves), which are actually part of the embryo. True leaves emerge later and look different."
      },
      {
        id: "3-q5",
        question: "What indicates healthy root development in seedlings?",
        options: [
          "Brown, mushy roots",
          "White or cream-colored roots",
          "No visible roots",
          "Roots growing above soil"
        ],
        correctIndex: 1,
        explanation: "Healthy roots should be white or cream-colored. Brown, slimy roots indicate rot from overwatering or disease."
      }
    ]
  },
  {
    moduleId: 4,
    title: "Week 3: Hydroponics Quiz",
    passingScore: 70,
    questions: [
      {
        id: "4-q1",
        question: "What does hydroponics mean?",
        options: [
          "Growing plants in enhanced soil",
          "Growing plants in water with dissolved nutrients",
          "Growing plants using only sunlight",
          "Growing plants in greenhouses"
        ],
        correctIndex: 1,
        explanation: "Hydroponics means growing plants in water with dissolved nutrients, completely without soil."
      },
      {
        id: "4-q2",
        question: "What four things does soil normally provide that hydroponics must replace?",
        options: [
          "Color, texture, smell, density",
          "Support, water, oxygen, nutrients",
          "Bacteria, fungi, worms, insects",
          "Shade, humidity, temperature, pressure"
        ],
        correctIndex: 1,
        explanation: "Soil provides support/anchor, water storage, oxygen to roots, and nutrients. Hydroponic systems must provide all of these through other means."
      },
      {
        id: "4-q3",
        question: "Why is an air pump essential in Deep Water Culture (DWC) systems?",
        options: [
          "To keep water warm",
          "To provide oxygen to submerged roots",
          "To move nutrients faster",
          "To prevent algae growth"
        ],
        correctIndex: 1,
        explanation: "Roots need oxygen just like we do. The air pump constantly bubbles oxygen into the water so submerged roots can breathe."
      },
      {
        id: "4-q4",
        question: "What is a key advantage of hydroponic growing?",
        options: [
          "Plants need less light",
          "No equipment required",
          "Plants often grow 30-50% faster",
          "Water usage increases significantly"
        ],
        correctIndex: 2,
        explanation: "Plants in hydroponics often grow 30-50% faster because nutrients are delivered directly to roots without having to search through soil."
      },
      {
        id: "4-q5",
        question: "What should you do before using clay pebbles in a hydroponic system?",
        options: [
          "Freeze them overnight",
          "Rinse them until water runs clear",
          "Soak them in fertilizer",
          "Dry them in the sun"
        ],
        correctIndex: 1,
        explanation: "Clay pebbles must be rinsed thoroughly until the water runs clear. Clay dust can clog plant roots and harm the system."
      }
    ]
  },
  {
    moduleId: 5,
    title: "Week 4: Pollination Quiz",
    passingScore: 70,
    questions: [
      {
        id: "5-q1",
        question: "What are the four layers of a complete flower (from outside to inside)?",
        options: [
          "Root, stem, leaf, flower",
          "Sepals, petals, stamens, pistil",
          "Seed, fruit, flower, leaf",
          "Pollen, nectar, honey, wax"
        ],
        correctIndex: 1,
        explanation: "The four layers are: sepals (protection), petals (attraction), stamens (male parts), and pistil (female part)."
      },
      {
        id: "5-q2",
        question: "What is the function of petals on a flower?",
        options: [
          "Protect the flower bud",
          "Attract pollinators",
          "Produce seeds",
          "Store water"
        ],
        correctIndex: 1,
        explanation: "Petals are the advertising department—they use color, patterns, and sometimes scent to attract pollinators to the flower."
      },
      {
        id: "5-q3",
        question: "What is a 'perfect' flower?",
        options: [
          "A flower with no defects",
          "A flower with both male and female parts",
          "The most beautiful flower in a garden",
          "A flower that never wilts"
        ],
        correctIndex: 1,
        explanation: "A 'perfect' flower contains both stamens (male) AND pistil (female), meaning it can potentially self-pollinate."
      },
      {
        id: "5-q4",
        question: "What part of the pistil receives pollen?",
        options: [
          "Ovary",
          "Style",
          "Stigma",
          "Anther"
        ],
        correctIndex: 2,
        explanation: "The stigma is the sticky landing pad at the top of the pistil that receives and holds pollen grains."
      },
      {
        id: "5-q5",
        question: "Botanically speaking, is a tomato a fruit or vegetable?",
        options: [
          "Vegetable",
          "Fruit (it's a ripened ovary containing seeds)",
          "Neither",
          "It depends on the variety"
        ],
        correctIndex: 1,
        explanation: "Botanically, a tomato is a FRUIT—it's a ripened ovary containing seeds. Cucumbers, peppers, and squash are also fruits!"
      }
    ]
  },
  {
    moduleId: 6,
    title: "Week 5: Harvest Quiz",
    passingScore: 70,
    questions: [
      {
        id: "6-q1",
        question: "What is 'cut-and-come-again' harvesting?",
        options: [
          "Cutting the entire plant and replanting",
          "Harvesting outer leaves while leaving the center to continue growing",
          "Cutting plants in half",
          "Harvesting every other plant"
        ],
        correctIndex: 1,
        explanation: "Cut-and-come-again means harvesting only outer leaves while leaving the center growing point intact, allowing the plant to keep producing for weeks."
      },
      {
        id: "6-q2",
        question: "What does 'bolting' indicate in lettuce?",
        options: [
          "The plant is ready to harvest",
          "The plant is stressed and trying to reproduce, becoming bitter",
          "The plant needs more water",
          "The plant is extremely healthy"
        ],
        correctIndex: 1,
        explanation: "Bolting happens when the plant's center starts stretching upward to produce flowers. This makes leaves bitter and tough—harvest before bolting!"
      },
      {
        id: "6-q3",
        question: "When is the best time of day to harvest for maximum freshness?",
        options: [
          "Midday when it's warmest",
          "Morning when plants are most hydrated",
          "Evening after a full day of sun",
          "It doesn't matter"
        ],
        correctIndex: 1,
        explanation: "Morning harvest is often best because plants are fully hydrated from overnight and haven't lost water to daytime heat stress."
      },
      {
        id: "6-q4",
        question: "What happens if you harvest herbs AFTER they flower?",
        options: [
          "They taste better",
          "Leaf quality and flavor decrease",
          "They produce more leaves",
          "Nothing changes"
        ],
        correctIndex: 1,
        explanation: "Once herbs flower, the plant puts energy into reproduction rather than leaf production, reducing the quality and flavor of leaves."
      },
      {
        id: "6-q5",
        question: "How can you tell if root vegetables are ready to harvest?",
        options: [
          "The leaves turn yellow",
          "The shoulders are visible above the soil line",
          "The plant stops growing completely",
          "The roots push completely out of the soil"
        ],
        correctIndex: 1,
        explanation: "When the shoulders (top part) of root vegetables become visible above the soil line and reach the proper size for the variety, they're ready to harvest."
      }
    ]
  },
  {
    moduleId: 7,
    title: "Week 6: Optimization Quiz",
    passingScore: 70,
    questions: [
      {
        id: "7-q1",
        question: "What is the first step in the plant diagnostic process?",
        options: [
          "Apply fertilizer immediately",
          "Observe carefully where, what, when, and which",
          "Remove affected leaves",
          "Move the plant to a new location"
        ],
        correctIndex: 1,
        explanation: "Always start by observing: WHERE is the problem, WHAT does it look like, WHEN did it start, and WHICH plants are affected."
      },
      {
        id: "7-q2",
        question: "What causes 'leggy' or stretched plants with long spaces between leaves?",
        options: [
          "Too much water",
          "Insufficient light",
          "Too much fertilizer",
          "High humidity"
        ],
        correctIndex: 1,
        explanation: "Leggy, stretched plants with pale color and weak stems are classic signs of insufficient light—plants are reaching toward any light source."
      },
      {
        id: "7-q3",
        question: "What is succession planting?",
        options: [
          "Planting different species together",
          "Staggering plantings for continuous harvest",
          "Planting in a straight line",
          "Planting only after the first frost"
        ],
        correctIndex: 1,
        explanation: "Succession planting means staggering your plantings so you always have crops at different stages of growth, ensuring continuous harvests."
      },
      {
        id: "7-q4",
        question: "Why should you make only ONE change at a time when troubleshooting plant problems?",
        options: [
          "It's less work",
          "So you can identify what actually fixed the problem",
          "Plants can only handle one change",
          "It saves money on supplies"
        ],
        correctIndex: 1,
        explanation: "Making multiple changes at once makes it impossible to know which one actually solved the problem, or if a change made things worse."
      },
      {
        id: "7-q5",
        question: "To harvest lettuce every 10 days with 50 days to maturity, how many staggered plantings do you need?",
        options: [
          "3 plantings",
          "4 plantings",
          "5 plantings",
          "10 plantings"
        ],
        correctIndex: 2,
        explanation: "50 days ÷ 10 days = 5 batches needed in rotation to have a batch ready every 10 days continuously."
      }
    ]
  }
];

export const getQuizForModule = (moduleId: number): ModuleQuiz | undefined => {
  return moduleQuizzes.find(q => q.moduleId === moduleId);
};

export const calculateQuizScore = (answers: Record<string, number>, moduleId: number): { 
  score: number; 
  passed: boolean; 
  total: number;
  correct: number;
} => {
  const quiz = getQuizForModule(moduleId);
  if (!quiz) return { score: 0, passed: false, total: 0, correct: 0 };

  let correct = 0;
  quiz.questions.forEach(q => {
    if (answers[q.id] === q.correctIndex) {
      correct++;
    }
  });

  const score = Math.round((correct / quiz.questions.length) * 100);
  return {
    score,
    passed: score >= quiz.passingScore,
    total: quiz.questions.length,
    correct
  };
};
