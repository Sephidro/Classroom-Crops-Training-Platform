# Classroom Crops Teacher Training Platform

## Overview

A premium React Native/Expo mobile application designed to train teachers with no agriculture experience to become confident instructors of the Classroom Crops curriculum. The platform provides structured, self-paced training through 7 modules and 34 lessons, tracking progress and celebrating growth through a gamified learning experience.

The app follows an "Organic Editorial" aesthetic - sophisticated natural warmth with magazine-quality typography, using earthy greens and clean whitespace with rounded corners.

## Premium Features

**Complete Training System**:
- 7 comprehensive modules covering seeds, seedlings, hydroponics, pollination, harvesting, and optimization
- 34 detailed lessons with "what to say" scripts for teachers
- Offline-capable content - all training material works without internet

**Assessment & Certification**:
- Module quizzes (5 questions each, 70% passing score)
- Professional completion certificates (PDF generation via expo-print)
- Quiz score persistence with best score tracking

**Achievement System**:
- 12 unlockable achievement badges
- Progress tracking for lesson completion, quiz performance, and milestones
- Visual badge display in profile

**PDF Export**:
- Printable lesson plans for classroom use
- Includes "what to say" scripts, activities, materials lists, and discussion questions
- Share/print functionality via expo-sharing

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React Native with Expo SDK 54, using the new architecture and React 19.1

**Navigation Structure**:
- Root Stack Navigator (modal presentations)
- Bottom Tab Navigator with 3 tabs: Training, My Learning, Profile
- Nested stack navigators per tab for push navigation

**State Management**:
- React Context for progress tracking (ProgressContext)
- TanStack React Query for server state management
- AsyncStorage for local persistence of user progress, bookmarks, and preferences

**UI Components**:
- Custom themed components (ThemedText, ThemedView, Card, Button)
- Reanimated for smooth animations with spring configs
- expo-blur for iOS glassmorphism effects
- Nunito font family via expo-google-fonts

**Design System** (constants/theme.ts):
- Brand colors: Forest Green primary, Warm Earth secondary, Golden Harvest accent
- Module-specific accent colors for visual differentiation
- Light/dark theme support
- Consistent spacing, border radius, and typography scales

### Backend Architecture

**Server**: Express.js (v5) running on Node.js with TypeScript

**API Structure**: RESTful endpoints prefixed with `/api` (routes defined in server/routes.ts)

**Data Layer**:
- Drizzle ORM with PostgreSQL dialect
- Schema defined in shared/schema.ts (currently users table)
- In-memory storage implementation available (server/storage.ts)

**Build System**:
- esbuild for server bundling
- Custom build script for Expo static web builds
- Separate dev/prod configurations

### Data Flow

1. Training content is statically defined in `client/data/trainingData.ts`
2. User progress persisted locally via AsyncStorage
3. Server provides API endpoints for potential future backend features
4. Shared schema types between client and server via `@shared` path alias

### Key Design Patterns

- **Path aliases**: `@/` for client code, `@shared/` for shared code
- **Screen composition**: Header height + safe area insets + tab bar height calculations
- **Haptic feedback**: Used throughout for interactive elements
- **Error boundaries**: Graceful error handling with recovery options

## External Dependencies

### Database
- PostgreSQL via Drizzle ORM (configured but schema is minimal)
- DATABASE_URL environment variable required for production

### Third-Party Services
- Expo services (splash screen, fonts, haptics, image handling)
- No external authentication service (no auth required per design)

### Key NPM Packages
- `expo` ecosystem for mobile capabilities
- `@tanstack/react-query` for data fetching
- `react-native-reanimated` for animations
- `drizzle-orm` + `drizzle-zod` for database and validation
- `@react-navigation/*` for navigation
- `expo-print` for PDF generation
- `expo-sharing` for file sharing
- `ws` for WebSocket support (server)

## Recent Changes (Feb 2026)

- Added comprehensive quiz system with 7 module quizzes (35 total questions)
- Implemented achievement badge system (12 achievements)
- Added PDF export for printable lesson plans with proper pagination
- Integrated certificate generation for program completion
- Updated Profile screen with achievements display and certificate download
- Added "Take Quiz" buttons to module cards in Training tab
- Created Substitute Teacher Quick Start guide with emergency lesson plans
- Fixed NetworkContext to remove external dependency issues
- Fixed PDF export to generate complete module PDFs with page breaks
- Added calendar integration for scheduling lessons (expo-calendar)
- Implemented lesson scheduling from lesson viewer with date/time selection

### Key Screens
- TrainingScreen: Browse all 7 training modules
- ModuleDetailScreen: View lessons in a module with Take Quiz button
- LessonViewerScreen: Modal lesson viewer with tabs, PDF export, calendar scheduling
- QuizScreen: Modal quiz with 5 questions per module
- ProfileScreen: Achievements, certificates, Quick Start access
- ScheduleLessonScreen: Schedule lessons to device calendar
- QuickStartScreen: Emergency lesson plans for substitute teachers

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `EXPO_PUBLIC_DOMAIN`: API server domain for client requests
- `REPLIT_DEV_DOMAIN` / `REPLIT_DOMAINS`: CORS configuration